-- A basic encounter script skeleton you can copy and modify for your own creations.

music = "war_zone" --Always OGG or WAV. Extension is added automatically. Remove the first two lines for custom music.
encountertext = "Old Snake.[w:30]\nBut[w:10].[w:10].[w:10].a dog." --Modify as necessary. It will only be read out in the action select screen.
nextwaves = {"bullettest_bouncy"}
wavetimer = 4.0
arenasize = {155, 130}

enemies = {
"poseur"
}

enemypositions = {
{0, 0}
}

first_turn = true
confirm_level = 0
mode = nil
zlock = 0
hide = false

function Update()
	--[[
	VALUES:
	absx:
	48 - FIGHT option
	202 - ACT option
	361 - ITEM option
	515 - MERCY option
	65 - COLLUMN 1
	321 - COLLUMN 2
	absy:
	25 - FIGHT/ACT/ITEM/MERCY
	190 - ROW 1
	160 - ROW 2
	130 - ROW 3
	]]--
	if Input.Confirm == 1 and confirm_level < 3 and thetime ~= -1 then
		confirm_level = confirm_level + 1
	end
	if Input.Cancel == 1 and confirm_level > 0 and zlock == 0 then
		confirm_level = confirm_level - 1
	end
	if Input.Confirm == 1 and Input.Cancel == 1 and confirm_level < 3 then
		confirm_level = confirm_level + 1
	end
	if confirm_level == 0 and mode ~= nil then
		--Player went back to FIGHT/ACT/ITEM/MERCY
		mode = nil
	end
	if Player.absx == 48 and confirm_level == 1 then
		--Player has selected FIGHT
		mode = "FIGHT"
	elseif Player.absx == 202 and confirm_level == 1 then
		--Player has selected ACT
		mode = "ACT"
	elseif Player.absx == 361 and confirm_level == 1 then
		--Player has selected ITEM
		mode = "ITEM"
	elseif Player.absx == 515 and confirm_level == 1 then
		--Player has selected MERCY
		mode = "MERCY"
	end
	
	if mode == "FIGHT" and confirm_level == 2 then
		--Player has chosen an enemy to FIGHT
		zlock = 1
		hide = true
	end
	
	if mode == "ITEM" and confirm_level == 2 then
		--Player has used an ITEM
		hide = true
	end
	
	if mode == "FIGHT" and confirm_level == 3 then
		--Player has FIGHTed
	end
	if mode == "ACT" and confirm_level == 3 then
		--Player has ACTed
		hide = true
	end
	if mode == "ITEM" and confirm_level == 3 then
		--Player has ITEMed
		hide = true
	end
	if mode == "MERCY" and Player.absy == 190 and confirm_level == 2 then
		--Player has SPAREed
		confirm_level = 0
		hide = true
	end
	if mode == "MERCY" and Player.absy == 160 and confirm_level == 2 then
		--Player has FLEEd
		mode = nil
		hide = true
	end
	if GetGlobal("globalprojectile") ~= nil and hide == false then
		GetGlobal("globalprojectile").MoveToAbs(Player.absx,Player.absy)
	elseif GetGlobal("globalprojectile") ~= nil and hide == true then
		GetGlobal("globalprojectile").MoveToAbs(300,500)
	end
	if Player.isHurting and GetGlobal("globalprojectile") ~= nil and GetGlobal("globalprojectile").GetVar("nohurt") == 1 then
		Audio.PlaySound("bark")
		GetGlobal("globalprojectile").Remove()
		SetGlobal("globalprojectile",CreateProjectileAbs("bullet_old_snake_2",Player.absx,Player.absy))
		GetGlobal("globalprojectile").SetVar("nohurt",2)
		GetGlobal("globalprojectile").MoveToAbs(Player.absx,Player.absy)
		GetGlobal("globalprojectile").SendToBottom()
	elseif not Player.isHurting and GetGlobal("globalprojectile") ~= nil and GetGlobal("globalprojectile").GetVar("nohurt") == 2 then
		GetGlobal("globalprojectile").Remove()
		SetGlobal("globalprojectile",CreateProjectileAbs("bullet_old_snake",Player.absx,Player.absy))
		GetGlobal("globalprojectile").SetVar("nohurt",1)
		GetGlobal("globalprojectile").MoveToAbs(Player.absx,Player.absy)
		GetGlobal("globalprojectile").SendToBottom()
	end
end

function OnHit(bullet)
	if bullet.GetVar("nohurt") == nil then
		Player.hurt(1,0)
	end
end

-- A custom list with attacks to choose from. Actual selection happens in EnemyDialogueEnding(). Put here in case you want to use it.
possible_attacks = {"bullettest_bouncy", "bullettest_chaserorb", "bullettest_touhou"}

function EncounterStarting()
    -- If you want to change the game state immediately, this is the place.
	Audio.PlaySound("detected")
	SetGlobal("globalprojectile",CreateProjectileAbs("bullet_old_snake",Player.absx,Player.absy))
	GetGlobal("globalprojectile").SetVar("nohurt",1)
	GetGlobal("globalprojectile").MoveToAbs(Player.absx,Player.absy)
	Player.name = "SNAKE"
end

function EnemyDialogueStarting()
    -- Good location for setting monster dialogue depending on how the battle is going.
    -- Example: enemies[1].SetVar('currentdialogue', {"Check it\nout!"})   See documentation for details.
	zlock = 0
	confirm_level = 0
	hide = false
end

function EnemyDialogueEnding()
    -- Good location to fill the 'nextwaves' table with the attacks you want to have simultaneously.
    -- This example line below takes a random attack from 'possible_attacks'.
	nextwaves = { possible_attacks[math.random(#possible_attacks)] }
end

function DefenseEnding() --This built-in function fires after the defense round ends.
    encountertext = RandomEncounterText() --This built-in function gets a random encounter text from a random enemy.
	mode = nil
	confirm_level = 0
	hide = false
	SetGlobal("globalprojectile",CreateProjectileAbs("bullet_old_snake",Player.absx,Player.absy))
	GetGlobal("globalprojectile").SetVar("nohurt",1)
	GetGlobal("globalprojectile").MoveToAbs(Player.absx,Player.absy)
end

function HandleSpare()
     State("ENEMYDIALOGUE") --By default, pressing spare only spares the enemies but stays in the menu. Changing state happens here.
end

function HandleItem(ItemID)
    BattleDialog({"Selected item " .. ItemID .. "."})
end