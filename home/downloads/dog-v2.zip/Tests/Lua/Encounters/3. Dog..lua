-- A basic encounter script skeleton you can copy and modify for your own creations.

--music = "dog" --Always OGG or WAV. Extension is added automatically. Remove the first two lines for custom music.
encountertext = "Poseur strikes a pose!" --Modify as necessary. It will only be read out in the action select screen.
nextwaves = {"bullettest_bouncy"}
wavetimer = math.huge
arenasize = {155, 130}

enemies = {
"poseur"
}

enemypositions = {
{0, 0}
}

first_turn = true
confirm_level = 0
mode = nil
zlock = 0
hide = false
barks = {}
warp = 0
timer = 0
warptox = 0
warptoy = 0
warpeffects = {}
xspeed = 0
yspeed = 0
SetGlobal("arenawidth",arenasize[1])
SetGlobal("arenaheight",arenasize[2])

function Update()
	timer = timer + 1
	--[[
	VALUES:
	absx:
	48 - FIGHT option
	202 - ACT option
	361 - ITEM option
	515 - MERCY option
	65 - COLLUMN 1
	321 - COLLUMN 2
	absy:
	25 - FIGHT/ACT/ITEM/MERCY
	190 - ROW 1
	160 - ROW 2
	130 - ROW 3
	]]--
	if Input.Confirm == 1 and confirm_level < 3 and thetime ~= -1 then
		confirm_level = confirm_level + 1
	end
	if Input.Cancel == 1 and confirm_level > 0 and zlock == 0 then
		confirm_level = confirm_level - 1
	end
	if Input.Confirm == 1 and Input.Cancel == 1 and confirm_level < 3 then
		confirm_level = confirm_level + 1
	end
	if confirm_level == 0 and mode ~= nil then
		--Player went back to FIGHT/ACT/ITEM/MERCY
		mode = nil
	end
	if Player.absx == 48 and confirm_level == 1 then
		--Player has selected FIGHT
		mode = "FIGHT"
	elseif Player.absx == 202 and confirm_level == 1 then
		--Player has selected ACT
		mode = "ACT"
	elseif Player.absx == 361 and confirm_level == 1 then
		--Player has selected ITEM
		mode = "ITEM"
	elseif Player.absx == 515 and confirm_level == 1 then
		--Player has selected MERCY
		mode = "MERCY"
	end
	
	if mode == "FIGHT" and confirm_level == 2 then
		--Player has chosen an enemy to FIGHT
		zlock = 1
		hide = true
	end
	
	if mode == "ITEM" and confirm_level == 2 then
		--Player has used an ITEM
		hide = true
	end
	
	if mode == "FIGHT" and confirm_level == 3 then
		--Player has FIGHTed
	end
	if mode == "ACT" and confirm_level == 3 then
		--Player has ACTed
		hide = true
	end
	if mode == "ITEM" and confirm_level == 3 then
		--Player has ITEMed
		hide = true
	end
	if mode == "MERCY" and Player.absy == 190 and confirm_level == 2 then
		--Player has SPAREed
		confirm_level = 0
		hide = true
	end
	if mode == "MERCY" and Player.absy == 160 and confirm_level == 2 then
		--Player has FLEEd
		mode = nil
		hide = true
	end
	if GetGlobal("globalprojectile") ~= nil and hide == false then
		GetGlobal("globalprojectile").MoveToAbs(Player.absx,Player.absy)
	elseif GetGlobal("globalprojectile") ~= nil and hide == true then
		GetGlobal("globalprojectile").MoveToAbs(300,500)
	end
	if Input.Menu == 1 and GetGlobal("globalprojectile") ~= nil and hide == false then
		local bark = nil
		if #warpeffects == 1 then
			bark = CreateProjectileAbs("bark",warpeffects[1].absx + 8,warpeffects[1].absy + 12)
		else
			bark = CreateProjectileAbs("bark",Player.absx+8,Player.absy + 12)
		end
		bark.SetVar("nohurt",1)
		bark.SetVar("velx",2)
		Audio.PlaySound("bark")
		table.insert(barks,bark)
	end
	if Input.Confirm == 1 and mode == "defense" and GetGlobal("globalprojectile") ~= nil and warp == 0 then
		warptox = Player.x
		warptoy = Player.y
		xspeed = 0
		yspeed = 0
		Player.SetControlOverride(true)
		Audio.PlaySound("vworp")
		warp = 1
	elseif Input.Confirm == -1 and mode == "defense" and warp > 0 then
		if warpeffects[1] ~= nil then
			warpeffects[1].Remove()
		end
		warpeffects = {}
		Player.SetControlOverride(false)
		Audio.PlaySound("slice")
		warp = -1
		GetGlobal("globalprojectile").Remove()
		SetGlobal("globalprojectile",CreateProjectileAbs("bullet_warp3",Player.absx,Player.absy))
		GetGlobal("globalprojectile").SetVar("nohurt",1)
	elseif warp <= -1 and Player.x ~= movetox and Player.y ~= movetoy then
		local differencex = nil
		local differencey = nil
		differencex = Player.x - warptox
		differencey = Player.y - warptoy
		--xspeed = xspeed / 2 + differencex
		--yspeed = yspeed / 2 + differencey
		xspeed = xspeed / 1.25 - differencex --/ 100
		yspeed = yspeed / 1.25 - differencey --/ 100
		Player.MoveTo(Check(Player.x + xspeed), Check(Player.y + yspeed), false)
		if timer%4 == 0 then
			if warp == -1 then
				warp = -2
				GetGlobal("globalprojectile").Remove()
				SetGlobal("globalprojectile",CreateProjectileAbs("bullet_warp1",Player.absx,Player.absy))
				GetGlobal("globalprojectile").SetVar("nohurt",1)
			else
				warp = -1
				GetGlobal("globalprojectile").Remove()
				SetGlobal("globalprojectile",CreateProjectileAbs("bullet_warp3",Player.absx,Player.absy))
				GetGlobal("globalprojectile").SetVar("nohurt",1)
			end
		end
		if GetGlobal("globalprojectile") ~= nil then
			GetGlobal("globalprojectile").MoveTo(Player.x,Player.y)
		end
		if (xspeed < 0.1 and xspeed > -0.1 and yspeed < 0.1 and yspeed > -0.1) or Input.Menu == 1 then
			warp = 0
			GetGlobal("globalprojectile").Remove()
			SetGlobal("globalprojectile",CreateProjectileAbs("bullet",Player.absx,Player.absy))
			GetGlobal("globalprojectile").SetVar("nohurt",1)
		end
	end
	if warp > 0 and Input.Confirm == 2 and warptox ~= nil and warptoy ~= nil then
		warptox = warptox + Input.Right - Input.Left
		warptoy = warptoy + Input.Up - Input.Down
	end
	if timer%8 == 0 and warp > 0 then
		Audio.PlaySound("flick")
		local sprite = "bullet_warp"
		if warp == 1 then
			warp = 2
		else
			warp = 1
		end
		GetGlobal("globalprojectile").Remove()
		SetGlobal("globalprojectile",CreateProjectileAbs(sprite..tostring(warp),Player.absx,Player.absy))
		GetGlobal("globalprojectile").SetVar("nohurt",1)
		if #warpeffects ~= 1 then
			local ghost = CreateProjectileAbs("bullet_ghost",warptox,warptoy)
			ghost.SetVar("nohurt",1)
			table.insert(warpeffects,ghost)
		end
	end
	for i=1,#warpeffects do
		if warpeffects[i] ~= nil then
			local line = warpeffects[i]
			line.MoveTo(warptox, warptoy)
		end
	end
	for i=1,#barks do
		if barks[i] ~= nil then
			local bark = barks[i]
			local velx = bark.GetVar("velx")
			velx = velx - 0.08
			bark.SetVar("velx",velx)
			bark.Move(velx,velx*2)
			if velx < 0 then
				bark.Remove()
				table.remove(barks,i)
			end
		end
	end
end

function Check(num)
	if num > -GetGlobal("arenawidth") / 2 and num < GetGlobal("arenawidth") / 2 and num > -GetGlobal("arenaheight") / 2 and num < GetGlobal("arenaheight") / 2 then
		return num
	else
		return num/2
	end
end

function OnHit(bullet)
	if bullet.GetVar("nohurt") == nil then
		Player.hurt(1,0)
	end
end

-- A custom list with attacks to choose from. Actual selection happens in EnemyDialogueEnding(). Put here in case you want to use it.
possible_attacks = {"bullettest_bouncy", "bullettest_chaserorb", "bullettest_touhou"}

function EncounterStarting()
    -- If you want to change the game state immediately, this is the place.
end

function EnemyDialogueStarting()
    -- Good location for setting monster dialogue depending on how the battle is going.
    -- Example: enemies[1].SetVar('currentdialogue', {"Check it\nout!"})   See documentation for details.
	zlock = 0
	confirm_level = 0
	hide = false
	if first_turn == true then
		enemies[1].SetVar("currentdialogue","How do\nyou like\nTHIS?")
	end
end

function EnemyDialogueEnding()
    -- Good location to fill the 'nextwaves' table with the attacks you want to have simultaneously.
    -- This example line below takes a random attack from 'possible_attacks'.
	mode = "defense"
	if first_turn == true then
		nextwaves = { "dog" }
	else
		nextwaves = { possible_attacks[math.random(#possible_attacks)] }
	end
end

function DefenseEnding() --This built-in function fires after the defense round ends.
    --encountertext = RandomEncounterText() --This built-in function gets a random encounter text from a random enemy.
	if #warpeffects == 1 then
		warpeffects[1].Remove()
	end
	warp = 0
	mode = nil
	if first_turn == true then
		first_turn = false
		wavetimer = 4.0
	end
	encountertext = "You're dog now."
	confirm_level = 0
	hide = false
	SetGlobal("globalprojectile",CreateProjectileAbs("bullet",Player.absx,Player.absy))
	GetGlobal("globalprojectile").SetVar("nohurt",1)
	GetGlobal("globalprojectile").MoveToAbs(Player.absx,Player.absy)
	--[[
	if GetGlobal("globalprojectile") == nil then
		SetGlobal("globalprojectile",CreateProjectileAbs("bullet",Player.absx,Player.absy))
		GetGlobal("globalprojectile").SetVar("nohurt",1)		
	else
		GetGlobal("globalprojectile").Remove()
		SetGlobal("globalprojectile",nil)
		SetGlobal("globalprojectile",CreateProjectileAbs("bullet",Player.absx,Player.absy))
		GetGlobal("globalprojectile").SetVar("nohurt",1)	
	end
	]]--
end

function HandleSpare()
     State("ENEMYDIALOGUE") --By default, pressing spare only spares the enemies but stays in the menu. Changing state happens here.
end

function HandleItem(ItemID)
    BattleDialog({"Selected item " .. ItemID .. "."})
end