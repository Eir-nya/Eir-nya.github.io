gametime = 0
bullets = {}
Volume = 0.75
function Update()
	gametime = gametime + 1
	if gametime == 250 then
		Audio.PlaySound("dogsecret")
		SetGlobal("globalprojectile",CreateProjectileAbs("bullet",Player.absx,Player.absy))
		GetGlobal("globalprojectile").SetVar("nohurt",1)
	elseif gametime == 350 then
		Audio.Stop()
		Audio.LoadFile("dogtrousle")
		Audio.Volume(1)
		Audio.Play()
		EndWave()
	end
	if gametime%12 == 0 and gametime > 150 and Volume > 0 and gametime < 250 then
		Volume = Volume - 0.15
		Audio.Volume(Volume)
	elseif Volume <= 0 and gametime < 250 then
		Audio.Stop()
		Audio.Volume(0.0)
	end
	if gametime%(math.random(1,3) * 6) == 0 and gametime > 40 and gametime < 150 then
		local bullet = CreateProjectileAbs("bullet_blue",400,math.random(100,200))
		bullet.SetVar("speed",math.random(2,5))
		table.insert(bullets,bullet)
	end
	for i=1,#bullets do
		if bullets[i] ~= nil then
			local bullet = bullets[i]
			local speed = bullet.GetVar("speed")
			bullet.Move(-speed,0)
			if bullet.x <= -Arena.width/2 then
				bullet.Remove()
				table.remove(bullets,i)
			end
		end
	end
end

function OnHit(bullet)
	if Player.isMoving and bullet.GetVar("nohurt") == nil then
		Player.Hurt(3)
	end
end