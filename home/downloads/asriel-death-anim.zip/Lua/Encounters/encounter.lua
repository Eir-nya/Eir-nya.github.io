currentstate = "NONE"
music = "ura_ha_ha!"
encountertext = "Asriel takes a stand!"
nextwaves = {"fire"}
wavetimer = math.huge -- 4.0
arenasize = {155, 130}
enemies = {
"asriel", "items", "spare"
}
enemypositions = {
{-7, 3}, {0, 0}, {0, 0}
}
phase = 0
sparepos = 3
itemmenu = false
createmask = true
create_mask_timer = -1

damage_indicators = {}
damage_number_counter = 40
decrease_counter = false
deathcounter = 0

function HurtPlayer(damage)
	if not Player.isHurting then
		if Player.hp - damage > 0 and Player.hp > 1 then
			Player.Hurt(damage)
		elseif Player.hp - damage <= 0 and Player.hp > 1 then
			Player.Hurt(Player.hp - 1)
		elseif Player.hp == 1 and GetGlobal("capture") == nil then
			Audio.Stop()
			Player.hp = 2
			Player.Hurt(1)
			local x = Player.x
			local y = Player.y
			nextwaves = {"capture"}
			capturing = true
			State("ACTIONSELECT")
			Player.MoveTo(x,y,false)
		end
	end
end
function Update()
	if Player.sprite.color ~= {1.0,0.0,0.0} then
		Player.sprite.color = {1.0,0.0,0.0}
	end
	if currentstate == "ENEMYDIALOGUE" and Input.Confirm == 1 and enemies[1]["talking"] == false then
		enemies[1].Call("face",enemies[1]["facesprite"])
	elseif currentstate == "ENEMYDIALOGUE" and Input.Cancel == 1 and GetGlobal("capture") == nil then
		enemies[1].Call("stoptalking")
	end
	if currentstate ~= "ITEMMENU" and itemoverlay ~= nil then
		itemoverlay.Remove()
		itemmenu = false
	end
	if currentstate == "ITEMMENU" then
		if Input.Right == 1 and Player.absx == 321 and Player.absy == 190 and #enemies[2].GetVar("commands2") >= 1 then
			ChangePage()
		elseif Input.Left == 1 and Player.absx == 65 and Player.absy == 190 and #enemies[2].GetVar("commands2") >= 2 then
			ChangePage()
		elseif Input.Right == 1 and Player.absx == 321 and Player.absy == 160 and #enemies[2].GetVar("commands2") >= 3 then
			ChangePage()
		elseif Input.Left == 1 and Player.absx == 65 and Player.absy == 160 and #enemies[2].GetVar("commands2") == 4 then
			ChangePage()
		end
	end
	if mercymenu == true and Input.Confirm == 1 then
		if Player.absy == 190 then
			SwapActiveEnemies(true)
			if enemies[sparepos]["name"] ~= "[starcolor:ffffff]Spare" then
				for k,v in pairs(enemies) do
					if v["canspare"] == true then
						v.Call("Spare")
						break
					end
				end
			else
				HandleSpare()
			end
		end
		Audio.PlaySound("menuconfirm")
	end
	if create_mask_timer > 0 then
		create_mask_timer = create_mask_timer - 1
	elseif create_mask_timer == 0 then
		create_mask_timer = -1
		if currentstate ~= "DEFENDING" and createmask == true then
			mask = CreateProjectile("masks/245x130overlay",0,0)
			if GetGlobal("capture") ~= nil then
				mask.Remove()
				mask = CreateProjectile("masks/245x130overlay2",0,0)
			end
			mask.SetVar("safe",true)
		end
	end
	if decrease_counter == true and damage_number_counter > 0 then
		damage_number_counter = damage_number_counter - 1
	elseif damage_number_counter == 0 and decrease_counter == true then
		decrease_counter = false
		hp_back.alpha = 0
		hp_front.alpha = 0
		for k,v in pairs(damage_indicators) do
			if v.isactive then ; v.Remove() ; end
		end
	end
	if death == true then
		deathcounter = deathcounter + 0.5
		if mask ~= nil then ; mask.Remove() ; end
		if deathcounter == 1 then
			Player.MoveToAbs(-16,-16,true)
			body.Remove()
			head.Remove()
			hurt = CreateSprite("hurt")
			hurt.SendToBottom()
			hurt.MoveToAbs(313,303)
		elseif deathcounter == 2 then ; hurt.Remove() ; enemies[1].Call("SetSprite","hurt")
		elseif deathcounter == 60 then
			enemies[3].Call("SetActive",true)
			enemies[1].Call("Kill")
			scarf = CreateProjectileAbs("scarf",313,340)
			scarf.sprite.SetPivot(0.5,0.75)
			scarf.SetVar("safe",true)
		elseif deathcounter >= 140 and deathcounter <= 300 then
			if deathcounter%3 == 0 then
				scarf.MoveToAbs(313+math.sin(deathcounter/15)*10,scarf.absy-1.3)
			end
			if deathcounter%30 == 0 then
				scarf.sprite.rotation = -math.sin(deathcounter/2)*2.5
			end
		elseif deathcounter == 360 then
			black = CreateProjectileAbs("bg",320,240)
			black.sprite.alpha = 0
			black.SetVar("safe",true)
		elseif deathcounter >= 400 and deathcounter < 450 then
			black.sprite.alpha = black.sprite.alpha + 0.01
		elseif deathcounter == 475 then
			State("DONE")
		end
		if deathcounter%1 == 0 then ; State("NONE") ; end
	end
end
function ChangePage()
	enemies[2].Call("SwapTables")
	itemoverlay.Remove()
	State("ITEMMENU")
end
function OnHit(bullet)
	if bullet.GetVar("safe") == nil then
		Player.Hurt(1,0)
	end
end
function EnteringState(newstate,oldstate)
	currentstate = newstate
	if newstate == "ATTACKING" then
		SetGlobal("enemynum",((190 - Player.absy)/30) + 1)
		nextwaves = { "shoes" }
		State("DEFENDING")
	elseif oldstate == "DEFENDING" and attacking then
		attacking = nil
		damage_number_counter = 40
		decrease_counter = true
	end
	if newstate == "ITEMMENU" then
		if itemmenu == false then
			local commands = enemies[2].GetVar("commands")
			local commands2 = enemies[2].GetVar("commands2")
			if #commands <=3 and #commands2 > 0 then
				for i=1,4-#commands do
					if #commands2 > 0 then
						local item = commands2[1]
						table.remove(commands2,1)
						table.insert(commands,item)
					end
				end
			end
			enemies[2].SetVar("commands",commands)
			enemies[2].SetVar("commands2",commands2)
		end
		if #enemies[2].GetVar("commands") + #enemies[2].GetVar("commands2") > 0 then
			enemies[1].Call("SetActive",false)
			enemies[2].Call("SetActive",true)
			itemmenu = true
			local alt = 0
			if enemies[2].GetVar("alt")%2 ~= 0 then
				alt = 2
			else
				alt = 1
			end
			itemoverlay = CreateProjectileAbs("items_"..alt,320,240)
			itemoverlay.SetVar("safe",1)
			State("ACTMENU")
		else
			State("ACTIONSELECT")
		end
	elseif newstate == "ENEMYDIALOGUE" then
		local alt = enemies[2].GetVar("alt")
		if alt%2 ~= 0 then
			enemies[2].Call("SwapTables")
		end
	elseif oldstate == "ACTMENU" then
		enemies[1].Call("SetActive",true)
		enemies[2].Call("SetActive",false)
		if itemmenu == true and newstate == "ENEMYSELECT" then
			itemmenu = false
			State("ACTIONSELECT")
		end
	end
	if newstate == "MERCYMENU" then
		SwapActiveEnemies(false)
		State("ENEMYSELECT")
	elseif oldstate == "ENEMYSELECT" and mercymenu == true then
		SwapActiveEnemies(true)
	end
	if newstate == "ENEMYDIALOGUE" then
		enemies[1]["talking"] = true
		enemies[1].Call("face",enemies[1]["facesprite"])
		enemies[1].Call("SetSprite","blank")
		body.alpha = 1
		head.alpha = 1
	elseif oldstate == "ENEMYDIALOGUE" then
		enemies[1].Call("stoptalking")
		enemies[1]["currentdialogue"] = nil
		enemies[1].Call("SetSprite","blank_small")
	end
	if newstate == "ENEMYDIALOGUE" or (oldstate == "DEFENDING" and newstate == "ENEMYDIALOGUE") then
		Player.SetControlOverride(true)
		create_mask_timer = 20
	elseif (newstate == "DEFENDING" or oldstate == "ENEMYDIALOGUE") and mask ~= nil then
		Player.SetControlOverride(false)
		create_mask_timer = -1
		mask.Remove()
	end
	if newstate == "ENEMYDIALOGUE" and phase == 1 and not GetGlobal("capture") then
		enemies[1].Call("advancetables")
	elseif oldstate == "DEFENDING" and face_after_attack ~= nil then
		head.Set("face/"..face_after_attack)
		head.SetAnimation({"face/"..face_after_attack})
		face_after_attack = nil
	end
	if newstate == "ACTIONSELECT" and oldstate == "DEFENDING" and capturing ~= nil then ; State("DEFENDING") ;end
end
function SwapActiveEnemies(normal)
	if normal == true then
		mercymenu = false
		enemies[1].Call("SetActive",true)
		enemies[sparepos].Call("SetActive",false)
	else
		mercymenu = true
		enemies[1].Call("SetActive",false)
		enemies[sparepos].Call("SetActive",true)
		for k,v in pairs(enemies) do
			if v["canspare"] ~= nil and v["canspare"] == true then
				enemies[sparepos]["name"] = "[starcolor:ffff00][color:ffff00]Spare[color:ffffff]"
				return
			else
				enemies[sparepos]["name"] = "[starcolor:ffffff]Spare"
			end
		end
	end
end
function EncounterStarting()
	Player.name = "SHIFTY"
    body = CreateSprite("azzy_body") ; body.Scale(2,2) ; body.MoveToAbs(-7,43)
	head = CreateSprite("face/normal") ; head.Scale(2,2) ; head.SetParent(body) ; head.MoveToAbs(-6,105)
	hp_back = CreateSprite("damage/hp_back")
	hp_back.MoveTo(313,260)
	hp_back.alpha = 0
	hp_front = CreateSprite("damage/hp_front")
	hp_front.SetParent(hp_back)
	hp_front.MoveTo(-50,0)
	hp_front.SetPivot(0,0.5)
	hp_front.alpha = 0
	SwapActiveEnemies(true)
end
function EnemyDialogueStarting()
	if phase == 1 and not GetGlobal("capture") then
		enemies[1]["currentdialogue"] = enemies[1]["sequential_dialogue"][enemies[1]["progress"]]
	end
end
function DefenseEnding()
	createmask = true
	if phase == 0 then
		encountertext = RandomEncounterText()
	end
end
spared = false
function HandleSpare()
	if phase == 0 and (enemies[1]["flirted"] or enemies[1]["insulted"] > 0) then
		enemies[2].Call("SwapItemsByNames","Pieghetti","Pie")
		enemies[2].Call("SwapItemsByNames","ChocoChip","Cookie")
		enemies[1]["currentdialogue"] = {enemies[1].Call("Voice","So, [w:5]you won't fight\nme?"), "[noskip][func:face,eyebrow][next]",
		enemies[1].Call("Voice","Heh, [w:5]I don't blame\nyou."),
		enemies[1].Call("Voice","Let's see how you\nhandle my fabled\nSTAR BLAZING."),
		enemies[1].Call("Voice","Behold!"), "[noskip][func:face,normal][next]"}
		nextwaves = {"star_blazing"}
	end
    State("ENEMYDIALOGUE")
end
function histrousle()
	enemies[1].Call("histrousle")
end