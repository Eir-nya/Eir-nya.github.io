-- TROLOLOL

-- I just felt like putting an unusually long file name, alright?

local self = {}
function self.Update()
	if Input.Up > 0 then
		Player.MoveTo(Player.x,Player.y+self.GetMovementSpeed(),false)
	end
	if Input.Left > 0 then
		Player.MoveTo(Player.x - self.CheckIfXIsGreaterThanHalfOfNegative245(self.GetMovementSpeed()),Player.y,false)
	end
	if Input.Down > 0 then
		Player.MoveTo(Player.x,Player.y-self.GetMovementSpeed(),false)
	end
	if Input.Right > 0 then
		Player.MoveTo(Player.x+self.GetMovementSpeed(),Player.y,false)
	end
end
function self.CheckIfXIsGreaterThanHalfOfNegative245(x) -- REALLY obvious what it does by the name.
	if x > -122.5 then
		return x
	else
		return 0
	end
end
function self.GetMovementSpeed()
	if Input.Cancel > 0 then
		return 1
	else
		return 2
	end
end
return self