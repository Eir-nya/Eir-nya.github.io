gametimer = 0
Encounter["attacking"] = true
timer = Encounter["wavetimer"]
Encounter["wavetimer"] = math.huge
Arena.ResizeImmediate(565,130)
Player.SetControlOverride(true) ; Player.MoveToAbs(-16,-16,true)
target = CreateProjectile("shoes/target",0,0)
damagenumbers = {}
bars = {}
dyingbars = {}
sprite = Encounter["enemies"][1]["sprite"]
local bar = CreateProjectile("shoes/choice_0",-Arena.width/2 - 10,0) ; table.insert(bars,bar)
local bar2 = CreateProjectile("shoes/choice_1",-Arena.width/2 - math.random(95,105),0) ; table.insert(bars,bar2)
local bar3 = CreateProjectile("shoes/choice_0",-Arena.width/2 - math.random(160,170),0) ; table.insert(bars,bar3)
errors = 0
deadcenter = 0
speed = 5.5
animationstarted = 0

if Encounter["enemies"][1]["maxhp"] == nil then
	Encounter["enemies"][1]["maxhp"] = Encounter["enemies"][1]["hp"]
end

damage = -1

sprite_x = Encounter["enemypositions"][1][1]
sprite_y = Encounter["enemypositions"][1][2] + 140--186

function Update()
	gametimer = gametimer + 1
	local pressed = false
	count = 0
	for k,v in pairs(bars) do
		if v.isactive then ; count = count + 1
			if Input.Confirm == 1 and pressed == false and v.x >= -Arena.width/2 - 10 and errors < 2 then
				pressed = true
				v.sprite.Set("shoes/choice_0")
				v.SetVar("pressed",true)
				v.sprite.alpha = 1
				if v.x > -100 and v.x < 40 then
					damage = damage + ((100 - math.abs(v.x))/6) + math.random(1,3)
				end
				if v.x <= -100 or v.x >= 40 then
					errors = errors + 1
					v.sprite.Set("shoes/white")
					v.sprite.color = {1.0,0.0,0.0}
					v.SetVar("scale",true)
				elseif (v.x > -100 and v.x < -5) or (v.x > 5 and v.x < 40) then
					v.sprite.Set("shoes/white")
					v.SetVar("scale",true)
					Audio.PlaySound("shoe_"..math.random(1,2))
					v.sprite.color = {0.0,162/255,232/255}
				elseif v.x >= -5 and v.x <= 5 then
					v.sprite.Set("shoes/white")
					v.SetVar("scale",true)
					deadcenter = deadcenter + 1
					Audio.PlaySound("shoe_"..math.random(1,2))
					v.sprite.color = {1.0,154/255,34/255}
				end
				table.remove(bars,k)
				table.insert(dyingbars,v)
			elseif errors == 2 and count == 1 then
				cleanup()
			end
			if not v.GetVar("pressed") then
				v.Move(speed*Time.mult,0)
				if v.x >= 40 and v.sprite.alpha > 0.2 then
					v.sprite.alpha = v.sprite.alpha - 0.075
				elseif v.sprite.alpha <= 0.2 then
					v.SetVar("move",speed)
					table.remove(bars,k)
					table.insert(dyingbars, v)
				end
			end
			if not v.GetVar("pressed") and gametimer%5 == 0 then
				if k%2 ~= 0 then
					v.sprite.Set("shoes/choice_"..gametimer%2)
				else
					v.sprite.Set("shoes/choice_"..(gametimer+5)%2)
				end
			end
		end
	end
	for k,v in pairs(dyingbars) do
		if v.isactive then
			count = count + 1
			if v.sprite.alpha > 0 then
				v.sprite.alpha = v.sprite.alpha - 0.05
			elseif v.sprite.alpha == 0 then
				v.Remove()
			end
			if v.GetVar("move") ~= nil then ; v.Move(speed*Time.mult,0) ; end
			if v.GetVar("scale") then
				v.sprite.Scale(1 + (1 - v.sprite.alpha), 1 + (1 - v.sprite.alpha))
			end
		end
	end
	if count == 0 and not animatingkick and damage > -1 then
		damage = math.ceil(damage + ((15 + (2*Player.lv)) - Encounter["enemies"][1]["def"]))
		if Encounter["enemies"][1]["hp"] - damage < 0 then
			-- damage = Encounter["enemies"][1]["hp"]
			Audio.Stop()
		end
		Encounter["enemies"][1].Call("HandleAttack",damage)
		maxhealth = Encounter["enemies"][1]["maxhp"]
		health = Encounter["enemies"][1]["hp"]
		newhealth = Encounter["enemies"][1]["hp"] - damage
		animatingkick = true
		animationstarted = gametimer
		Encounter["enemies"][1].Call("SetSprite","blank")
		enemysprite = CreateSprite("hurt")
		enemysprite.MoveTo(313,303)
		enemysprite.SendToBottom()
		foot = CreateProjectile("shoes/foot (1)",math.random(sprite_x-5,sprite_x+5),sprite_y+20)
		Encounter["hp_back"].alpha = 1
		Encounter["hp_front"].alpha = 1
		Audio.PlaySound("shoe_final")
		if deadcenter >= 2 then
			Audio.PlaySound("shoe_dazzle")
			foot.sprite.color = {1.0,(248/255),(112/255)}
		end
		local string2 = tostring(math.ceil(damage))
		local var = -15 ; var = var + (15 * #string2)
		for i=1,#string2 do
			local num = CreateProjectile("damage/"..string.sub(string2,i,i),(sprite_x + (i-1)*32) - var,sprite_y)
			num.sprite.color = {1.0,0.0,0.0}
			table.insert(damagenumbers,num)
		end
		
	elseif count == 0 and animatingkick and damage > -1 then
		if (gametimer - animationstarted)%5 == 0 and (gametimer - animationstarted) < 59 then
			enemysprite.MoveTo((math.sin(gametimer)*(60-(gametimer-animationstarted))/2)+313,303)
			local time = (gametimer-animationstarted)
			Encounter["hp_front"].xscale = (newhealth + (damage*(60-time))/maxhealth)/maxhealth
		elseif (gametimer - animationstarted) == 59 then
			enemysprite.MoveTo(313,303)
		elseif (gametimer - animationstarted) == 60 then
			cleanup()	
		end
		if (gametimer - animationstarted) == 10 then
			foot.sprite.Set("shoes/foot (2)")
		elseif (gametimer - animationstarted) == 12 then
			foot.sprite.Set("shoes/foot (3)")
		elseif (gametimer - animationstarted) == 15 then
			foot.sprite.Set("shoes/foot (4)")
		elseif (gametimer - animationstarted) == 17 then
			foot.sprite.Set("shoes/foot (5)")
		elseif (gametimer - animationstarted) == 20 then
			foot.sprite.Set("shoes/foot (6)")
		elseif (gametimer - animationstarted) == 22 then
			foot.Remove()
		end
		if (gametimer-animationstarted) < 60 then
			for k,v in pairs(damagenumbers) do
				if v.isactive then
					v.MoveTo(v.x,sprite_y + math.sin((gametimer-animationstarted)/20)*40)
				end
			end
		end
	elseif count == 0 and damage == -1 then
		Encounter["enemies"][1].Call("HandleAttack",-1)
		cleanup()
	end
end
function OnHit(bullet)
end
function cleanup()
	Player.sprite.alpha = 1
	for k,v in pairs(bars) do ; if v.isactive then ; v.Remove() ; end ; end
	for k,v in pairs(dyingbars) do ; if v.isactive then ; v.Remove() ; end ; end
	target.Remove()
	Encounter["enemies"][1].Call("SetSprite",sprite)
	if enemysprite ~= nil then ; enemysprite.Remove() ; end
	if damage == -1 then
		Encounter["damage_indicators"][#Encounter["damage_indicators"]+1] = CreateProjectile("damage/miss",sprite_x,sprite_y+100)
	end
	if newhealth ~= nil then
		Encounter["enemies"][1]["hp"] = newhealth
		if newhealth <= 0 then
			-- Encounter["damage_indicators"] = {}
			for k,v in pairs(damagenumbers) do
				if v.isactive then ; v.Remove() ; end
			end
			Encounter["enemies"][1].Call("OnDeath")
		end
		for k,v in pairs(damagenumbers) do
			if v.isactive then ; Encounter["damage_indicators"][#Encounter["damage_indicators"]+k] = v ; end
		end
	end
	Encounter["wavetimer"] = timer
	if Encounter["enemies"][1]["currentdialogue"] == nil then
		if Encounter["phase"] == 0 then
			Encounter["nextwaves"] = {"fire"}
		else
			Encounter["nextwaves"] = {Encounter["enemies"][1]["random_attacks"][math.random(#Encounter["enemies"][1]["random_attacks"])]}
		end
		State("DEFENDING")
	end
	State("ENEMYDIALOGUE")
end