if Arena.currentwidth >= 245 then ; Arena.Resize(245,130) ; elseif Arena.currentwidth < 245 then ; Arena.ResizeImmediate(245,130) ; end
gametimer = 0
fireballs = {}
function Update()
	gametimer = gametimer + 1
	if Arena.currentwidth == 245 and mask == nil then ; mask = CreateProjectileAbs("masks/245x130", 320, 240) ; end
	if gametimer%30 == 0 and gametimer < 170 then
		local num = math.random(75,95)
		if math.random(0,1) == 0 then ;	num = num * -1 ; end
		local fireball = CreateProjectile("attacks/fire1", num, math.random(-Arena.height/4,Arena.height/4) * 1.6)
		fireball.SetVar("side",0)
		if fireball.x > 0 then ; fireball.SetVar("side",1) ; fireball.sprite.Set("attacks/fire2") ; end
		fireball.SetVar("life",10)
		if mask ~= nil then ; mask.SendToTop() ; fireball.SendToBottom() ; end
		table.insert(fireballs,fireball)
	end
	for k,v in pairs(fireballs) do
		if v.isactive then
			local life = v.GetVar("life")
			if life > -10 then ; v.SetVar("life",life-1) ; end
			if life%5 > 2 and life >= 0 then ; v.sprite.alpha = 0
			elseif life%5 == 2 and life >= 0 then ; v.sprite.alpha = 1 ; Audio.PlaySound("flicker")
			elseif life == 0 and v.sprite.alpha ~= 1 then ; v.sprite.alpha = 1 ; end
			if life == -10 and v.GetVar("side") == 0 then ; v.Move(Time.mult*1.5,0)
			elseif life == -10 and v.GetVar("side") == 1 then ; v.Move(-Time.mult*1.5,0) ; end
			if v.x > Arena.width/2 + 4 or v.x < -Arena.width/2 - 4 then ; v.Remove() ; end
			if gametimer == 240 then
				v.Remove()
				if mask ~= nil then
					mask.Remove()
				end
			end
		end
	end
	if gametimer == 240 then
		EndWave()
	end
end
function OnHit(bullet)
	if bullet ~= mask then
		Encounter.Call("HurtPlayer",3)
		if Encounter["capturing"] ~= nil then
			for k,v in pairs(fireballs) do
				if v.isactive then ; v.Remove() ; end
			end
		end
	end
end