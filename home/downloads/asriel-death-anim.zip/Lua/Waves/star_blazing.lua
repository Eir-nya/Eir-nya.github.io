math.randomseed(Player.hp)
Encounter["wavetimer"] = math.huge
gametimer = 0
Arena.ResizeImmediate(245,130)
mask = CreateProjectile("masks/245x130overlay2",0,0)
Player.sprite.SendToTop()
mask.SetVar("safe",true)
smallstars = {}
bigstars = {}
sparks = {}
function Update()
	gametimer = gametimer + 1
	if gametimer%40 == 0 and #smallstars < 5 then
		local star = CreateProjectile("attacks/blazing/small"..math.random(1,2),math.random(350,500),math.random(350,500))
		star.SetVar("speedmult",math.random(1.0,1.5))
		star.SetVar("safe",true)
		star.SendToBottom()
		star.SetVar("rot_mult",math.random(1.75,4.50) - 2) ; if star.GetVar("rot_mult") == 0 then ; star.SetVar("rot_mult",-1.23) ; end
		star.SetVar("sparked",false)
		table.insert(smallstars,star)
		Audio.PlaySound("fall")
	elseif gametimer == 300 then
		local bigstar = CreateProjectile("attacks/blazing/big",-425,350)
		bigstar.sprite.rotation = -50
		bigstar.SendToBottom()
		Audio.PlaySound("fall2")
		table.insert(bigstars,bigstar)
	end
	for k,v in pairs(smallstars) do
		if v.isactive and not CheckIfInsideBox(v,"asdf") then
			v.sprite.rotation = v.sprite.rotation + v.GetVar("rot_mult")
			v.Move(-2*Time.mult*v.GetVar("speedmult"),-2*Time.mult*v.GetVar("speedmult"))
			if v.GetVar("sparked") == true then ; v.sprite.alpha = v.sprite.alpha - 0.15 ; end
		end
		if v.isactive and CheckIfInsideBox(v) and not CheckIfInsideBox(v, "ghjk") and not v.GetVar("sparked") then
			v.SetVar("sparked",true)
			for i=1,math.random(2,4) do
				local spark = CreateProjectile("attacks/blazing/scorchmed",v.x,v.y)
				spark.SetVar("velx_initial",(((i*math.random(4.5,5.5))-10)/5)/2.5)
				spark.SetVar("velx",spark.GetVar("velx_initial"))
				spark.SetVar("vely",0.12)
				spark.SetVar("life",0)
				table.insert(sparks,spark)
			end
			for i=1,math.random(1,3) do
				local spark = CreateProjectile("attacks/blazing/scorchsmall",v.x,v.y)
				spark.SetVar("velx_initial",(i*math.random(2.5,3.5))-4.5)
				spark.SetVar("velx",spark.GetVar("velx_initial"))
				spark.SetVar("vely",0.48)
				spark.SetVar("life",0)
				table.insert(sparks,spark)
			end
			Audio.PlaySound("heartbeatbreaker")
		elseif v.isactive and CheckIfInsideBox(v, "lmno") then
			v.Remove()
		end
	end
	for k,v in pairs(sparks) do
		if v.isactive and v.absy >= -2 then
			local velx = v.GetVar("velx")
			local vely = v.GetVar("vely")
			local life = v.GetVar("life")
			local num = 0.008
			life = life + 0.001
			if velx < 0 then ; num = num * -1 ; end
			vely = vely - 0.04
			v.Move(velx*Time.mult,vely*Time.mult)
			v.SetVar("velx",velx)
			v.SetVar("vely",vely)
			v.sprite.Scale((1 + math.abs(velx))/40, (1 + math.abs(vely))/16)
			v.sprite.rotation = (v.GetVar("velx_initial")*10) + life
		elseif v.isactive and v.absy < -2 then
			v.Remove()
		end
	end
	for k,v in pairs(bigstars) do
		if v.isactive and v.GetVar("safe") == nil then
			if not CheckIfInsideBox(v,"??") then
				v.sprite.rotation = v.sprite.rotation + 1
				v.Move(Time.mult,-Time.mult)
			elseif CheckIfInsideBox(v,"??") and v.GetVar("life") == nil then ; v.SetVar("life",10) ; Audio.PlaySound("heartbeatbreaker")
			elseif v.GetVar("life") ~= nil and v.GetVar("life") > 0 and v.GetVar("life") ~= 5 then
				v.SetVar("life",v.GetVar("life") - 0.5)
			elseif v.GetVar("life") == 5 then ; Audio.PlaySound("heartsplosion") ; v.SetVar("life",v.GetVar("life") - 0.5)
			elseif v.GetVar("life") == 0 then ; v.SetVar("life",-1) ; musicchange = 0.75
			elseif v.GetVar("life") ~= nil and v.GetVar("life") <= -1 and v.GetVar("life") > -20 then
				v.SetVar("life",v.GetVar("life") - 0.5)
				v.sprite.alpha = v.sprite.alpha - 0.05
				if gametimer%8 == 0 then
					for i=1,5 do
						local spark = CreateProjectile("attacks/blazing/scorchbig",v.x+(i-3),v.y+8)
						spark.SetVar("velx_initial",i/math.random(2,4))
						spark.SetVar("velx",spark.GetVar("velx_initial"))
						spark.SetVar("vely",2)
						spark.SetVar("life",0)
						table.insert(sparks,spark)
					end
				end
				if gametimer%12 == 0 then
					for i=1,6 do
						local spark = CreateProjectile("attacks/blazing/scorchsmall",v.x+(i-3),v.y+8)
						spark.SetVar("velx_initial",i/math.random(4,6))
						spark.SetVar("velx",spark.GetVar("velx_initial"))
						spark.SetVar("vely",2)
						spark.SetVar("life",0)
						table.insert(sparks,spark)
					end
				end
			elseif v.GetVar("life") == -20 then
				local count = 0
				for l,w in pairs(sparks) do
					if w.isactive then ; count = count + 1 ; end
				end
				if count == 0 then
					Encounter["phase"] = 1
					Encounter["create_mask_timer"] = 0
					mask.Remove()
					Encounter["enemies"][1]["attacked"] = true ; Encounter["enemies"][1]["can_flirt"] = false ; Encounter["enemies"][1]["can_insult"] = false
					local nummy = 16
					if Encounter["enemies"][1]["flirted"] == true then
						nummy = 17
					end
					Encounter["enemies"][1].Call("insert_randomtext",nummy,{"What."})
					Encounter["enemies"][1].Call("insert_randomtext",nummy,{"Asriel is sparing you."})
					State("ENEMYDIALOGUE")
				end
			end
		end
	end
	if musicchange ~= nil then
		musicchange = musicchange - 0.005
		Audio.Volume(musicchange)
	end
end
function CheckIfInsideBox(bullet, specific)
	if specific == nil then
		if bullet.x <= Arena.width/2 and bullet.x >= -Arena.width/2 and bullet.y <= Arena.height/2 and bullet.y >= -Arena.height/2 then
			return true
		else
			return false
		end
	elseif specific ~= nil and specific ~= "??" then
		if bullet.y + bullet.sprite.height < Arena.height/2 and bullet.y - bullet.sprite.height > -Arena.height/2 then
			if bullet.x + bullet.sprite.width > -Arena.width/2 and bullet.x - bullet.sprite.width < Arena.width/2 then
				return true
			else
				return false
			end
		else
			return false
		end
	elseif specific == "??" then
		if bullet.x + bullet.sprite.width/3 >= -Arena.width/2 and bullet.y - bullet.sprite.height/3 <= Arena.height/2 then ; return true ; else ; return false
		end
	end
end
function OnHit(bullet)
	if bullet.GetVar("safe") == nil then
		Encounter.Call("HurtPlayer",3)
		if Encounter["capturing"] ~= nil then
			for k,v in pairs(smallstars) do
				if v.isactive then
					v.Remove()
				end
			end
			for k,v in pairs(sparks) do
				if v.isactive then
					v.Remove()
				end
			end
			for k,v in pairs(bigstars) do
				if v.isactive then
					v.Remove()
				end
			end
		end
	end
end