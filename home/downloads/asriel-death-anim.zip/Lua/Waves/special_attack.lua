Arena.ResizeImmediate(245,130)
mask = CreateProjectile("masks/325x130",0,0)
mask2 = CreateProjectile("masks/325x130rightside",41.5 + Arena.currentwidth/2,0)
Arena.Resize(325,130)
Player.SetControlOverride(true)
movement = require "DefaultMovementButRecreatedInSuchAWayThatThePlayerCannotTouchTheLeftSideOfTheBattleBox"
Encounter["head"].SetAnimation({"face/shock_look"})
function Update()
	movement.Update()
	-- DEBUG(Player.x)
	mask2.MoveTo(mask2.sprite.width/2 + Arena.currentwidth/2,0)
end ; function OnHit(bullet) ; end