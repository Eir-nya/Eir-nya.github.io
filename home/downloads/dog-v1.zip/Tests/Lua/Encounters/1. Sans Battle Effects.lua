-- A basic encounter script skeleton you can copy and modify for your own creations.

music = "megalovania" --Always OGG or WAV. Extension is added automatically. Remove the first two lines for custom music.
encountertext = "Poseur strikes a pose!" --Modify as necessary. It will only be read out in the action select screen.
nextwaves = {"bullettest_chaserorb"}
wavetimer = 4.0
arenasize = {155, 130}

enemies = {
"poseur_maxdef"
}

enemypositions = {
{0, 0}
}

-- A custom list with attacks to choose from. Actual selection happens in EnemyDialogueEnding(). Put here in case you want to use it.
possible_attacks = {"bullettest_bouncy", "bullettest_chaserorb", "bullettest_touhou"}

gametimer = -1
bones = {}
side_bones = {}
phase = 0
TIME_1 = 15
TIME_2 = 65
TIME_3 = 70
FIGHT = 145
ACT = 299
ITEM = 453
MERCY = 607
height = -85
timetocreate = 28
createmore = true

SetGlobal("dodge_x",330)
SetGlobal("dodge_y",346)
SetGlobal("spritey","poseur")
thetime = 0
dodging = 0
lastsprite = poseur
confirm_level = 0
mode = nil
zlock = 0
amount = 0.5 -- 0.15
time1 = 20 -- 50
time2 = 127 -- 102
time3 = 149
def_velx = -12 -- -7.5

--DEBUG("amount: "..amount.." time1: "..time1.." time2: "..time2.." time3: "..time3.." def_velx: "..def_velx)

function Update()
	gametimer = gametimer + 1
	
	if GetGlobal("spritey") ~= nil then
		if GetGlobal("spritex") ~= nil then
			SetGlobal("spritex",nil)
		else
			enemies[1].SetSprite(GetGlobal("spritey"))
		end
		lastsprite = GetGlobal("spritey")
		SetGlobal("spritey",nil)
	end
	if dodgesprite ~= nil and dodging ~= 1 then
		dodgesprite.Remove()
	end
	--[[
	VALUES:
	absx:
	48 - FIGHT option
	202 - ACT option
	361 - ITEM option
	515 - MERCY option
	65 - COLLUMN 1
	321 - COLLUMN 2
	absy:
	25 - FIGHT/ACT/ITEM/MERCY
	190 - ROW 1
	160 - ROW 2
	130 - ROW 3
	]]--
	if Input.Confirm == 1 and confirm_level < 3 and thetime ~= -1 then
		confirm_level = confirm_level + 1
	end
	if Input.Cancel == 1 and confirm_level > 0 and zlock == 0 then
		confirm_level = confirm_level - 1
	end
	if Input.Confirm == 1 and Input.Cancel == 1 and confirm_level < 3 then
		confirm_level = confirm_level + 1
	end
	if confirm_level == 0 and mode ~= nil then
		--Player went back to FIGHT/ACT/ITEM/MERCY
		mode = nil
	end
	if Player.absx == 48 and confirm_level == 1 then
		--Player has selected FIGHT
		mode = "FIGHT"
	elseif Player.absx == 202 and confirm_level == 1 then
		--Player has selected ACT
		mode = "ACT"
	elseif Player.absx == 361 and confirm_level == 1 then
		--Player has selected ITEM
		mode = "ITEM"
	elseif Player.absx == 515 and confirm_level == 1 then
		--Player has selected MERCY
		mode = "MERCY"
	end
	
	if dodging == 1 then
		local velx = dodgesprite.GetVar("velx")
		if thetime >= 0 then
			thetime = thetime + 1
		end
		if thetime <= time1 then
			velx = velx + amount
			dodgesprite.Move(velx,0)
		elseif thetime == (time1 + 1) then
			velx = 0
		elseif thetime >= time2 and thetime < time3 then
			velx = velx + amount
			dodgesprite.Move(velx,0)
		elseif thetime == time3 then
			if dodgesprite ~= nil then
				enemies[1].SetSprite(lastsprite)
				dodgesprite.Remove()
				--confirm_level = 0
				thetime = -1
				State("ENEMYDIALOGUE")
			end
		end
		dodgesprite.SetVar("velx",velx)
	end
	
	if mode == "FIGHT" and confirm_level == 2 then
		--Player has chosen an enemy to FIGHT
		createmore = false
		zlock = 1
	end
	
	if mode == "FIGHT" and confirm_level == 3 then
		--Player has FIGHTed
		if dodging == 0 and thetime ~= -1 then
			dodging = 1
			--dodgesprite.Remove()
			dodgesprite = CreateProjectileAbs(lastsprite,GetGlobal("dodge_x"),GetGlobal("dodge_y"))
			dodgesprite.SetVar("velx",def_velx)
			enemies[1].SetSprite("blank")
		end
	end
	if mode == "ACT" and confirm_level == 3 then
		--Player has ACTed
		createmore = false
	end
	if mode == "ITEM" and confirm_level == 3 then
		--Player has ITEMed
		createmore = false
	end
	if mode == "MERCY" and Player.absy == 190 and confirm_level == 2 then
		--Player has SPAREed
		createmore = false
	end
	if mode == "MERCY" and Player.absy == 160 and confirm_level == 2 then
		--Player has FLEEd
		createmore = false
		BattleDialog({"You can't run from fate.","[noskip][func:State,ENEMYDIALOGUE]"})
	end
	
	for i=1,#side_bones do
		if side_bones[i] ~= nil then
			local bone = side_bones[i]
			local time = bone.GetVar("time")
			if gametimer%5 == 0 then
				time = time - 0.51
			end
			bone.SetVar("time",time)
			bone.Move(time,0)
			if bone.absx < -10 then
				bone.Remove()
				table.remove(side_bones,i)
			end
		end
	end
	for i=1,#bones do
		if bones[i] ~= nil then
			local bone = bones[i]
			bone.SetVar("lifetime",bone.GetVar("lifetime") + 1)
			if bone.GetVar("lifetime") < TIME_1 then
				bone.Move(0,8)
			elseif bone.GetVar("lifetime") >= TIME_1 and bone.GetVar("lifetime") < TIME_2 then
				bone.Move(-2.5,0)
			elseif bone.GetVar("lifetime") >= TIME_2 and bone.GetVar("lifetime") < TIME_3 then
				bone.Move(0,-8)
			elseif bone.GetVar("lifetime") == TIME_3 then
				bone.Remove()
				table.remove(bones,i)
			end
		end
	end
	if gametimer%timetocreate == 0 and phase == 0 and #bones < 4 and createmore == true then
		local bone = CreateProjectileAbs("bone",FIGHT,height)
		bone.SetVar("lifetime", 0)
		table.insert(bones,bone)
		local bone2 = CreateProjectileAbs("bone",ITEM,height)
		bone2.SetVar("lifetime", 0)
		table.insert(bones,bone2)
		phase = 1
	elseif gametimer%timetocreate == 0 and phase == 1 and #bones < 4 and createmore == true then
		local bone3 = CreateProjectileAbs("bone",ACT,height)
		bone3.SetVar("lifetime", 0)
		table.insert(bones,bone3)
		local bone4 = CreateProjectileAbs("bone",MERCY,height)
		bone4.SetVar("lifetime", 0)
		table.insert(bones,bone4)
		phase = 0
	end
	if #side_bones == 0 and createmore == true and gametimer%15 == 0 then
		local side_bone = CreateProjectileAbs("bone",-10,190)
		side_bone.SetVar("time",4)
		table.insert(side_bones,side_bone)
	end
end

function OnHit(bullet)
	if createmore == true then
		Player.Hurt(1,0)
	end
end

function EncounterStarting()
    -- If you want to change the game state immediately, this is the place.
	--[[
	local alphabet = {"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"}
	local name = alphabet[math.random(#alphabet)]..alphabet[math.random(#alphabet)]..alphabet[math.random(#alphabet)]
	name = name..alphabet[math.random(#alphabet)]..alphabet[math.random(#alphabet)]..alphabet[math.random(#alphabet)]
	Player.name = name
	]]--
	Player.name = "Chara"
	Player.lv = 20
	Player.hp = 99
end

function EnemyDialogueStarting()
    -- Good location for setting monster dialogue depending on how the battle is going.
    -- Example: enemies[1].SetVar('currentdialogue', {"Check it\nout!"})   See documentation for details.
	zlock = 0
	thetime = 0
	confirm_level = 0
	dodging = 0
end

function EnemyDialogueEnding()
    -- Good location to fill the 'nextwaves' table with the attacks you want to have simultaneously.
    -- This example line below takes a random attack from 'possible_attacks'.
    nextwaves = { possible_attacks[math.random(#possible_attacks)] }
end

function DefenseEnding() --This built-in function fires after the defense round ends.
    encountertext = RandomEncounterText() --This built-in function gets a random encounter text from a random enemy.
	createmore = true
	confirm_level = 0
end

function HandleSpare()
     State("ENEMYDIALOGUE") --By default, pressing spare only spares the enemies but stays in the menu. Changing state happens here.
end

function HandleItem(ItemID)
    BattleDialog({"Selected item " .. ItemID .. "."})
end