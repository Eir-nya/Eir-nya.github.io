Encounter["wavetimer"] = math.huge
Arena.ResizeImmediate(174, 130)
-- Preload audio
Audio.Pause()
NewAudio.CreateChannel("temp")
NewAudio.PlayMusic("temp", "../apple/apple")

-- Heart toggle
heartColorToggle = false
heartColorCooldown = 0
heartColorCooldownMax = 11 / 60

function SetHeartMode(mode)
    heartColorToggle = mode
    heartColorCooldown = heartColorCooldownMax

    overlay.color = not mode and {0, 0, 0} or {1, 1, 1}

    Player.Hurt(0, 0, false, false)
    Player.Hurt(0, 6/30, false, false)
end

-- Heart overlay and outline
overlay = CreateSprite("ut-heart", "Top")
overlay.color = Player.sprite.color
overlay.MoveToAbs(-16, -16)
outline = CreateSprite("ut-heart-outline", "Top")
outline.color = Player.sprite.color
outline.MoveToAbs(-16, -16)
SetHeartMode(false)

-- Apple functionality
appleLast = 1
appleLength = 6516
local preloader = CreateSprite("empty")
function NumToFileName(num)
    local name = tostring(num)
    if #name < 4 then
        while #name < 4 do
            name = "0" .. name
        end
    end
    name = "../apple/apple" .. name
    return name
end
function Preload(num)
    preloader.Set(NumToFileName(num))
    preloader.Set("empty")
end

local appleBul = CreateProjectile("empty", 0, 0)
appleBul.sprite.Set("empty")
appleBul.ppcollision = true

function Update()
    -- overlay and outline
    overlay.MoveToAbs(Player.absx, Player.absy)
    outline.MoveToAbs(Player.absx, Player.absy)

    if Player.isHurting then
        local col = 0.5--(math.sin(math.rad(Time.time)) / 4) + 0.5
        outline.color = {col * Player.sprite.color[1], col * Player.sprite.color[2], col * Player.sprite.color[3]}
    else
        outline.color = Player.sprite.color
    end

    -- controls
    if heartColorCooldown > 0 then
        heartColorCooldown = heartColorCooldown - Time.dt
    end
    if Input.Confirm == 1 and heartColorCooldown <= 0 then
        SetHeartMode(not heartColorToggle)
    end

    -- hurt
    local touching = appleBul.isColliding()
    if touching ~= heartColorToggle then
        if (math.floor(Player.hp * 100) / 100) - 0.06 <= 0 and not Player.isHurting then
            OnDeath()
            Player.hp = 0
            return
        end
        Player.Hurt(0.06, 2/30, true, true)
    end

    -- played time
    local playedTime = NewAudio.GetPlayTime("temp")
    playedTime = math.ceil(playedTime * 30)
    playedTime = math.max(playedTime, 1)
    playedTime = math.min(playedTime, appleLength)

    appleBul.sprite.Set(NumToFileName(playedTime))

    -- clear previous frames
    for i = appleLast, math.max(playedTime - 1, 1) do
        UnloadSprite(NumToFileName(i))
        appleLast = i
    end

    -- preload
    for i = playedTime, math.min(playedTime, appleLength) do
        Preload(i)
    end

    if NewAudio.isStopped("temp") then
        overlay.Remove()
        outline.Remove()
        preloader.Remove()
        NewAudio.DestroyChannel("temp")
        Audio.Unpause()
        EndWave()
    end
end

function OnHit(bullet) end

function OnDeath()
    NewAudio.Stop("temp")
    NewAudio.DestroyChannel("temp")
end
