local self = {} ; self.move = false ; self.movecounter = 0 ; self.movespeed = 8.3
self.vertbar_r = CreateProjectile("resizing_mask_side",285,0) ; self.vertbar_r.sprite.Set("resizing_mask_side") ; self.vertbar_r.sprite.xscale = 1.25
self.vertbar_r.sprite.color = {0.0,0.0,0.0} ; self.vertbar_r.SetVar("safe",true)
self.vertbar_l = CreateProjectile("resizing_mask_side",-285,0) ; self.vertbar_l.sprite.Set("resizing_mask_side") ; self.vertbar_l.sprite.xscale = 1.25
self.vertbar_l.sprite.color = {0.0,0.0,0.0} ; self.vertbar_l.SetVar("safe",true)
self.fakemovecounter = -1
function self.Update()
	if self.move then
		if self.movecounter < 24 then
			self.movecounter = self.movecounter + 1
			self.vertbar_r.Move(-self.movespeed*Time.mult,0)
			self.vertbar_l.Move(self.movespeed*Time.mult,0)
		elseif self.movecounter == 24 then
			self.vertbar_l.MoveTo(-80,0)
			self.vertbar_r.MoveTo(80,0)
		end
	elseif not self.move then
		if self.movecounter > 0 then
			self.movecounter = self.movecounter - 1
			self.vertbar_r.Move(self.movespeed*Time.mult,0)
			self.vertbar_l.Move(-self.movespeed*Time.mult,0)
		elseif self.movecounter == 0 then
			self.vertbar_r.MoveTo(285,0)
			self.vertbar_l.MoveTo(-285,0)
		end
	end
	if self.fakemovecounter > 0 then
		self.fakemovecounter = self.fakemovecounter - 1
	elseif self.fakemovecounter == 0 then
		self.fakemask.Remove()
		self.fakemovecounter = -1
	end
	-- self.vertbar_l.sprite.color = {math.sin(2+Time.time*4)/2 + 0.5,math.sin(3+Time.time*4)/2 + 0.5,math.sin(1+Time.time*4)/2 + 0.5}
	-- self.vertbar_r.sprite.color = {self.vertbar_l.sprite.color[1],self.vertbar_l.sprite.color[2],self.vertbar_l.sprite.color[3]}
end
return self