local cancel = Input.Cancel
local x = 0
local y = 0
if Input.Up > 0 then
	if cancel > 0 then
		y = 1
	else
		y = 2
	end
	-- if touch_box and ((Player.absx > 24 and Player.absx < 615) and (Player.absy + y > 82 and Player.absy + y < 238)) then
		-- y = 0
	-- end
end
if Input.Down > 0 then
	if cancel > 0 then
		y = -1
	else
		y = -2
	end
	-- if touch_box and ((Player.absx > 24 and Player.absx < 615) and (Player.absy + y > 82 and Player.absy + y < 238)) then
		-- y = 0
	-- end
end
if Input.Right > 0 then
	if cancel > 0 then
		x = 1
	else
		x = 2
	end
	-- if touch_box and ((Player.absy > 82 and Player.absy < 238) and (Player.absx + x > 24 and Player.absx + x < 615)) then
		-- x = 0
	-- end
end
if Input.Left > 0 then
	if cancel > 0 then
		x = -1
	else
		x = -2
	end
	-- if touch_box and ((Player.absy > 82 and Player.absy < 238) and (Player.absx + x > 24 and Player.absx + x < 615)) then
		-- x = 0
	-- end
end
if Player.absx + x < 8 or Player.absx + x > 632 then
	x = 0
end
if Player.absy + y < 8 or Player.absy + y > 472 then
	y = 0
end
Player.MoveToAbs(Player.absx + x,Player.absy + y,true)