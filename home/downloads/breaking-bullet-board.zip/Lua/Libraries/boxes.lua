local self = {}
function self.CreateBoxes()
	self.mask = CreateProjectileAbs("mask",320,240)
	self.mask.SetVar("safe",true)
    if touch_box then
		self.mask.sprite.Set("mask")
	end
	self.fightbt = CreateProjectileAbs("UI/Buttons/fightbt_0",87,27)
	self.fightbt.SetVar("safe",true)
	self.fightbt.SetVar("icon","fightbt")
	self.actbt = CreateProjectileAbs("UI/Buttons/actbt_0",240,27)
	self.actbt.SetVar("safe",true)
	self.actbt.SetVar("icon","actbt")
	self.itembt = CreateProjectileAbs("UI/Buttons/itembt_0",400,27)
	self.itembt.SetVar("safe",true)
	self.itembt.SetVar("icon","itembt")
	self.mercybt = CreateProjectileAbs("UI/Buttons/mercybt_0",555,27)
	self.mercybt.SetVar("safe",true)
	self.mercybt.SetVar("icon","mercybt")
	Player.sprite.SendToTop()
end

function self.CheckTouchingBox(box)
	if Player.absx + Player.sprite.width/2 >= box.absx - box.sprite.width/2 and Player.absx - Player.sprite.width/2 <= box.absx + box.sprite.width/2 and Player.absy + Player.sprite.height/2 >= box.absy - box.sprite.height/2 and Player.absy - Player.sprite.height/2 <= box.absy + box.sprite.height/2 and not box.GetVar("hover") then
		box.SetVar("hover",true)
		box.sprite.Set("UI/Buttons/"..box.GetVar("icon").."_1")
		Audio.PlaySound("menumove")
	elseif (Player.absx + Player.sprite.width/2 < box.absx - box.sprite.width/2 or Player.absx - Player.sprite.width/2 > box.absx + box.sprite.width/2 or Player.absy + Player.sprite.height/2 < box.absy - box.sprite.height/2 or Player.absy - Player.sprite.height/2 > box.absy + box.sprite.height/2) and box.GetVar("hover") then
		box.SetVar("hover",nil)
		box.sprite.Set("UI/Buttons/"..box.GetVar("icon").."_0")
	end
end

function self.TouchingButton()
	if self.fightbt.GetVar("hover") or self.actbt.GetVar("hover") or self.itembt.GetVar("hover") or self.mercybt.GetVar("hover") then
		return true
	else
		return false
	end
end

function self.IsTouchingButton(button)
	if button.GetVar("hover") then
		return true
	else
		return false
	end
end

function self.DimBoxes()
	self.CheckTouchingBox(self.fightbt)-- fightbt.SetVar("hover",nil)
	self.CheckTouchingBox(self.actbt)-- actbt.SetVar("hover",nil)
	self.CheckTouchingBox(self.itembt)-- itembt.SetVar("hover",nil)
	self.CheckTouchingBox(self.mercybt)-- mercybt.SetVar("hover",nil)
end

return self