local self = {}
self.bullets = {}
self.timer = 0
self.phase = 0
self.createmore = true
function self.Update()
	self.timer = self.timer + 1
	if self.timer == 240 then
		self.timer = 0
		self.phase = math.random(0,2)
	end
	if self.createmore then
		if self.phase == 0 then
			if self.timer%15 == 0 then
				local num = math.random(Player.absx - 20,Player.absx + 20)
				while num < 40 do
					num = num + 1
				end
				while num > 592 do
					num = num - 1
				end
				local bullet = CreateProjectileAbs("bullet",num,480)
				bullet.SetVar("velx",(num - Player.absx)/16)
				bullet.SetVar("vely",0)
				bullet.SetVar("bounces",0)
				bullet.SetVar("mode",self.phase)
				table.insert(self.bullets,bullet)
			end
		elseif self.phase == 1 then
			if self.timer%15 == 0 then
				for i=1,3 do
					local bullet = CreateProjectileAbs("bullet",math.random(0,638),-8)
					bullet.SetVar("vely",3)
					bullet.SetVar("mode",self.phase)
					table.insert(self.bullets,bullet)
				end
			end
		elseif self.phase == 2 then
			if not GetGlobal("pattern_bullets") then
				local spawnpos = {{0,480}, {640,480}, {640,0}, {0,0}, {-320,240}, {320,480+240}, {640+320,240}, {320,-240}}
				for i=1,8 do
					--YES, I took this code from bullettest_chaserorb. Please don't hate me for this. It is just a simple test.
					SetGlobal("pattern_bullets",true)
					local bullet = CreateProjectileAbs("bullet",spawnpos[i][1],spawnpos[i][2])
					bullet.SetVar("xspeed",0)
					bullet.SetVar("yspeed",0)
					bullet.SetVar("mult",-50)
					bullet.SetVar("life",0)
					bullet.SetVar("mode",self.phase)
					table.insert(self.bullets,bullet)
				end
			end
		end
	end
	local count = 0
	for k,v in pairs(self.bullets) do
		if v.isactive then
			count = count + 1
			if v.GetVar("mode") == 0 then
				local vely = v.GetVar("vely")
				v.SetVar("vely",v.GetVar("vely") - 0.12)
				v.Move(v.GetVar("velx")*Time.mult,v.GetVar("vely")*Time.mult)
				if v.absy-v.GetVar("vely") <= v.sprite.height/2 and v.GetVar("bounces") < 3 then
					v.SetVar("vely",6)
					v.SetVar("bounces",v.GetVar("bounces") + 1)
					v.Move(0,((v.sprite.height/2) - v.absy)*Time.mult)
				end
				if v.absx <= -v.sprite.width/2 or v.absx >= 632 + v.sprite.width/2 or (v.absy <= -v.sprite.height/2 and v.GetVar("bounces") == 3) then
					v.Remove()
				end
			elseif v.GetVar("mode") == 1 then
				local vely = v.GetVar("vely")
				v.SetVar("vely",vely - 0.06)
				v.Move(0,vely*Time.mult)
				if v.absy < -v.sprite.height/2 then
					v.Remove()
				end
			elseif v.GetVar("mode") == 2 then
				local mult = v.GetVar("mult")
				local life = v.GetVar("life")
				local xspeed = v.GetVar("xspeed")
				local yspeed = v.GetVar("yspeed")
				local xdifference = Player.x - v.x
				local ydifference = Player.y - v.y
				v.Move(xspeed, yspeed)
				v.SetVar("xspeed",-(xspeed/2 + xdifference/mult))
				v.SetVar("yspeed",-(yspeed/2 + ydifference/mult))
				v.SetVar("life",life + 1)
				if v.GetVar("life") >= 240 and v.GetVar("life") < 280 then
					v.SetVar("xspeed",v.GetVar("xspeed")*-1)
					v.SetVar("yspeed",v.GetVar("yspeed")*-1)
					v.SetVar("mult",mult + 1)
				elseif v.GetVar("life") == 280 then
					if GetGlobal("pattern_bullets") then ; SetGlobal("pattern_bullets",nil) ; end
					v.Remove()
				end
			end
			if not self.createmore and not v.GetVar("safe") then
				v.SetVar("safe",true)
			end
		end
	end
	if count == 0 and #self.bullets > 0 then
		self.bullets = {}
	end
end
return self