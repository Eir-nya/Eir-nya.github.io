function Update()
	State("ACTIONSELECT")
	Player.MoveToAbs(320,160,true)
end