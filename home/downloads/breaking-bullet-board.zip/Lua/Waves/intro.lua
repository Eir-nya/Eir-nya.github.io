Audio.Stop()
bg = CreateProjectileAbs("white",320,240)
bg.sprite.color = {0.0,0.0,0.0}
Arena.ResizeImmediate(565,130)
Player.SetControlOverride(true)
Player.MoveToAbs(320,140,true)
gametimer = 0
intro_mask = CreateProjectileAbs("intro_mask",320,240)
intro_mask.SendToBottom()
border = {}
function Update()
	gametimer = gametimer + 1
	if bg.sprite.alpha > 0 then
		bg.sprite.alpha = bg.sprite.alpha - 0.01
	end
	if gametimer == 129 then
		white = CreateProjectileAbs("white",320,240)
		white.sprite.alpha = 0
	elseif gametimer >= 130 and gametimer < 150 and white.sprite.alpha < 1 then
		white.sprite.alpha = white.sprite.alpha + 0.05
	elseif gametimer >= 250 and white.isactive and white.sprite.alpha > 0 then
		white.sprite.alpha = white.sprite.alpha - 0.02
		if white.sprite.alpha == 0 then
			white.Remove()
		end
	end
	if gametimer == 150 then
		Audio.PlaySound("slice")
		intro_mask.sprite.Set("intro_mask_2")
		left = CreateProjectile("intro_mask_vert",-67,-15)
		left.sprite.Set("intro_mask_vert")
		right = CreateProjectile("intro_mask_vert",68,-15)
		right.sprite.Set("intro_mask_vert")
		top = CreateProjectile("intro_mask_horiz",0,37)
		top.sprite.Set("intro_mask_horiz")
		bottom = CreateProjectile("intro_mask_horiz",0,-68)
		bottom.sprite.Set("intro_mask_horiz")
		bottom.sprite.rotation = 180
	elseif gametimer == 210 then
		Audio.PlaySound("big_crack")
	elseif gametimer == 300 then
		Audio.PlaySound("big_hit")
		top.sprite.Set("intro_mask_horiz_crack")
		bottom.sprite.Set("intro_mask_horiz_crack")
	end
	if gametimer >= 400 and gametimer < 450 then
		local shake = math.random(((gametimer-400)/450)*2)
		left.MoveTo(-67 + shake,-15 + shake)
		right.MoveTo(68 + shake,-15 - shake)
		top.MoveTo(0 + shake,37 + shake)
		bottom.MoveTo(0 + shake,-68 - shake)
	elseif gametimer == 450 then
		left.SetVar("velx",-1)
		left.SetVar("vely",1)
		left.SetVar("rotspeed",0.5)
		right.SetVar("velx",1.5)
		right.SetVar("vely",0.8)
		right.SetVar("rotspeed",-1)
		top.SetVar("velx",1)
		top.SetVar("vely",1)
		top.SetVar("rotspeed",-0.5)
		bottom.SetVar("velx",0)
		bottom.SetVar("vely",0)
		bottom.SetVar("rotspeed",-0.5)
		table.insert(border,left)
		table.insert(border,top)
		table.insert(border,right)
		table.insert(border,bottom)
		Audio.PlaySound("big_break")
	elseif gametimer > 450 and gametimer < 600 then
		for k,v in pairs(border) do
			if v.isactive then
				v.Move(v.GetVar("velx")*Time.mult,v.GetVar("vely")*Time.mult)
				local num = 1
				if v.GetVar("velx") < 0 then ; num = -1 ; end
				v.SetVar("velx",(math.abs(v.GetVar("velx")) - 0.005)*num)
				v.SetVar("vely",v.GetVar("vely") - 0.05)
				v.sprite.rotation = v.sprite.rotation + v.GetVar("rotspeed")
				if v.absy < -55 then
					v.Remove()
				end
			end
		end
	elseif gametimer == 600 then
		Audio.PlaySound("neo_ikarus_intro")
	elseif gametimer == 670 then
		Encounter["nextwaves"] = {}
		bg.Remove()
		intro_mask.Remove()
		local x = Player.absx
		local y = Player.absy
		Audio.LoadFile("neo_ikarus")
		Encounter.Call("CreateBoxes")
		State("ACTIONSELECT")
		Player.MoveToAbs(x,y,true)
	end
end
function OnHit(bullet)
end