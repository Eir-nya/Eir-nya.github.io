currentstate = "NONE"
encountertext = "Poseur strikes a pose!"
nextwaves = {"intro"}
wavetimer = math.huge
arenasize = {155, 130}

enemies = {
"poseur", "actmenuswitch"
}

enemypositions = {
{0, 0}, {0, 0}
}

action = ""
boxes_enable = false
button_cooldown = 0
fake_act_menu = false
function Update()
	if button_cooldown > 0 then
		button_cooldown = button_cooldown - 1
	elseif button_cooldown == 0 then
		button_cooldown = -1
		State(action)
	end
	if currentstate == "ACTIONSELECT" and boxes_enable then
		State("NONE")
		DefenseEnding()
	elseif currentstate == "NONE" and boxes_enable then
		require "Libraries/moving_menu"
		boxes.CheckTouchingBox(boxes.fightbt)
		boxes.CheckTouchingBox(boxes.actbt)
		boxes.CheckTouchingBox(boxes.itembt)
		boxes.CheckTouchingBox(boxes.mercybt)
		if Input.Confirm == 1 then
			x = Player.absx
			y = Player.absy
			if boxes.IsTouchingButton(boxes.fightbt) then
				action = "ENEMYSELECT"
			elseif boxes.IsTouchingButton(boxes.actbt) then
				action = "ACTMENU"
				fake_act_menu = true
			elseif boxes.IsTouchingButton(boxes.itembt) then
				action = "ITEMMENU"
			elseif boxes.IsTouchingButton(boxes.mercybt) then
				action = "MERCYMENU"
			end
			if boxes.TouchingButton() then
				Audio.PlaySound("menuconfirm")
				button_cooldown = 1
			end
		end
	end
	if currentstate == "ACTMENU" and Input.Cancel == 1 then
		if fake_act_menu then
			enemies[1].Call("SetActive",true)
			enemies[2].Call("SetActive",false)
			State("ACTIONSELECT")
			Player.MoveToAbs(x,y,true)
			fake_act_menu = false
		else
			fake_act_menu = true
			enemies[1].Call("SetActive",false)
			enemies[2].Call("SetActive",true)
			action = "ACTMENU"
			button_cooldown = 1
		end
	end
	if currentstate == "ITEMMENU" or currentstate == "MERCYMENU" then
		if Input.Cancel == 1 then
			State("ACTIONSELECT")
			Player.MoveToAbs(x,y,true)
		end
	end
	if boxes_enable then
		resizing_mask.Update()
		random_attacks.Update()
	end
end

function EnteringState(newstate,oldstate)
	currentstate = newstate
	if newstate == "ACTIONSELECT" and (oldstate == "DEFENDING" or oldstate == "ENEMYDIALOGUE") then
		random_attacks.timer = 0
	end
	if newstate == "ENEMYDIALOGUE" then
		resizing_mask.move = true
	elseif oldstate == "ENEMYDIALOGUE" and newstate == "DEFENDING" then
		resizing_mask.move = false
		resizing_mask.fakemovecounter = 1
		resizing_mask.fakemask = CreateProjectile("another mask",0,0)
		resizing_mask.fakemask.SetVar("safe",true)
		resizing_mask.vertbar_l.MoveTo(-72.5,0)
		resizing_mask.vertbar_r.MoveTo(72.5,0)
		resizing_mask.movecounter = 25
		random_attacks.timer = 0
		random_attacks.createmore = true
		Player.MoveToAbs(320,160,true)
	end
	if newstate == "ACTMENU" and fake_act_menu then
		enemies[1].Call("SetActive",false)
		enemies[2].Call("SetActive",true)
	elseif newstate == "ENEMYSELECT" and fake_act_menu then
		State("ACTMENU")
	end
	if newstate == "ATTACKING" or newstate == "DIALOGRESULT" or newstate == "ENEMYDIALOGUE" then
		random_attacks.createmore = false
	end
	if oldstate == "ATTACKING" and enemies[1]["hp"] <= 0 then
		random_attacks.createmore = false
	end
end

function CreateBoxes()
	boxes = require "Libraries/boxes"
	boxes.CreateBoxes()
	boxes_enable = true
	resizing_mask = require "resizing_mask"
	random_attacks = require "random_attacks"
end
function OnHit(bullet)
	if not bullet.GetVar("safe") then
		Player.Hurt(3)
	end
end

function EncounterStarting()
	State("DEFENDING")
end

function DefenseEnding()
	if not intro then
		intro = true
		encountertext = "?!?!"
		nextwaves = {"none"}
	else
		encountertext = RandomEncounterText()
	end
end

function HandleSpare()
     State("ENEMYDIALOGUE")
end

function HandleItem(ItemID)
    BattleDialog({"Selected item " .. ItemID .. "."})
end