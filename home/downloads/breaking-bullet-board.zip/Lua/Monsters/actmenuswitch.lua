SetActive(false)
sprite = "blank"
commands = {Encounter["enemies"][1]["name"]}
function HandleCustomCommand(command)
	Encounter["fake_act_menu"] = false
	Encounter["enemies"][1].Call("SetActive",true)
	SetActive(false)
	State("ACTMENU")
end