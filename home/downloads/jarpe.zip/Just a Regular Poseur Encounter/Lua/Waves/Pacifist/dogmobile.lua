require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



blue = require "Libraries/bluesoul"
blue.Initialize({})
blue.speed = 3
Audio.PlaySound("ding")

do
    maskL = CreateSprite("px", "Topper")
    maskL.color = {0, 0, 0}
    maskL.SetPivot(1, 0)
    maskL.x = Arena.x - Arena.currentwidth/2 - 5
    maskL.y = Arena.y - 5
    maskL.Scale(320, 140)

    maskR = CreateSprite("px", "Topper")
    maskR.color = {0, 0, 0}
    maskR.SetPivot(0, 0)
    maskR.x = Arena.x + Arena.currentwidth/2 + 5
    maskR.y = Arena.y - 5
    maskR.Scale(320, 140)
end

timer = 0
f = 25

dog = CreateProjectile("Waves/Pacifist/dogmobile1", -Arena.width/2 - 100, 480)
dog.sprite.ypivot = 0
dog.ppcollision = true
smokes = {}

-- car sound effects, very important
NewAudio.CreateChannel("car")
NewAudio.PlaySound("car", "Waves/engine", true, 0.5)


function Update()
    blue.Update()
    
    timer = timer + 1
    
    -- update masks
    maskL.x = Arena.x - Arena.currentwidth/2 - 5
    maskR.x = Arena.x + Arena.currentwidth/2 + 5
    
    -- make dog appear
    if timer%240 < 120 then
        if not safe then
            dog.y = lerp(dog.y, Player.y, 0.1) + (math.sin(timer/12) * 2)
        else
            dog.y = dog.y + (math.min(math.abs(dog.y - Player.y), 8) * (Player.y < dog.y and -1 or 1))
        end
    elseif timer%240 == 120 then
        Audio.PlaySound("flash", 0.5)
        Misc.ShakeScreen(6, 30, false)
    elseif timer%240 > 120 and timer%240 < 239 then
        dog.x = dog.x + (((timer%240)-120) / 3.5)
        NewAudio.SetVolume("car", NewAudio.GetVolume("car") - (1/240))
    elseif timer%240 == 239 then
        dog.MoveTo(-Arena.width/2 - 100, 480)
        NewAudio.SetVolume("car", 0.5)
    end
    
    -- smoak
    if timer%32 == 16 then
        if not safe or (safe and timer%240 >= 48 and timer%240 <= 128) then
            -- play little puff sound
            Audio.PlaySound("BeginBattle2", (dog.x == -Arena.width/2 - 100) and 0.3 or 0.75 - ((dog.x - (-Arena.width/2 - 100)) / 2000))
            
            local smoke = CreateSprite("paper", "Topper")
            smoke.rotation = math.random() * 360
            smoke.Scale(0.75, 0.75)
            smoke.color = (timer%240 < 48 or timer%240 > 128) and {0.3, 0.3, 0.3}
                or ({
                     [48] = {  1, 0.3, 0.3},  [64] = {  1, 0.3, 0.3},
                     [80] = {  1,   1, 0.3},  [96] = {  1,   1, 0.3},
                    [112] = {0.3,   1, 0.3}, [128] = {0.3,   1, 0.3},
            })[timer%240]
            
            smoke.MoveToAbs(dog.absx - 48, dog.absy + 10)
            
            smokes[smoke] = true
        end
    end
    
    -- update smoak
    for smoke in next, smokes, smoke do
        smoke.rotation = smoke.rotation + 1
        smoke.alpha = smoke.alpha - (1/30)
        smoke.x = smoke.x - 1
        
        if smoke.alpha == 0 then
            smoke.Remove()
            smokes[smoke] = nil
        end
    end
    
    
    
    -- create platforms
    if timer%f == 0 then
        local plat = CreateProjectile("Waves/Pacifist/plat1", Arena.width/2 + 45, -Arena.height/2 + ((((timer-f)%(f*4))/f) * (Arena.height/5)) + Arena.height/5)
        plat.sprite.SetParent(Arena.sprite)
        plat.sprite.SendToBottom()
        
        plat["speed"] = -2
        
        table.insert(blue.platforms, plat)
    end
    
    -- update platforms
    for i = 1, #blue.platforms do
        if blue.platforms[i].isactive then
            blue.platforms[i].x = blue.platforms[i].x + blue.platforms[i]["speed"]
            
            -- remove condition
            if blue.platforms[i].x + blue.platforms[i].sprite.width/2 < -Arena.width/2 then
                blue.platforms[i].Remove()
            end
        end
    end
end

function lerp(a, b, t)
    return a + ((b - a) * t)
end

function OnHit(bullet)
    if bullet == dog then
        Player.Hurt(3, 1)
    end
end

function EndingWave()
    NewAudio.DestroyChannel("car")
    
    maskL.Remove()
    maskR.Remove()
    
    for smoke in next, smokes, smoke do
        smoke.Remove()
    end
    
    Player.sprite.color = {1, 0, 0}
end
