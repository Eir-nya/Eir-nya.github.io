require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



blue = require "Libraries/bluesoul"
blue.Initialize({})
blue.maxjump = 5

soul = require "Libraries/shield"

--================================--
--[[
do
    local outline = CreateSprite("shield/outline", "Topper")
    outline.SetParent(Player.sprite)
    outline.MoveTo(0, 0)
    Player.sprite["outline"] = outline
end
]]--
--================================--



NewAudio.CreateChannel("moov")

plat1 = CreateProjectile("Waves/Pacifist/plat2", 0, 150)
plat1.sprite.SetParent(Arena.sprite)
plat1.sprite.SetAnchor(0.5, 0)
plat1.sprite.SendToBottom()

plat2 = CreateProjectile("Waves/Pacifist/plat1", 30, 320)
plat2.sprite.SetParent(Arena.sprite)
plat2.sprite.SetAnchor(0.5, 0)
plat2.sprite.SendToBottom()

blue.platforms = { plat1, plat2 }



timer = 0
local _cg = blue.CheckIfGrounded
local switched = false

cannons     = {}
cannonballs = {}

function Update()
    timer = timer + 1
    
    blue.Update()
    if Input.Confirm == 1 then
        soul.jump = not blue.CheckIfGrounded()
    else
        soul.jump = false
    end
    soul.Update()
    
    -- move up stuff
    do
        Arena.height = Arena.height + 1
        Arena.currentheight = Arena.currentheight + 1
        Misc.cameraY = Misc.cameraY + 1
        
        -- force player to stay at spikes if they are below them
        spikes.absy = math.max(spikes.absy, Misc.cameraY + 10)
        if Player.absy < spikes.absy and not switched then
            Player.absy = spikes.absy
            blue.CheckIfGrounded = function() return true end
            switched = true
        elseif switched then
            blue.CheckIfGrounded = _cg
            switched = false
        end
    end
    
    
    
    -- actually create objects
    
    -- platform with skull face
    if timer == 1 then
        plat3 = CreateProjectileAbs("Waves/Pacifist/plat1", Arena.x - 60, 0)
        plat3.sprite.SetParent(Arena.sprite)
        plat3.sprite.SendToBottom()
        plat3.sprite.SetAnchor(0.5, 0)
        plat3.absy = Arena.y + Misc.cameraY + 480 + 11
        table.insert(blue.platforms, plat3)
        
        sign = CreateSprite("Waves/Pacifist/sign1", "Topper")
        sign.SetParent(plat3.sprite)
        sign.ypivot = 0
        sign.MoveTo(0, 0)
        sign.layer = "Topper"
        sign.MoveBelow(spikes.sprite)
    
    -- very wide platform with 6 cannons on bottom
    elseif timer == 90 then
        plat4 = CreateProjectileAbs("Waves/Pacifist/plat2", Arena.x, 0)
        plat4.sprite.SetParent(Arena.sprite)
        plat4.sprite.SendToBottom()
        plat4.sprite.SetAnchor(0.5, 0)
        plat4.absy = Arena.y + Misc.cameraY + 480 + 11 + 16
        table.insert(blue.platforms, plat4)
        
        for i = 1, 6 do
            local cannon = CreateProjectileAbs("Waves/Pacifist/cannon1", plat3.absx - (plat3.sprite.width/2) + ((i/7) * plat3.sprite.width), 0)
            cannon.sprite.SetParent(Arena.sprite)
            cannon.sprite.ypivot = 1
            cannon.sprite.SetAnchor(0.5, 0)
            cannon.absy = Arena.y + Misc.cameraY + 480 + 11 + 12
            
            cannon["timer"] = 90
            cannon["frequency"] = 60
            cannon["green"] = true
            cannon["sound"] = i == 1
            
            cannons[cannon]      = true
        end
    
    -- platform moving from left to right gradually with 2 green cannons on top and 2 normal cannons on bottom
    elseif timer == 160 then
        plat5 = CreateProjectileAbs("Waves/Pacifist/plat1", Arena.x + Arena.width/4, 0)
        plat5.sprite.SetParent(Arena.sprite)
        plat5.sprite.SendToBottom()
        plat5.sprite.SetAnchor(0.5, 0)
        plat5.absy = Arena.y + Misc.cameraY + 480 + 11 + 16
        table.insert(blue.platforms, plat5)
        
        -- spawn 4 cannons
        do
            local c1 = CreateProjectileAbs("Waves/Pacifist/cannon2", plat5.absx - plat5.sprite.width/2 + 8, 0)
            c1.sprite.SetParent(plat5.sprite)
            c1.sprite.ypivot = 1
            c1.sprite.rotation = 180
            c1.absy = plat5.absy + 5
            c1["timer"] = 60
            c1["frequency"] = 60
            c1["green"] = true
            c1["NoRemove"] = true
            c1["ydir"] = 1
            
            c1["OnShield"] = function()
                c1.Remove()
                cannons[c1] = nil
                plat5["c1"] = nil
                soul.bullets[c1] = nil
            end
            
            cannons[c1]      = true
            soul.bullets[c1] = true
            
            plat5["c1"] = c1
            
            
            
            local c2 = CreateProjectileAbs("Waves/Pacifist/cannon2", plat5.absx + plat5.sprite.width/2 - 8, 0)
            c2.sprite.SetParent(plat5.sprite)
            c2.sprite.ypivot = 1
            c2.sprite.rotation = 180
            c2.absy = plat5.absy + 5
            c2["timer"] = 60
            c2["frequency"] = 60
            c2["green"] = true
            c2["NoRemove"] = true
            c2["ydir"] = 1
            
            c2["OnShield"] = function()
                c2.Remove()
                cannons[c2] = nil
                plat5["c2"] = nil
                soul.bullets[c2] = nil
            end
            
            cannons[c2]      = true
            soul.bullets[c2] = true
            
            plat5["c2"] = c2
            
            
            
            local c3 = CreateProjectileAbs("Waves/Pacifist/cannon1", plat5.absx - plat5.sprite.width/2 + 8, 0)
            c3.sprite.SetParent(plat5.sprite)
            c3.sprite.ypivot = 1
            c3.absy = plat5.absy - 5
            c3["timer"] = 60
            c3["frequency"] = 60
            c3["sound"] = true
            
            cannons[c3]      = true
            
            plat5["c3"] = c3
            
            
            
            local c4 = CreateProjectileAbs("Waves/Pacifist/cannon1", plat5.absx + plat5.sprite.width/2 - 8, 0)
            c4.sprite.SetParent(plat5.sprite)
            c4.sprite.ypivot = 1
            c4.absy = plat5.absy - 5
            c4["timer"] = 60
            c4["frequency"] = 60
            
            cannons[c4]      = true
            
            plat5["c4"] = c4
        end
    
    -- platforms in the middle, bunch of green cannons on the sides of the arena
    elseif timer == 260 then
        plat6 = CreateProjectileAbs("Waves/Pacifist/plat3", Arena.x, 0)
        plat6.sprite.SetParent(Arena.sprite)
        plat6.sprite.SendToBottom()
        plat6.sprite.SetAnchor(0.5, 0)
        plat6.absy = Arena.y + Misc.cameraY + 480 + 11 + 16
        table.insert(blue.platforms, plat6)
        
        sign2 = CreateSprite("Waves/Pacifist/sign2", "Topper")
        sign2.SetParent(plat6.sprite)
        sign2.ypivot = 0
        sign2.MoveTo(-20, 0)
        sign2.layer = "Topper"
        sign2.MoveBelow(spikes.sprite)
        
        -- spawn 8 cannons on each Arena side
        for i = 1, 4 do
            local cannon = CreateProjectileAbs("Waves/Pacifist/cannon1", Arena.x + ((Arena.width/2) * (i % 2 == 0 and -1 or 1)), 0)
            cannon.sprite.SetParent(Arena.sprite)
            cannon.sprite.ypivot = 1
            cannon.sprite.rotation = i % 2 == 0 and 90 or 270
            cannon.sprite.SetAnchor(0.5, 0)
            cannon.absy = Arena.y + Misc.cameraY + 480 + 11 + 100 + (i * 48)
            
            cannon["timer"] = 90
            cannon["frequency"] = 60
            cannon["green"] = true
            cannon["sound"] = i == 1
            cannon["xdir"] = i % 2 == 0 and 1 or -1
            cannon["ydir"] = 0
            
            cannons[cannon]      = true
        end
    
    -- mural
    elseif timer == 900 then
        muralB = CreateSprite("Waves/Pacifist/mural" .. math.random(2, 3), "Topper")
        muralB.ypivot = 0
        muralB.MoveToAbs(Arena.x, Misc.cameraY + 480)
        muralB.alpha = 0.5
        
        muralA = CreateSprite("Waves/Pacifist/mural1", "Topper")
        muralA.ypivot = 0
        muralA.MoveToAbs(Arena.x, Misc.cameraY + 480 + 60)
        muralA.alpha = 0.5
    end
    
    
    
    -- update objects
    if plat5 then
        plat5["speed"] = math.sin(math.rad(timer))
        plat5.x = plat5.x + plat5["speed"]
        
        -- remove condition
        if plat5.absy + plat5.sprite.height/2 + 16 < Misc.cameraY then
            if plat5["c1"] then
                plat5["c1"].Remove()
            end
            if plat5["c2"] then
                plat5["c2"].Remove()
            end
            plat5["c3"].Remove()
            plat5["c4"].Remove()
            
            plat5.Remove()
            plat5 = nil
        end
    end
    
    if plat6 and (timer == 760 or math.sqrt((Player.absy - plat6.absy)^2 + (Player.absx - plat6.absx)^2) < plat6.sprite.width) and not plat6["thing"] then
        if plat6.isColliding() or timer == 760 then
            -- yes, it must be structured like this with multiple nested if statements
            -- the reason being if I do `if plat6.isColliding() and blue.CheckIfGrounded() then`,
            -- it'll always check if the player is grounded even if `plat6.isColliding()` is false
            -- so this is optimization
            if blue.CheckIfGrounded() or timer == 760 then
                plat6["thing"] = true
                plat6["vely"] = 1
                Audio.PlaySound("Waves/home")
            end
        end
    elseif plat6 and plat6["thing"] and plat6.absy < 1241 then
        plat6.y = plat6.y + plat6["vely"]
        
        -- move player up too because h
        if platforming then
            Player.y = Player.y + plat6["vely"]
        end
        
        sign2.y = sign2.y + plat6["vely"]
    end
    
    for cannon in next, cannons, cannon do
        cannon["timer"] = cannon["timer"] - 1
        
        -- begin to squish cannon
        if cannon["timer"] <= 30 and cannon["timer"] > 0 then
            cannon.sprite.yscale = cannon.sprite.yscale - (cannon["timer"] % 2 == 1 and -0.005 or 0.015)
        -- fire!
        elseif cannon["timer"] == 0 then
            if cannon["sound"] then
                Audio.PlaySound("BeginBattle2")
            end
            
            cannon.sprite.yscale = 1
            cannon["timer"] = cannon["frequency"] + 30
            
            local cball = CreateProjectileAbs("Waves/Pacifist/cannonball" .. (cannon["green"] and "2" or "1"), cannon.absx, cannon.absy)
            cball.ppcollision = true
            cball["xdir"] = cannon["xdir"] and cannon["xdir"] or  0
            cball["ydir"] = cannon["ydir"] and cannon["ydir"] or -1
            
            cball.Move(cball["xdir"] * 16, cball["ydir"] * 16)
            
            cannonballs[cball] = true
            if cannon["green"] then
                cball["OnShield"] = function()
                    cball.Remove()
                    cannonballs[cball] = nil
                    soul.bullets[cball] = nil
                end
                soul.bullets[cball] = true
            end
        end
        
        -- remove condition
        if not cannon["NoRemove"] and cannon.absy < Misc.cameraY then
            cannon.Remove()
            cannons[cannon] = nil
        end
    end
    
    for cball in next, cannonballs, cball do
        cball.sprite.rotation = cball.sprite.rotation + 10
        cball.Move(4 * cball["xdir"], 4 * cball["ydir"])
        
        -- remove condition
        if cball.absy - cball.sprite.height/2 > Misc.cameraY + 480
        or cball.absy + cball.sprite.height/2 < Misc.cameraY
        or cball.absx - cball.sprite. width/2 < 0
        or cball.absx + cball.sprite. width/2 > 640 then
            cball.Remove()
            cannonballs[cball] = nil
        end
    end
    
    -- remove objects that are off-screen
    if     plat1 and plat1.absy + plat1.sprite.height/2 < Misc.cameraY then
        plat1.Remove()
        plat1 = nil
    elseif plat2 and plat2.absy + plat2.sprite.height/2 < Misc.cameraY then
        plat2.Remove()
        plat2 = nil
    elseif plat3 and plat3.absy + plat3.sprite.height/2 < Misc.cameraY then
        sign.layer = "Topper"
        plat3.Remove()
        plat3 = nil
    elseif sign and sign.absy + sign.height/2 < Misc.cameraY then
        sign.Remove()
        sign = nil
    elseif plat4 and plat4.absy + plat4.sprite.height/2 < Misc.cameraY then
        plat4.Remove()
        plat4 = nil
    elseif sign2 and sign2.absy + sign2.height/2 < Misc.cameraY then
        sign2.Remove()
        sign2 = nil
    end
    
    
    
    -- end of wave time
    if timer == 1140 then
        Misc.ShakeScreen(3)
        Audio.PlaySound("flash", 0.3)
        
        function OnHit() end
        NewAudio.Stop("moov")
    elseif timer == 1240 then
        Audio.PlaySound("success")
    elseif timer == 1335 then
        Misc.ShakeScreen(3)
        Audio.PlaySound("flash", 0.3)
        Misc.ResetCamera()
        cover2 = CreateSprite("UI/sq_white", "Topper")
        cover2.MoveTo(320, 240)
        cover2.Scale(700/4, 500/4)
    elseif timer == 1340 then
        Arena.height = 130
        Arena.currentheight = 130
        EndWave()
    end
    
    if timer >= 1140 then
        Arena.height = Arena.height - 1
        Arena.currentheight = Arena.currentheight - 1
        Misc.cameraY = Misc.cameraY - 1
        spikes.y = spikes.y - 1
    end
end



-- wrap Update to allow for intro sequence
tim = 0
local _update = Update

hpcover = CreateSprite("px", "Topper")
hpcover.SetPivot(0, 0)
hpcover.MoveTo(274, 60)
hpcover.Scale(30, 20)
hpcover.color = {0, 0, 0}

hpback = CreateSprite("px", "Toppest")
hpback.SetPivot(0, 0)
hpback.MoveTo(276, 60)
hpback.Scale(24, 20)
hpback.color = {1, 0, 0}

hpfront = CreateSprite("px", "Toppest")
hpfront.SetParent(hpback)
hpfront.SetPivot(0, 0)
hpfront.SetAnchor(0, 0)
hpfront.MoveTo(0, 0)
hpfront.Scale(Player.hp * 1.2, 20)
hpfront.color = {1, 1, 0}

Player.MoveTo(0, -Arena.height/2)

function Update()
    tim = tim + 1
    
    blue.Update()
    if Input.Confirm == 1 then
        soul.jump = not blue.CheckIfGrounded()
    else
        soul.jump = false
    end
    soul.Update()
    
    if tim == 20 then
        label1 = CreateSprite("shield/label3", "Topper")
        label1.SetParent(Player.sprite)
        label1.xpivot = 0
        label1.MoveTo(14, 24)
        
        label2 = CreateSprite("shield/label2", "Topper")
        label2.SetParent(Player.sprite)
        label2.xpivot = 1
        label2.MoveTo(-12, 24)
        
        button = CreateSprite("shield/button1", "Topper")
        button.SetAnimation({"button1", "button1", "button1", "button1", "button1", "button1", "button2", "button3", "button3", "button3", "button3", "button3", "button3"}, 1/16, "shield")
        button.SetParent(Player.sprite)
        button.MoveTo(0, 24)
    elseif Player.y >= plat1.y then
        if label1 then
            label1.Remove()
            label1 = nil
            label2.Remove()
            label2 = nil
            button.Remove()
            button = nil
            
            cover = CreateSprite("black", "Topper", 6)
            cover.alpha = 0
            coverstamp = tim
            
            Player.y = plat1.y + plat1.sprite.height/2 + Player.sprite.height/2
            soul.jumpamount = soul.jumpamount + 1
            soul.maxcooldown = soul.maxcooldown - 18
        end
        
        -- begin darkening scween
        if     tim-coverstamp <= 60 then
            cover.alpha = cover.alpha + (1/120)
        
        -- make spikes
        elseif tim-coverstamp == 80 then
            Audio.PlaySound("Waves/Screen/0721")
            Misc.ShakeScreen(8, 10)
            spikes = CreateProjectileAbs("Waves/Pacifist/spikes", Arena.x, Arena.y + 10)
            -- spikes["vely"] = 1
            spikes.sprite.yscale = 0
        -- scale in spikes
        elseif tim-coverstamp > 80 and tim-coverstamp <= 84 then
            spikes.sprite.yscale = spikes.sprite.yscale + (1/4)
        -- move up arena top prematurely
        elseif tim-coverstamp > 110 and tim-coverstamp <= 145 then
            Arena.height = Arena.height + 1
            Arena.currentheight = Arena.currentheight + 1
            
            hpback.absx = lerp(hpback.absx, Player.absx - 12, 0.2)
            hpback.absy = lerp(hpback.absy, Player.absy + 24, 0.2)
        
        -- make the switch over to the proper update function
        elseif tim-coverstamp == 146 then
            Audio.PlaySound("flash", 0.3)
            Misc.ShakeScreen(6, 6, true)
            NewAudio.PlaySound("moov", "Waves/chain", true, 0.4)
            Update = _update
            
            hpback.SetParent(Player.sprite)
            hpback.MoveToAbs(Player.absx - 12, Player.absy + 24)
            
            -- re-wrap Update function
            package.loaded["Libraries/fakearena_WAVE_END"] = nil
            (require "fakearena_WAVE_END")(true)
        end
    end
end

function lerp(a, b, t)
    return a + ((b - a) * t)
end



function OnHit(bullet)
    if Player.isHurting then
        return
    end
    
    
    -- change these values based on what bullets you get hit by
    local damage  = 0
    local iframes = 0
    
    if bullet == spikes then
        damage  = 3
        iframes = 1.7
    elseif bullet.sprite.spritename:sub(-11, -2) == "cannonball" then
        damage = 2
        iframes = 1
        bullet.Remove()
        cannonballs[bullet["wrapped"]] = nil
    elseif bullet.sprite.spritename:sub(-7, -2) == "cannon" then
        damage = 1
        iframes = 1.7
    end
    
    -- this is done so you actually appear where you died on screen in the game over screen
    if Player.hp - damage <= 0 then
        Player.absy = Player.absy - Misc.cameraY
    end
    
    -- also scale hp sprite here
    if damage > 0 then
        Player.Hurt(damage, iframes)
        if hpfront and hpfront.isactive then
            hpfront.xscale = Player.hp * 1.2
        end
    end
end

function EndingWave()
    NewAudio.DestroyChannel("moov")
    
    if label1 then
        label1.Remove()
        label2.Remove()
        button.Remove()
    end
    
    hpcover.Remove()
    hpback.Remove()
    hpfront.Remove()
    
    if cover then
        cover.Remove()
    end
    if cover2 then
        cover2.Remove()
    end
    
    if sign then
        sign.Remove()
    end
    
    if muralB then
        muralB.Remove()
        muralA.Remove()
    end
    
    Player.sprite.color = {1, 0, 0}
    soul.EndWave()
end
