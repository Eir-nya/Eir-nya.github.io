require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



local hand = CreateSprite("Waves/Pacifist/hand", "Topper")
hand.SetPivot(1, 0)
hand.rotation = 180
hand.x = Arena.x - Arena.width/2
hand.y = Arena.y + Arena.height
hand.alpha = 0

bullets = {}
local timer = -30

function Update()
    timer = timer + 1
    
    if timer > 0 then
        -- move hand right
        if hand then
            hand.x = hand.x + 2
            hand.alpha = ((Arena.x + Arena.width/2) - (hand.x + hand.width))/20
            
            -- create bullets
            if timer%8 == 0 then
                Audio.PlaySound("BeginBattle2", 0.4)
                
                local bullet = CreateProjectile("Waves/Pacifist/flame1", hand.x - Arena.x + (hand.width/2), hand.y - (Arena.y + Arena.height/2) - (hand.height/2))
                bullet.sprite.SetAnimation({"flame1", "flame2"}, 1/6, "Waves/Pacifist")
                bullet.sprite.MoveBelow(hand)
                bullet["timer"] = 0
                bullets[bullet] = true
            end
            
            -- remove condition
            if hand.alpha <= 0 then
                hand.Remove()
                hand = nil
            end
        end
        
        
        
        -- update bullets
        for bullet in next, bullets, bullet do
            bullet["timer"] = bullet["timer"] + 1
            
            if bullet["timer"] == 30 then
                local ang = math.rad(math.deg(math.atan2(Player.y - bullet.y, Player.x - bullet.x)) + 90)
                bullet["xdir"] =  math.sin(ang)
                bullet["ydir"] = -math.cos(ang)
            elseif bullet["timer"] > 30 then
                local speed = 2.25
                bullet.Move(bullet["xdir"] * speed, bullet["ydir"] * speed)
                
                -- collision with ceiling and floor
                if bullet.y + bullet.sprite.height/2 > Arena.height/2 then
                    bullet["ydir"] = -bullet["ydir"]
                    bullet.y = (Arena.height/2) - bullet.sprite.height/2
                elseif bullet.y - bullet.sprite.height/2 < -Arena.height/2 then
                    bullet["ydir"] = -bullet["ydir"]
                    bullet.y = (-Arena.height/2) + bullet.sprite.height/2
                end
                
                -- collision with walls
                if bullet.x - bullet.sprite.width/2 < -Arena.width/2 then
                    bullet["xdir"] = -bullet["xdir"]
                    bullet.x = (-Arena.width/2) + bullet.sprite.width/2
                elseif bullet.x + bullet.sprite.width/2 > Arena.width/2 then
                    bullet["xdir"] = -bullet["xdir"]
                    bullet.x = (Arena.width/2) - bullet.sprite.width/2
                end
            end
        end
    else
        -- fade in hand
        hand.alpha = hand.alpha + (1/20)
    end
end

function OnHit(bullet)
    if not Player.isHurting then
        Player.Hurt(2, 1)
        bullet.sprite.StopAnimation()
        bullet.Remove()
        bullets[bullet["wrapped"]] = nil
    end
end

function EndingWave()
    if hand then
        hand.Remove()
    end
    
    for bullet in next, bullets, bullet do
        if bullet.isactive then
            bullet.sprite.StopAnimation()
            bullet.Remove()
        end
    end
end
