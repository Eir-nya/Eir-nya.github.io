require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



soul = require "Libraries/shield"
soul.active = false

-- Player.SetControlOverride(true)

Encounter["enemies"][1].Call("FadeOutAudio", 2)
Misc.ShakeScreen(16, 4, false)
Audio.PlaySound("flash")

if windows then
    Misc.WindowName = "Huh??"
end



knives = {}
for j = 1, 2 do
    for i = 1, 10 do
        local knife = CreateProjectile("Waves/Pacifist/knife", ({[1] = -340, [2] = 340})[j], 0)
        knife.sprite.rotation = ({[1] = -90, [2] = 90})[j]
        knife["speed"] = ({[1] = 1, [2] = -1})[j]
        knife.Move(math.random(0, 32) * -knife["speed"], -Arena.height/2 + ((i/11) * Arena.height))
        
        knife["OnShield"] = function()
            knife.Remove()
            knives[knife] = nil
        end
        knives[knife] = true
    end
end

shield = CreateSprite("shield/shield", "Topper")
shield.MoveToAbs(660, 200)
shield.rotation = math.random() * 360
shieldvel = 4

glow = CreateSprite("shield/glow", "Topper")
glow.MoveBelow(shield)
glow.MoveToAbs(shield.absx, shield.absy)
glow.alpha = 0

timer = 0

function Update()
    timer = timer + 1
    soul.Update()
    
    
    
    -- make the shield fly in
    if timer > 120 and timer < 190 then
        shield.x = shield.x - 5
        shield.y = shield.y + shieldvel
        shield.rotation = shield.rotation + 7
        shieldvel = shieldvel - 0.15
        
        glow.MoveToAbs(shield.absx, shield.absy)
        glow.xscale = 1 + (math.sin(timer / 3) / 4)
        glow.yscale = glow.xscale
        glow.alpha = (timer - 120) / 70
    end
    
    if timer >= 90 and timer < 170 and timer%10 == 0 then
        Audio.PlaySound("ding")
    -- activate shield!! --
    elseif timer == 190 then
        shield.Remove()
        glow.Remove()
        Misc.ShakeScreen(16, 8, true)
        
        local outline = CreateSprite("shield/outline", "Topper")
        outline.SetParent(Player.sprite)
        outline.MoveTo(0, 0)
        Player.sprite["outline"] = outline
        
        Player.SetControlOverride(false)
        soul.bullets = knives
        soul.Protecc()
        soul.active = true
        
        Audio.PlaySound("hitsound")
    -- Press Z, Player!
    elseif timer == 300 then
        label = CreateSprite("shield/label1", "Topper")
        label.SetParent(Player.sprite)
        label.xpivot = 0
        label.MoveTo(-10, 24)
        
        button = CreateSprite("shield/button1", "Topper")
        button.SetAnimation({"button1", "button1", "button1", "button1", "button1", "button1", "button2", "button3", "button3", "button3", "button3", "button3", "button3"}, 1/16, "shield")
        button.SetParent(Player.sprite)
        button.MoveTo(-24, 24)
        
        local f = soul.Protecc
        function soul.Protecc()
            f()
            label.Remove()
            button.Remove()
            timer = 0
            function Update()
                soul.Update()
                timer = timer + 1
                if timer == 180 then
                    -- play music
                    Encounter.Call("loadstring", "musicIntroLoop.StartSong(\"Hand in Hand (Intro)\", \"Hand in Hand (Loop)\", 12.581)")
                    
                    if windows then
                        Misc.WindowName = "A new ability!?"
                    end
                    
                    EndWave()
                end
            end
            
            package.loaded["Libraries/fakearena_WAVE_END"] = nil
            (require "fakearena_WAVE_END")(true)
            
            soul.Protecc = f
        end
    end
    
    if timer >= 160 then
        for knife in next, knives, knife do
            knife.Move(knife["speed"] * 10, 0)
            
            if math.abs(knife.x) > 400 then
                knife.Remove()
                knives[knife] = nil
            end
        end
    end
end

function OnHit(bullet) end

function EndingWave()
    soul.EndWave()
end
