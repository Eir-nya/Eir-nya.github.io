-- plz don't hurt me Gir I luv ya <3

do
    Player.SetControlOverride(true)
    local pos = {x = Player.absx, y = Player.absy}
    Player.sprite.SetParent(Encounter["fakearena"].arena)
    Player.sprite.SetAnchor(0, 0)
	Player.MoveToAbs(pos.x, pos.y, false)
    Player.sprite.rotation = Encounter["fakearena"].arena.rotation
    
    local speed = 2
    local controlOverride = false
    SetGlobal("invulTimer", 0)
    
    local wrapper = require "Libraries/userdataWrapper"
    wrapper.WrapPlayer({
        -- Player.x: gets/sets position relative to arena center
        x = {
            set = function(_pla, pla, val)
                _pla.sprite.x = (Arena.currentwidth/2) + val
            end,
            get = function(_pla, pla)
                return _pla.sprite.x - (Arena.currentwidth/2)
            end
        },
        
        -- Player.y: gets/sets position relative to arena center
        y = {
            set = function(_pla, pla, val)
                _pla.sprite.y = (Arena.currentheight/2) + val
            end,
            get = function(_pla, pla)
                return _pla.sprite.y - (Arena.currentheight/2)
            end
        },
        
        -- Player.absx: gets/sets position relative to bottom-left of screen
        absx = {
            set = function(_pla, pla, val)
                _pla.sprite.absx = val
            end,
            get = function(_pla, pla)
                return _pla.sprite.absx
            end
        },
        
        -- Player.absy: gets/sets position relative to bottom-left of screen
        absy = {
            set = function(_pla, pla, val)
                _pla.sprite.absy = val
            end,
            get = function(_pla, pla)
                return _pla.sprite.absy
            end
        },
        
        -- Player.KeepInBounds(): keeps the player inside the arena
        KeepInBounds = {
            set = function(_pla, pla)
                local arena_left_side   = -Encounter["fakearena"].arena.xscale/2
                local arena_right_side  =  Encounter["fakearena"].arena.xscale/2
                local arena_top_side    =  Encounter["fakearena"].arena.yscale/2
                local arena_bottom_side = -Encounter["fakearena"].arena.yscale/2
                
                local player_width  = _pla.sprite.width /2 * _pla.sprite.xscale
                local player_height = _pla.sprite.height/2 * _pla.sprite.yscale
                
                --   left side
                if     pla.x - player_width <   arena_left_side then
                    pla.x = arena_left_side   + player_width
                
                --  right side
                elseif pla.x + player_width >   arena_right_side then
                    pla.x = arena_right_side  - player_width
                end
                
                --    top side
                --     (                         top edge of player                       )
                if     pla.y + player_height >    arena_top_side then
                    pla.y = arena_top_side    - player_height
                
                -- bottom side
                --     (                      bottom edge of player                       )
                elseif pla.y - player_height < arena_bottom_side then
                    pla.y = arena_bottom_side + player_height
                end
            end
        },
        
        -- Player.Move: adds on to x and y
        Move = {
            set = function(_pla, pla, x, y, ignoreWalls)
                pla.x = pla.x + x
                pla.y = pla.y + y
                
                if not ignoreWalls then
                    pla.KeepInBounds()
                end
            end
        },
        
        -- Player.MoveTo: gets/sets position relative to arena center
        MoveTo = {
            set = function(_pla, pla, x, y)
                pla.x = x
                pla.y = y
                
                if not ignoreWalls then
                    pla.KeepInBounds()
                end
            end
        },
        
        -- Player.Hurt: also shakes the screen
        Hurt = {
            set = function(_pla, pla, ...)
                if not pla.isHurting then
                    if _pla.hp - ({...})[1] > 0 then
                        Misc.ShakeScreen(6, 6)
                        _pla.hp = _pla.hp - ({...})[1]
                        Audio.PlaySound("hurtsound")
                        pla.invulTimer = (({...})[2] and ({...})[2] or 1.7) * 60
                        _pla.sprite.alpha = _pla.sprite.alpha / 2
                    else
                        Encounter.Call("loadstring",
                                "gameover = require \"Libraries/game_over_" .. (Encounter["route"].genostep == 2 and "deltarune" or "undertale") .. "\" ; "
                             .. "Update = function() ; "
                                 .. "gameover.Update() ; "
                             .. "end ; "
                             .. "gameover.text = deathtext and deathtext or gameover.text ; "
                             .. "gameover.music = deathmusic and deathmusic or gameover.music ; "
                             .. "gameover.layer = \"Toppest\" ; "
                             .. "gameover.shardcount = " .. (Encounter["route"].genostep == 3 and 400 or 6) .. " ; "
                             .. "gameover.StartGameOver() ; "
                             .. "Misc.ResetCamera() ; "
                             .. "NewAudio.StopAll() ; "
                             .. "route.deathfunc()"
                        )
                        State("NONE")
                    end
                end
            end
        },
        
        -- Player.isHurting: returns if `invulTimer` from above is > 0
        isHurting = {
            get = function(_pla, pla)
                return GetGlobal("invulTimer") and GetGlobal("invulTimer") > 0
            end
        },
        
        -- Player.invulTimer: gets and sets `invulTimer` from above. see `Libraries/fakearena_WAVE_END.lua`
        invulTimer = {
            set = function(_pla, pla, val)
                SetGlobal("invulTimer", val)
            end,
            get = function()
                return GetGlobal("invulTimer") and GetGlobal("invulTimer")
            end
        },
        
        -- Player.speed: gets and sets `speed` from above. see `Libraries/fakearena_WAVE_END.lua`
        speed = {
            set = function(_pla, pla, val)
                speed = val
            end,
            get = function()
                return speed
            end
        },
        
        -- Player.controlOverride: gets and sets `controlOverride` from above. see `Libraries/fakearena_WAVE_END.lua`
        controlOverride = {
            set = function(_pla, pla, val)
                controlOverride = val
            end,
            get = function()
                return controlOverride
            end
        },
        
        -- Player.SetControlOverride: shortcut to above
        SetControlOverride = {
            set = function(_pla, pla, val)
                pla.controlOverride = val
            end
        }
    })
end
-- require "Libraries/fakearena_WAVE_BEGIN"    -- not always required
--═════════════════════════════════════════════════════════════════--



-- made by WD200019
rows = 14
columns = 10

Arena.ResizeImmediate(columns * 16, rows * 16)
Player.absx = Arena.x

blue = require "Libraries/bluesoul_tetris"
blue.Initialize({-Arena.width/2, Arena.height/2, Arena.width/2, -Arena.height/2})

grid = CreateSprite("Waves/Pacifist/tetris/grid", "Topper")
grid.SetParent(Encounter["fakearena"].arena)
grid.SendToBottom()
grid.MoveTo(0, 0)

preview = CreateSprite("Waves/Pacifist/tetris/I", "Topper")
preview.SetPivot(0, 1)
preview.MoveToAbs(304, 319)
preview.alpha = 0

stars = {}
-- makes a star particle with a random size, rotation, and direction
function CreateStar(absx, absy)
    local star = CreateSprite("Waves/Pacifist/tetris/star", "Topper")
    star.MoveToAbs(absx, absy)
    star.rotation = math.random(0, 360)
    star.alpha = 0.5
    
    star.SetVar("turnspeed", math.random(-10, 10))
    
    star.SetVar("direction", math.random(0, 360))
    star.SetVar("distance", 2)
    
    table.insert(stars, star)
end

-- Creates a new block in column `column` and row `row`
function CreateBlock(column, row)
    local block = CreateProjectile("bullet", -((columns/2) * 16) - 8 + (column * 16), -((rows/2) * 16) - 8 + (row * 16))
    block.sprite.layer = "Topper"
    
    -- lol moovs the boolet
    block.SetVar("moov", function(x, y, no_star)
        block.Move(x * 16, y * 16)
        
        if not no_star then
            CreateStar(block.absx, block.absy)
        end
    end)
    
    -- Gets the row and column the block is currently in
    block.SetVar("GetPosition", function()
        return { x = columns + (((block.x + 8) - ((columns/2) * 16))/16), y = rows + (((block.y + 8) - ((rows/2) * 16))/16) }
    end)
    
    CreateStar(block.absx, block.absy)
    
    table.insert(ALLblocks, block)
    
    return block
end

-- Creates a block shape
-- shape: string : "I", "O", "T", "L", "J", "S", "Z"
-- column: number 1-10
function CreateShape(shape, column)
    local tab = {}
    
    tab.rotation = 0
    
    if     shape == "I" then
        table.insert(tab, CreateBlock(column  , rows  ))
        table.insert(tab, CreateBlock(column  , rows-1))
        table.insert(tab, CreateBlock(column  , rows-2))
        table.insert(tab, CreateBlock(column  , rows-3))
        
        for i = 1, 4 do
            tab[i].sprite.Set("Waves/Pacifist/tetris/blocky1")
            tab[i].sprite.color = {1, 0, 0}
        end
    elseif shape == "O" then
        table.insert(tab, CreateBlock(column  , rows  ))
        table.insert(tab, CreateBlock(column+1, rows  ))
        table.insert(tab, CreateBlock(column  , rows-1))
        table.insert(tab, CreateBlock(column+1, rows-1))
        
        for i = 1, 4 do
            tab[i].sprite.Set("Waves/Pacifist/tetris/blocky2")
            tab[i].sprite.color = {0, 1, 0}
        end
    elseif shape == "T" then
        table.insert(tab, CreateBlock(column  , rows  ))
        table.insert(tab, CreateBlock(column-1, rows-1))
        table.insert(tab, CreateBlock(column  , rows-1))
        table.insert(tab, CreateBlock(column  , rows-2))
        
        for i = 1, 4 do
            tab[i].sprite.Set("Waves/Pacifist/tetris/blocky3")
            tab[i].sprite.color = {1, 1, 0}
        end
    elseif shape == "L" then
        table.insert(tab, CreateBlock(column  , rows  ))
        table.insert(tab, CreateBlock(column-1, rows  ))
        table.insert(tab, CreateBlock(column  , rows-1))
        table.insert(tab, CreateBlock(column  , rows-2))
        
        for i = 1, 4 do
            tab[i].sprite.Set("Waves/Pacifist/tetris/blocky4")
            tab[i].sprite.color32 = {56, 12, 255}
        end
    elseif shape == "J" then
        table.insert(tab, CreateBlock(column  , rows  ))
        table.insert(tab, CreateBlock(column+1, rows  ))
        table.insert(tab, CreateBlock(column  , rows-1))
        table.insert(tab, CreateBlock(column  , rows-2))
        
        for i = 1, 4 do
            tab[i].sprite.Set("Waves/Pacifist/tetris/blocky5")
            tab[i].sprite.color32 = {64, 64, 182}
        end
    elseif shape == "S" then
        table.insert(tab, CreateBlock(column  , rows  ))
        table.insert(tab, CreateBlock(column  , rows-1))
        table.insert(tab, CreateBlock(column+1, rows-1))
        table.insert(tab, CreateBlock(column+1, rows-2))
        
        for i = 1, 4 do
            tab[i].sprite.Set("Waves/Pacifist/tetris/blocky6")
            tab[i].sprite.color = {1, 1, 1}
        end
    elseif shape == "Z" then
        table.insert(tab, CreateBlock(column+1, rows  ))
        table.insert(tab, CreateBlock(column+1, rows-1))
        table.insert(tab, CreateBlock(column  , rows-1))
        table.insert(tab, CreateBlock(column  , rows-2))
        
        for i = 1, 4 do
            tab[i].sprite.Set("Waves/Pacifist/tetris/blocky7")
            tab[i].sprite.color32 = {255, 56, 12}
        end
    end
    
    -- Moves the shape, but cancels if it would hit a wall
    -- This function will only be called moving horizontally only or vertically only
    function tab.TryMove(x, y, no_star)
        lock = false
        
        for i = 1, #tab do
            local pos = tab[i].GetVar("GetPosition")()
            
            if pos.x + x < 1 or pos.x + x > columns then
                return false
            end
            
            if pos.y + y < 1 then
                lock = true
            else
                -- Check if there are any already-placed blocks underneath the current one
                
                for j = 1, #blocks do
                    if blocks[j].isactive then
                        local placed_pos = blocks[j].GetVar("GetPosition")()
                        
                        if pos.x + x == placed_pos.x and pos.y + y == placed_pos.y then
                            if y == 0 then
                                return false
                            else
                                lock = true
                            end
                        end
                    end
                end
            end
        end
        
        -- convert to obstacles and calculate platforms
        if lock then
            local x = (math.min(tab[1].absx, tab[2].absx, tab[3].absx, tab[4].absx) - (Arena.x - Arena.width/2) + tab[1].sprite.width/2) / 16
            
            -- test area directly below where the piece landed, extending all the way to the bottom of the Arena
            TestArea({x = x, y = 1,
                      w = ((math.max(tab[1].absx, tab[2].absx, tab[3].absx, tab[4].absx) - (Arena.x - Arena.width/2) + tab[1].sprite .width/2 + 16) / 16) - x,
                      h =  (math.min(tab[1].absy, tab[2].absy, tab[3].absy, tab[4].absy) - (Arena.y + 5     -    16) - tab[1].sprite.height/2) / 16}, true)
            
            for i = 1, #tab do
                tab[i].sprite.color = {tab[i].sprite.color[1]/2, tab[i].sprite.color[2]/2, tab[i].sprite.color[3]/2}
                
                
                -- this code was found to not work well, it was replaced by the TestArea call above
                --[[
                -- move player outside if applicable
                if  Player.absx - Player.sprite .width/2 > tab[i].absx - tab[i].sprite .width/2
                and Player.absx + Player.sprite .width/2 < tab[i].absx + tab[i].sprite .width/2
                and Player.absy - Player.sprite.height/2 < tab[i].absy + tab[i].sprite.height/2
                and Player.absy + Player.sprite.height/2 > tab[i].absy - tab[i].sprite.height/2 then
                    Player.MoveTo(Player.x, Arena.height/2, false)
                end
                ]]--
                
                
                table.insert(blocks, tab[i])
            end
            
            shape_timer = 10
            drop_timer = 30
            
            Audio.PlaySound("BeginBattle2", 0.5)
            
            -- Find all blocks with a free space above them
            local better_blocks = {}
            local blocks_to_check = {}
            
            for i = 1, #ALLblocks do
                if blocks[i] and blocks[i].isactive then
                    blocks_to_check[i] = true
                end
            end
            
            for i, block in pairs(blocks_to_check) do
                if blocks[i].isactive then
                    local pos = blocks[i].GetVar("GetPosition")()
                    for k, v in pairs(blocks) do
                        if blocks_to_check[k] then
                            local pos_check = v.GetVar("GetPosition")()
                            
                            if pos.x == pos_check.x and pos.y == pos_check.y + 1 then
                                blocks_to_check[k] = false
                                break
                            end
                        end
                    end
                end
            end
            
            for i = 1, #ALLblocks do
                
                -- SET BLOCK TO PLATFORM --
                
                if blocks_to_check[i] and tostring(blocks[i]) == "ProjectileController" then
                    
                    -- blocks[i].sprite.color = {0, 1, 0} -- COMMENT OUT TEST LINE
                    blocks[i]["safe"] = true
                    table.insert(better_blocks, blocks[i])
                
                -- REPLACE PROJECTILE WITH SPRITE IF NOT A PLATFORM --
                
                elseif tostring(blocks[i]) == "ProjectileController" and blocks[i].isactive then
                    -- replace with a sprite
                    local spr = CreateSprite(blocks[i].sprite.spritename, "Topper")
                    spr.MoveToAbs(blocks[i].absx, blocks[i].absy)
                    
                    spr["moov"] = function(x, y, no_star)
                        spr.Move(x * 16, y * 16)
                        
                        if not no_star then
                            CreateStar(spr.absx, spr.absy)
                        end
                    end
                    spr["GetPosition"] = function()
                        return {
                            x = columns + ((((spr.absx - Arena.x) + 8) - ((columns/2) * 16))/16),
                            y = rows + ((((spr.absy - (Arena.y + Arena.height/2 + 5)) + 8) - ((rows/2) * 16))/16)
                        }
                    end
                    
                    -- replace in blocks
                    for j = 1, #ALLblocks do
                        if blocks[j] == blocks[i] then
                            spr.color = blocks[i].sprite.color
                            -- spr.color = {0.2, 0.2, 0.2} -- COMMENT OUT TEST LINE
                            blocks[i].Remove()
                            blocks[i] = spr
                        end
                    end
                
                --[[
                -- just make it grey
                elseif tostring(blocks[i]) == "LuaSpriteController" and blocks_to_check[i] then
                    blocks[i].color = {0, 0, 1}
                ]]--
                end
            end
            
            blue.platforms = better_blocks
            
            return false
        end
        
        for i = 1, #tab do
            tab[i].GetVar("moov")(x, y, no_star)
        end
        return true
    end
    
    -- Rotates the shape. You know Tetris, you know how this works
    function tab.Rotate(dir)
        -- I: gets rotated  left twice
        -- L: gets rotated right  once and, separately, left once
        -- T: gets rotated right twice and, separately, left once
        -- O: ...
        -- J: gets rotated  left  once and, separately, right twice
        -- S: gets rotated right  once
        -- Z: gets rotated  left  once
        
        -- I
        if shape == "I" then
            -- become horizontal
            if tab.rotation % 2 == 0 then
                tab[1].GetVar("moov")(-1, -1, true)
                tab[3].GetVar("moov")( 1,  1, true)
                tab[4].GetVar("moov")( 2,  2, true)
                
            -- become vertical
            else
                tab[1].GetVar("moov")( 1,  1, true)
                tab[3].GetVar("moov")(-1, -1, true)
                tab[4].GetVar("moov")(-2, -2, true)
            end
        
        -- L
        elseif shape == "L" then
            if tab.rotation == 0 and dir == 1 then
                tab[1].GetVar("moov")( 1, -1, true)
                tab[2].GetVar("moov")( 2,  0, true)
                tab[4].GetVar("moov")(-1,  1, true)
            elseif tab.rotation == 0 and dir == -1 then
                tab[1].GetVar("moov")(-1, -1, true)
                tab[2].GetVar("moov")( 0, -2, true)
                tab[4].GetVar("moov")( 1,  1, true)
            end
        
        -- T
        elseif shape == "T" then
            if dir == 1 then
                if tab.rotation == 0 then
                    current_shape[1].GetVar("moov")( 1, -1, true)
                    current_shape[2].GetVar("moov")( 1,  1, true)
                    current_shape[4].GetVar("moov")(-1,  1, true)
                elseif tab.rotation == 1 then
                    current_shape[1].GetVar("moov")(-1, -1, true)
                    current_shape[2].GetVar("moov")( 1, -1, true)
                    current_shape[4].GetVar("moov")( 1,  1, true)
                elseif tab.rotation == 2 then
                    current_shape[1].GetVar("moov")(-1,  1, true)
                    current_shape[2].GetVar("moov")(-1, -1, true)
                    current_shape[4].GetVar("moov")( 1, -1, true)
                end
            elseif tab.rotation == 0 then
                current_shape[1].GetVar("moov")(-1, -1, true)
                current_shape[2].GetVar("moov")( 1, -1, true)
                current_shape[4].GetVar("moov")( 1,  1, true)
            end
        
        -- J
        elseif shape == "J" then
            if tab.rotation == 0 and dir == -1 then
                tab[1].GetVar("moov")(-1, -1, true)
                tab[2].GetVar("moov")(-2,  0, true)
                tab[4].GetVar("moov")( 1,  1, true)
            elseif tab.rotation == 0 and dir == 1 then
                tab[1].GetVar("moov")( 1, -1, true)
                tab[2].GetVar("moov")( 0, -2, true)
                tab[4].GetVar("moov")(-1,  1, true)
            elseif tab.rotation == 1 and dir == 1 then
                tab[1].GetVar("moov")(-1, -1, true)
                tab[2].GetVar("moov")(-2,  0, true)
                tab[4].GetVar("moov")( 1,  1, true)
            end
        
        -- S
        elseif shape == "S" then
            tab[1].GetVar("moov")( 1, -1, true)
            tab[3].GetVar("moov")(-1, -1, true)
            tab[4].GetVar("moov")(-2,  0, true)
        
        -- Z
        elseif shape == "Z" then
            -- if tab.rotation == 0 and dir == -1 then
                tab[1].GetVar("moov")( 0, -2, true)
                tab[2].GetVar("moov")(-1, -1, true)
                tab[4].GetVar("moov")(-1,  1, true)
            -- elseif tab.rotation == 0 and dir == 1 then
                -- tab[1].GetVar("moov")( 0, -2, true)
                -- tab[2].GetVar("moov")( 1, -1, true)
                -- tab[4].GetVar("moov")( 1,  1, true)
            -- end
        end
        
        tab.rotation = (tab.rotation + dir) % 4
    end
    
    return tab
end

-- Update star particles
function UpdateStars()
    for k, v in pairs(stars) do
        if v and v.isactive then
            v.rotation = v.rotation + v.GetVar("turnspeed")
            v.SetVar("turnspeed", v.GetVar("turnspeed") - (v.GetVar("turnspeed")/10))
            
            v.Move(math.sin(math.rad(v.GetVar("direction"))) * v.GetVar("distance"),
                math.cos(math.rad(v.GetVar("direction"))) * v.GetVar("distance"))
            v.SetVar("distance", v.GetVar("distance") - (v.GetVar("distance")/10))
            
            if v.GetVar("distance") < 0.5 then
                v.alpha = v.alpha - (1/10)
                
                if v.alpha <= 0 then
                    v.Remove()
                    v = nil
                end
            end
        end
    end
end

blocks = {}    -- blocks that HAVE BEEN PLACED
ALLblocks = {} -- EVERY block is added here on creation

timer = -60

-- queue system
queue = {}
queueTimer = 0

-- pass it a table of actions such as {one of ("left", "down", "right", "rotateL", "rotateR"), 0}
function AddToQueue(shape, actions)
    local item = {}
    
    item.highestTimerVal = 0
    for i = 1, #actions do
        item.highestTimerVal = actions[i][2] > item.highestTimerVal and actions[i][2] or item.highestTimerVal
    end
    
    item.actions = actions
    if shape then
        table.insert(item.actions, 1, {shape, 0})
    end
    item.nextAction = 1
    
    table.insert(queue, item)
end

do
    AddToQueue("I", {
        {   "down",  22},
        {"rotateL",  35},
        {   "down",  48},
        {   "left",  55},
        {"rotateL",  65},
        {   "down",  76},
        {   "left",  81},
        {   "left",  87},
        {   "left",  95},
        {   "down",  99},
        {   "down", 104},
        {   "down", 114},
        {   "down", 119},
        {   "down", 124},
        {   "down", 129},
        {   "down", 138},
        {   "down", 139},
    })
    AddToQueue("L", {
        {   "down",   9},
        {   "down",  35},
        {"rotateR",  42},
        {   "down",  61},
        {  "right",  71},
        {  "right",  81},
        {   "down",  89},
        {   "down",  94},
        {   "down",  98},
        {   "down", 103},
        {   "down", 108},
        {   "down", 113},
        {   "down", 117},
        {   "down", 122},
        {   "down", 127},
        {   "down", 128},
    })
    AddToQueue("T", {
        {   "down",   9},
        {   "down",  35},
        {   "down",  59},
        {   "down",  84},
        {   "down", 110},
        {   "down", 119},
        {"rotateR", 129},
        {"rotateR", 138},
        {   "down", 142},
        {   "down", 147},
        {   "down", 152},
        {   "down", 156},
        {   "down", 161},
        {   "down", 162},
    })
    AddToQueue("O", {
        {   "down",   9},
        {   "left",  23},
        {   "down",  36},
        {   "left",  49},
        {   "down",  62},
        {   "down",  88},
        {   "down", 113},
        {   "down", 137},
        {   "down", 163},
        {  "right", 173},
        {  "right", 182},
        {   "down", 191},
        {  "right", 196},
        {  "right", 205},
        {  "right", 214},
        {   "down", 221},
        {  "right", 226},
        {   "down", 235},
        {   "down", 240},
        {   "down", 244},
        {   "down", 245},
    })
    AddToQueue("J", {
        {   "down",   9},
        {   "down",  33},
        {   "down",  59},
        {   "down",  84},
        {   "down",  99},
        {   "down", 125},
        {   "down", 150},
        {"rotateL", 163},
        {   "down", 166},
        {   "left", 176},
        {   "left", 185},
        {   "down", 193},
        {   "down", 199},
        {   "down", 204},
        {   "down", 208},
        {   "down", 209},
    })
end

function Queue2ndPhase()
    AddToQueue("S", {
        {   "down",   9},
        {   "down",  34},
        {   "down",  60},
        {   "down",  85},
        {   "down", 110},
        {   "down", 135},
        {   "down", 160},
        {"rotateR", 170},
        {   "left", 180},
        {   "down", 188},
        {   "left", 194},
        {   "down", 202},
        {   "down", 207},
        {   "down", 208},
    })
        AddToQueue(nil, { {{x =  3, y =  1, w = 2, h = 2}, 0} }) -- tested? ✓
    AddToQueue("Z", {
        {   "down",   9},
        {   "down",  34},
        {   "down",  59},
        {   "down",  85},
        {   "down", 110},
        {   "down", 135},
        {   "down", 160},
        {   "down", 186},
        {  "right", 192},
        {   "down", 200},
        {  "right", 207},
        {   "down", 214},
        {   "down", 221},
        {   "down", 222},
    })
    AddToQueue("T", {
        {   "down",   9},
        {   "down",  35},
        {   "down",  61},
        {   "down",  86},
        {   "down", 111},
        {   "down", 136},
        {   "down", 162},
        {"rotateL", 187},
        {   "down", 201},
        {  "right", 214},
        {   "down", 221},
        {   "down", 228},
        {   "down", 229},
    })
    AddToQueue("J", {
        {   "down",  10},
        {  "right",  20},
        {  "right",  31},
        {   "down",  37},
        {  "right",  43},
        {  "right",  54},
        {   "down",  59},
        {   "down",  65},
        {   "down",  70},
        {   "down",  74},
        {   "down",  79},
        {   "down",  84},
        {   "down",  89},
        {   "down",  93},
        {   "down",  94},
    })
        AddToQueue(nil, { {{x = 10, y =  2, w = 1, h = 1}, 0} }) -- tested? ✓
    AddToQueue("I", {
        {   "down",   9},
        {   "down",  34},
        {   "down",  60},
        {   "down",  85},
        {   "down", 110},
        {"rotateL", 120},
        {  "right", 129},
        {   "down", 137},
        {   "down", 143},
        {   "down", 148},
        {   "down", 149},
        {   "down", 150},
    })
    AddToQueue("L", {
        {   "down",  10},
        {   "left",  19},
        {   "left",  28},
        {   "down",  37},
        {   "left",  44},
        {   "down",  52},
        {   "down",  56},
        {   "down",  61},
        {   "down",  66},
        {   "down",  71},
        {   "down",  75},
        {   "down",  80},
        {   "down",  81},
    })
        AddToQueue(nil, { {{x =  1, y =  4, w = 1, h = 1}, 0} }) -- tested? ✓
    AddToQueue("O", {
        {   "down",  10},
        {   "left",  19},
        {   "left",  28},
        {   "down",  33},
        {   "down",  38},
        {   "down",  42},
        {   "down",  48},
        {   "down",  53},
        {   "down",  57},
        {   "down",  62},
        {   "down",  67},
        {   "down",  68},
    })
    AddToQueue("Z", {
        {   "down",  10},
        {"rotateL",  19},
        {  "right",  30},
        {   "down",  37},
        {   "down",  42},
        {   "down",  47},
        {   "down",  52},
        {   "down",  57},
        {   "down",  61},
        {   "down",  62},
    })
        AddToQueue(nil, { {{x =  5, y =  5, w = 1, h = 1}, 0} }) -- tested? ✓
    AddToQueue("S", {
        {   "down",  10},
        {  "right",  20},
        {  "right",  29},
        {   "down",  38},
        {  "right",  47},
        {  "right",  57},
        {   "down",  65},
        {   "down",  70},
        {   "down",  75},
        {   "down",  80},
        {   "down",  85},
        {"rotateR",  93},
        {   "down", 100},
    })
        AddToQueue(nil, { {{x = 10, y =  5, w = 1, h = 1}, 0} }) -- tested? ✓ maybe unnecessary
    AddToQueue("J", {
        {   "down",   9},
        {  "right",  18},
        {  "right",  28},
        {   "down",  36},
        {  "right",  46},
        {"rotateR",  53},
        {"rotateR",  61},
        {   "down",  66},
        {   "down",  71},
        {   "down",  76},
        {   "down",  81},
        {   "down",  82},
    })
    AddToQueue("I", {
        {   "down",   9},
        {   "left",  16},
        {   "down",  23},
        {   "down",  28},
        {   "down",  32},
        {   "down",  38},
        {   "down",  39},
    })
    AddToQueue("L", {
        {   "down",  10},
        {"rotateL",  16},
        {   "left",  24},
        {   "left",  31},
        {   "left",  38},
        {   "down",  46},
        {   "down",  53},
        {   "down",  60},
        {   "down",  67},
        {   "down",  74},
        {   "down",  75},
    })
        AddToQueue(nil, { {{x =  2, y =  6, w = 2, h = 1}, 0} }) -- tested? ✓
    AddToQueue("O", {
        {   "down",   9},
        {  "right",  17},
        {  "right",  24},
        {  "right",  31},
        {  "right",  38},
        {   "down",  46},
        {   "down",  52},
        {   "down",  60},
        {   "down",  67},
        {   "down",  74},
        {   "down",  75},
    })
    AddToQueue("S", {
        {   "down",  10},
        {"rotateR",  17},
        {  "right",  24},
        {   "down",  31},
        {   "down",  39},
        {   "down",  45},
        {   "down",  57},
        {   "down",  58},
    })
        AddToQueue(nil, { {{x =  7, y =  7, w = 1, h = 1}, 0} }) -- tested? ✓
    AddToQueue("T", { -- this is the weird one
        {"rotateR",   4},
        {"rotateR",   8},
        {   "down",   9},
        {"rotateR",  16},
        {   "left",  23},
        {   "left",  31},
        {   "left",  38},
        {   "down",  45},
        {   "down",  52},
        {   "down",  60},
        {   "down",  61},
    })
        AddToQueue(nil, { {{x =  1, y =  8, w = 3, h = 1}, 0} }) -- tested? ✓✓
    AddToQueue("Z", {
        {   "down",   9},
        {"rotateR",  17},
        {  "right",  23},
        {   "down",  31},
        {   "down",  38},
        {   "down",  39},
    })
        AddToQueue(nil, { {{x =  5, y =  8, w = 1, h = 2}, 0} }) -- tested? ✓ works but hurts you because you teleport straight to the next bullet, but oh well
    AddToQueue("L", {
        {   "down",   9},
        {"rotateL",  17},
        {  "right",  24},
        {  "right",  31},
        {  "right",  38},
        {  "right",  46},
        {   "down",  52},
        {   "down",  60},
        {   "down",  61},
    })
        AddToQueue(nil, { {{x =  9, y =  9, w = 2, h = 1}, 0} }) -- tested? ✓
    AddToQueue("J", {
        {   "down",   9},
        {"rotateR",  16},
        {   "left",  24},
        {   "left",  31},
        {   "left",  37},
        {   "down",  45},
        {   "down",  46},
    })
        AddToQueue(nil, { {{x =  1, y = 10, w = 2, h = 1}, 0} }) -- tested? ✓
    AddToQueue("I", {
        {"rotateL",  10},
        {   "down",  17},
        {   "down",  34},
        {   "down",  35},
    })
        AddToQueue(nil, { {{x =  4, y = 10, w = 4, h = 1}, 0} }) -- tested? ✓✓
    AddToQueue("O", {
        {   "down",   9},
        {  "right",  16},
        {  "right",  23},
        {  "right",  31},
        {  "right",  37},
        {   "down",  45},
        {   "down",  46},
    })
    AddToQueue("O", {
        {   "down",   9},
        {   "left",  17},
        {   "left",  24},
        {   "left",  31},
        {   "left",  39},
        {   "down",  40},
    })
    AddToQueue("Z", {
        {   "down",   30},
    })
end

-- pass it a table of {x = 1, y = 1, w = 1, h = 1} for only bottom left corner
function TestArea(area, errorCheck)
    -- parse area
    local x = (Arena.x - Arena.width/2) + ((area.x - 1) * 16)
    local y =  Arena.y + 5              + ((area.y - 1) * 16)
    
    --[[
    if errorCheck then
        local test = CreateSprite("bullet", "Toppest")
        test.SetPivot(0, 0)
        test.MoveToAbs(x, y)
        test.Scale(area.w, area.h)
    end
    ]]--
    
    -- check if player is in area
    if  Player.absx + Player.sprite. width/2 > x and Player.absx - Player.sprite. width/2 < x + (area.w * 16)
    and Player.absy + Player.sprite.height/2 > y and Player.absy - Player.sprite.height/2 < y + (area.h * 16) then
        
        -- possibly play sound to indicate the player was caught cheating?
        -- if I want to do this, I'll have to provide a second argument to this function for if it's an error check or an actual secret hole
        -- nah, I decided not to do this after all
        Player.MoveTo(Player.x, Arena.height/2, false)
    end
end


countToPhase2 = 0

function Update()
    local oldy = Player.y
    blue.Update()
    
    
    
    -- loop through all blocks to check for collision
    if countToPhase2 < 73 and (Input.Left > 0 or Input.Right > 0 or Player.y ~= oldy) then
        for i = 1, #ALLblocks do
            if blocks[i] and blocks[i].isactive and math.abs(blocks[i].absx - Player.absx) < 16 and math.abs(blocks[i].absy - Player.absy) < 16 then
                
                -- CHECK FOR COLLISION HERE --
                -- I don't need to worry about the player still being inside a block because I will spawn hurt regions as phase 2 goes on
                
                -- moving  left (so right side of block)
                if     Player.absx - Player.sprite.width/2 <  blocks[i].absx + (tostring(blocks[i]) == "LuaSpriteController" and blocks[i] or blocks[i].sprite).width/2
                   and Player.absx - Player.sprite.width/2 >= blocks[i].absx then
                    Player.absx = blocks[i].absx + (tostring(blocks[i]) == "LuaSpriteController" and blocks[i] or blocks[i].sprite).width/2 + Player.sprite.width/2
                    break
                
                -- moving right (so  left side of the block)
                elseif Player.absx + Player.sprite.width/2 >  blocks[i].absx - (tostring(blocks[i]) == "LuaSpriteController" and blocks[i] or blocks[i].sprite).width/2
                   and Player.absx + Player.sprite.width/2 <  blocks[i].absx then
                    Player.absx = blocks[i].absx - (tostring(blocks[i]) == "LuaSpriteController" and blocks[i] or blocks[i].sprite).width/2 - Player.sprite.width/2
                    break
                end
            end
        end
    end
    
    
    
    local queueItem = queue[1]
    if queueItem then
        local timer = timer - queueTimer
        
        if timer <= queueItem.highestTimerVal then
            local action = queueItem.actions[queueItem.nextAction]
            
            if timer == action[2] then
                -- handle action
                
                -- first: spawn piece
                if action[1] == "I" or action[1] == "O" or action[1] == "T" or action[1] == "L" or action[1] == "J" or action[1] == "S" or action[1] == "Z" then
                    -- SFX
                    Audio.PlaySound("Waves/home")
                    current_shape = CreateShape(action[1], 5)
                    
                    -- update preview to next block
                    preview.Set("Waves/Pacifist/tetris/".. ((queue[2] and #queue[2].actions > 1) and queue[2].actions[1][1] or queue[3] and queue[3].actions[1][1] or "S"))
                    preview.xpivot = (string.endsWith(preview.spritename, "L") or string.endsWith(preview.spritename, "T")) and 16/preview.width or 0
                    preview.alpha = 0.25
                    preview.SendToTop()
                
                -- second: move
                elseif action[1] == "left" or action[1] == "down" or action[1] == "right" then
                    -- SFX
                    if action[1] ~= "down" then
                        Audio.PlaySound("menumove")
                    end
                    
                    current_shape.TryMove(action[1] == "left" and -1 or action[1] == "right" and 1 or 0, action[1] == "down" and -1 or 0, queueItem.nextAction < #queueItem.actions - 1)
                
                -- third: rotate
                elseif action[1] == "rotateL" or action[1] == "rotateR" then
                    -- SFX
                    Audio.PlaySound("menuconfirm")
                    
                    current_shape.Rotate(action[1] == "rotateL" and -1 or 1)
                
                -- fourth: define out of bounds area
                -- define in this format: {x = 1, y = 1, w = 1, h = 1} for only bottom left corner
                elseif type(action[1]) == "table" then
                    TestArea(action[1])
                end
                
                queueItem.nextAction = queueItem.nextAction + 1
            end
        else
            table.remove(queue, 1)
            queueTimer = _G["timer"] + 21
        end
    else
        countToPhase2 = countToPhase2 + 1
        
        -- flash the bottom row
        if countToPhase2 == 1 then
            Audio.PlaySound("saved")
        elseif countToPhase2%8 == 0 and countToPhase2 < 72 then
            for i = 1, #ALLblocks do
                local block = blocks[i]
                -- handle block
                if block and block.isactive and block["GetPosition"]().y == 1 then
                    (tostring(block) == "LuaSpriteController" and block or block.sprite).alpha = (countToPhase2/8) % 2
                end
            end
        -- actually remove the line
        elseif countToPhase2 == 72 then
            for i = 1, #ALLblocks do
                local block = blocks[i]
                -- handle block
                if block and block.isactive and block["GetPosition"]().y == 1 then
                    block.Remove()
                end
            end
            
            for i = 1, #ALLblocks do
                if blocks[i] and blocks[i].isactive then
                    -- move down by 1
                    blocks[i].GetVar("moov")(0, -1, false)
                end
            end
            
            if blue.CheckIfGrounded() then
                blue.SetJump(0.1)
            end
            
            Queue2ndPhase()
            queueTimer = timer + 1
        
        -- AFTER phase 2
        elseif countToPhase2 == 73 then
            preview.Remove()
            blue.SetJump(0.1)
            Misc.ShakeScreen(20, 10, true)
            Audio.PlaySound("bigkill")
            
            
            
            -- for some reason the last shape doesn't turn into sprites automatically, so I'm doing this which works perfectly
            table.insert(blocks, current_shape[1])
            table.insert(blocks, current_shape[2])
            table.insert(blocks, current_shape[3])
            table.insert(blocks, current_shape[4])
            
            local newblocks = {}
            
            -- replace all projectiles with sprites
            for i = 1, #ALLblocks + 4 do
                if blocks[i] and blocks[i].isactive then
                    local blocc = blocks[i]
                    local spr = CreateSprite((tostring(blocc) == "LuaSpriteController" and blocc or blocc.sprite).spritename, "Topper")
                    spr.SetParent(Encounter["fakearena"].arena)
                    spr.MoveBelow(Player.sprite.userdata)
                    spr.MoveToAbs(blocc.absx, blocc.absy)
                    spr.color = (tostring(blocc) == "LuaSpriteController" and blocc or blocc.sprite).color
                    blocc.Remove()
                    newblocks[spr] = true
                end
            end
            
            blocks = newblocks
            
            
            -- create channel for thing
            NewAudio.CreateChannel("thing")
        elseif countToPhase2 > 74 and (countToPhase2 - 74)%3 == 0 and (countToPhase2 - 74)/3 < (columns * rows) then
            local num = (countToPhase2 - 74)/3
            
            local x = (num % columns) == 0 and columns or (num % columns)
            local y = math.floor((num - 1) / columns) + 1
            
            -- remove the matching blocc
            for blocc in next, blocks, blocc do
                if  columns + ((((blocc.absx - Arena.x) + 8) - ((columns/2) * 16))/16) == x
                and rows + ((((blocc.absy - (Arena.y + Arena.height/2 + 5)) + 8) - ((rows/2) * 16))/16) == y then
                    NewAudio.PlaySound("thing", "BeginBattle2", false, 0.5)
                    NewAudio.SetPitch("thing", 0.5 + ((countToPhase2 - 74)/3) / (columns * rows))
                    
                    blocc.color = {1, 1, 1, 0.25}
                    break
                end
            end
            
            
            
            -- FADE OUT MUSIC
            Encounter["enemies"][1].Call("FadeOutAudio", "5")
        
        -- KILL EM ALL --
        elseif (countToPhase2 - 74)/3 == (columns * rows) + 10 then
            -- destroy ALL blocks
            for spr in next, blocks, spr do
                if spr and type(spr) == "userdata" and spr.isactive then
                    spr.Remove()
                end
            end
            
            -- create image that looks exactly like the full arrangement of bullets
            compwete = CreateSprite("Waves/Pacifist/tetris/compwete", "Topper")
            compwete.SetParent(Encounter["fakearena"].arena)
            compwete.MoveBelow(Player.sprite.userdata)
            compwete.MoveToAbs(Arena.x, Arena.y + Arena.height/2 + 5)
            
            -- just make these images fade out with the dust sound if playing in performance mode
            if not safe then
                -- also kill the grid
                grid.Dust(true, true)
                
                compwete.Dust(true, true)
                compwete = nil
            else
                Audio.PlaySound("enemydust")
                grid.MoveAbove(compwete)
            end
            
        
        elseif safe and (countToPhase2 - 74)/3 > (columns * rows) + 10 and (countToPhase2 - 74)/3 < (columns * rows) + 60 then
            grid    .alpha = grid    .alpha - (1/180)
            compwete.alpha = compwete.alpha - (1/120)
        
        -- END OF WAVE --
        
        elseif (countToPhase2 - 74)/3 == (columns * rows) + 60 then
            if safe then
                grid.Remove()
                compwete.Remove()
                compwete = nil
            end
            
            if windows then
                Misc.WindowName = "..."
            end
            
            EndWave()
        end
    end
    
    UpdateStars()
    timer = timer + 1
    
    
    
    -- manual player hurting animation
    if Player.isHurting then
        Player.invulTimer = Player.invulTimer - 1
        
        if Player.invulTimer <= 0 then
            Player.sprite.alpha = Player.sprite.alpha * 2
            Player.invulTimer = 0
        end
    end
end



-- Update function used for intro and whatnot

local introtimer = 0 -- 369
Encounter["enemies"][1].Call("SetSprite", "poseur_float")

star = CreateSprite("Waves/Geno1/portal0", "Topper")
star.MoveToAbs(340, 360)
star.SetAnimation({"portal0", "portal1", "portal2", "portal3"}, 1/5, "Waves/Geno1")
star.loopmode = "ONESHOT"

Audio.PlaySound("transform1")

grid.alpha = 0
Player.sprite["outline"].alpha = 1
Player.sprite.color = {1, 0, 0}

local _upd = Update
function Update()
    introtimer = introtimer + 1
    
    if introtimer < 120 then
        star.rotation = star.rotation + (introtimer/16)
    elseif introtimer == 120 then
        Audio.PlaySound("shield/remove")
        Misc.ShakeScreen(8, 16, false)
        Player.sprite["outline"].Remove()
        Player.sprite["outline"] = nil
        
        shield = CreateSprite("shield/shield", "Topper")
        shield.MoveToAbs(Player.absx, Player.absy)
        shieldvel = 2
        
        star.SetAnimation({"portal3", "portal2", "portal1", "portal0"}, 1/5, "Waves/Geno1")
    elseif introtimer < 200 then
        star.rotation = star.rotation + (introtimer/8)
        star.alpha = star.alpha - (1/60)
        
        shield.rotation = shield.rotation - 2
        shield.x = shield.x + 1
        shieldvel = shieldvel - 0.1
        shield.y = shield.y + shieldvel
    elseif introtimer == 200 then
        Encounter["enemies"][1].Call("SetSprite", "poseur")
        
        star.Remove()
        shield.Remove()
        grid.alpha = 0.125
        cover = CreateSprite("black", "Topper")
        Audio.PlaySound("BeginBattle2", 1)


        Audio.Stop()
        Encounter.Call("loadstring", "musicIntroLoop.Stop()")



        -- play music
        Encounter.Call("loadstring", "musicIntroLoop.StartSong(\"Tetris Type A Remix (Intro)\", \"Tetris Type A Remix (Loop)\", 13.443)")

        if windows then
            Misc.WindowName = "What could it be...?"
        end
    elseif introtimer == 570 then
        cover.Remove()
        Audio.PlaySound("BeginBattle2", 1)
        
        Player.sprite.color = {0,0.23,1}
        Audio.PlaySound("ding")
        Player.MoveTo(0, 0)
        
        Update = _upd
        
        if windows then
            Misc.WindowName = "It's Tetris."
        end
    end
end



function OnHit(bullet)
    if not bullet["safe"] and (countToPhase2 <= 1 or (countToPhase2 >= 72 and #queue > 1)) then
        Player.Hurt(2, 2)
        blue.SetJump(0)
        Player.MoveTo(Player.x, Arena.height/2, false)
    end
end

function EndingWave()
    if preview.isactive then
        preview.Remove()
    end
    
    if grid.isactive then
        grid.Remove()
    end
    
    if compwete then
        compwete.Remove()
    end
    
    for spr in next, blocks, spr do
        if spr and type(spr) == "userdata" and spr.isactive then
            spr.Remove()
        end
    end
end
