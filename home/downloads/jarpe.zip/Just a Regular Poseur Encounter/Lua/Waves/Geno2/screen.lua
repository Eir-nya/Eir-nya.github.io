require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



shape = math.random(1, 4) -- Waves/Geno2/bullet.png, Waves/Geno2/heart.png, Waves/Geno2/menacing.png, Waves/Geno2/star.png

-- Waves/Screen/0800 - initial draw
-- Waves/Screen/0721 - finish drawing
-- Waves/Screen/0799 - throw drawing to arena
-- Waves/Screen/0798 - drawing lands

cover = CreateSprite("black", "Topper")
cover.Scale(1.1, 1.1)
cover.MoveBelow(Arena.sprite)
cover.alpha = 0

timer  =  0
sparks = {}

-- box stuff
do
    boxparent = CreateSprite("empty", "Topper")
    boxparent.MoveBelow(Arena.sprite)
    boxparent.y = 380

    box = CreateSprite("px", "Topper")
    box.SetAnchor(0.5, -2)
    box.ypivot = 2
    box.SetParent(boxparent)
    box.MoveTo(0, 0)
    box.Scale(Arena.width / 2.5, Arena.height / 2.5)
    box.color = {0, 0, 0, 0}

    left = CreateSprite("px", "Topper")
    left.SetParent(box)
    left.SetAnchor(0, 1)
    left.Scale(5/2.5, 0)
    left.SetPivot(1, 1)
    left.MoveTo(0, 0)
    
    right = CreateSprite("px", "Topper")
    right.SetParent(box)
    right.SetAnchor(1, 0)
    right.Scale(5/2.5, 0)
    right.SetPivot(0, 0)
    right.MoveTo(0, 0)
    
    top = CreateSprite("px", "Topper")
    top.SetParent(box)
    top.SetAnchor(1, 1)
    top.Scale(0, 5/2.5)
    top.SetPivot(1, 1)
    top.MoveTo(0, 0)
    
    bottom = CreateSprite("px", "Topper")
    bottom.SetParent(box)
    bottom.SetAnchor(0, 0)
    bottom.Scale(0, 5/2.5)
    bottom.SetPivot(0, 0)
    bottom.MoveTo(0, 0)
end

-- define sparkable area by shape
do
    -- DOG
    if shape == 1 then
        area = {
            -- four corners
            { x =  0, y =  0, w =  9, h =  7, r = -45 },
            { x =  0, y = 41, w =  9, h =  7, r =  45 },
            { x = 39, y =  0, w =  9, h =  7, r =  45 },
            { x = 39, y = 41, w =  9, h =  7, r = -45 },
            
            -- nose bottom left
            { x = 20, y = 20, w =  2, h =  2, r = -45 },
            -- nose bottom right
            { x = 26, y = 20, w =  3, h =  4, r =  45 },
            -- nose top left 
            { x = 20, y = 27, w =  2, h =  2, r =  45 },
            
            -- left eye, bottom
            { x =  8, y = 29, w =  6, h =  2, r =   0 },
            -- left eye, top
            { x =  8, y = 32, w =  6, h =  3, r =   0 },
            
            -- right eye, bottom
            { x = 32, y = 33, w =  6, h =  2, r =   0 },
            -- right eye, top
            { x = 32, y = 38, w =  6, h =  3, r =   0 },
            
            -- top of mouth
            { x =  8, y = 13, w = 33, h =  3, r =   0 },
            -- left side of mouth
            { x = 17, y =  3, w =  3, h = 10, r =  22 },
            -- right side of mouth
            { x = 28, y =  3, w =  4, h = 10, r = -22 },
            -- bottom of mouth
            { x = 19, y =  3, w = 11, h =  2, r =   0 }
        }
    
    -- HEART
    elseif shape == 2 then
        area = {
            -- top middle
            { x = 23, y = 42, w =  4, h =  3, r =   0 },
            -- top middle right
            { x = 27, y = 45, w =  4, h =  4, r =  45 },
            -- top right
            { x = 31, y = 48, w = 11, h =  2, r =   0 },
            
            -- right top
            { x = 42, y = 44, w =  4, h =  4, r = -45 },
            -- right
            { x = 45, y = 34, w =  3, h = 12, r =  90 },
            -- right bottom
            { x = 43, y = 28, w =  3, h =  6, r =  90 },
            -- right bottom bottom
            { x = 39, y = 22, w =  4, h =  6, r = -45 },
            -- bottom right top
            { x = 35, y = 17, w =  4, h =  5, r = -45 },
            -- bottom right
            { x = 26, y =  0, w =  8, h = 15, r =  90 },
            
            -- bottom left
            { x = 16, y =  0, w =  8, h = 15, r =  90 },
            -- bottom left top
            { x = 11, y = 17, w =  4, h =  5, r =  45 },
            -- left bottom bottom
            { x =  7, y = 22, w =  4, h =  6, r =  45 },
            -- left bottom
            { x =  4, y = 28, w =  3, h =  6, r =  90 },
            -- left
            { x =  2, y = 34, w =  3, h = 12, r =  90 },
            -- left top
            { x =  4, y = 44, w =  4, h =  4, r =  45 },
            
            -- top left
            { x =  8, y = 48, w = 11, h =  2, r =   0 },
            -- top middle left
            { x = 19, y = 45, w =  4, h =  4, r = -45 },
        }
    
    -- MENACING
    elseif shape == 3 then
        area = {
            { x = 10, y = 31, w = 21, h =  5, r =   0 },
            { x =  8, y = 34, w =  2, h =  2, r = -45 },
            { x =  4, y = 33, w =  2, h =  3, r =  45 },
            { x =  4, y = 23, w =  3, h =  6, r = -45 },
            { x =  8, y = 23, w =  4, h =  4, r =  45 },
            { x = 12, y = 26, w =  8, h =  2, r =   0 },
            { x = 20, y = 13, w =  2, h = 15, r =  90 },
            
            -- top of slope at bottom left, 0 from right
            { x = 17, y = 12, w =  5, h =  3, r =  45 },
            -- top of slope at bottom left, 1 from right
            { x = 10, y = 10, w =  7, h =  2, r =  45 },
            -- top of slope at bottom left, 2 from right
            { x =  5, y =  8, w =  5, h =  3, r =  45 },
            -- top of slope at bottom left, 3 from right
            { x =  0, y =  5, w =  5, h =  2, r =  45 },
            
            -- bottom left of slope at bottom left
            { x =  0, y =  0, w =  3, h =  2, r = -45 },
            
            -- bottom of slope at bottom left, 0 from left
            { x =  9, y =  0, w = 12, h =  3, r =  45 },
            -- bottom of slope at bottom left, 1 from left
            { x = 21, y =  3, w =  4, h =  2, r =  45 },
            
            -- right of slope at bottom left, 0 from bottom
            { x = 25, y =  5, w =  2, h =  4, r =  90 },
            -- right of slope at bottom left, 1 from bottom
            { x = 27, y =  9, w =  2, h = 10, r =  90 },
            -- right of slope at bottom left, 2 from bottom
            { x = 29, y = 19, w =  3, h =  6, r =  45 },
            -- right of slope at bottom left, 3 from bottom
            { x = 30, y = 29, w =  2, h =  2, r = -45 },
            
            -- left dot bottom
            { x = 23, y = 35, w =  8, h =  2, r =   0 },
            -- left dot left
            { x = 22, y = 38, w =  3, h = 10, r =  90 },
            -- left dot top
            { x = 23, y = 47, w =  8, h =  3, r =   0 },
            -- left dot right
            { x = 29, y = 36, w =  3, h = 14, r =  90 },
            
            -- right dot bottom
            { x = 35, y = 29, w =  6, h =  2, r =   0 },
            -- right dot bottom right
            { x = 40, y = 30, w =  3, h =  3, r =  45 },
            -- right dot right
            { x = 43, y = 32, w =  1, h =  7, r =  90 },
            -- right dot left
            { x = 34, y = 31, w =  2, h =  6, r =  90 },
            -- right dot top left
            { x = 35, y = 36, w =  3, h =  3, r =  45 },
            -- right dot top
            { x = 37, y = 38, w =  5, h =  2, r =   0 }
        }
    
    -- STAR
    else
        area = {
            -- top piece, left side, 1
            { x = 16, y = 32, w =  3, h =  7, r =  45 },
            -- top piece, left side, 2
            { x = 20, y = 39, w =  3, h =  7, r =  45 },
            -- top piece, left side, 3
            { x = 23, y = 44, w =  4, h =  6, r =  45 },
            -- top piece, right side, 1
            { x = 26, y = 44, w =  4, h =  6, r = -45 },
            -- top piece, right side, 2
            { x = 29, y = 36, w =  3, h =  7, r = -45 },
            -- top piece, right side, 3
            { x = 31, y = 32, w =  3, h =  7, r = -45 },
            
            -- right piece, top side
            { x = 33, y = 31, w = 17, h =  2, r =   0 },
            -- right piece, bottom side, 1
            { x = 46, y = 26, w =  4, h =  3, r =  45 },
            -- right piece, bottom side, 2
            { x = 42, y = 22, w =  4, h =  4, r =  45 },
            -- right piece, bottom side, 3
            { x = 38, y = 19, w =  4, h =  3, r =  45 },
            
            -- b-right piece, top side, 1
            { x = 38, y = 15, w =  3, h =  5, r = -45 },
            -- b-right piece, top side, 2
            { x = 41, y =  9, w =  3, h =  6, r = -45 },
            -- b-right piece, top side, 3
            { x = 44, y =  0, w =  3, h =  9, r =  90 },
            -- b-right piece, bottom side, 1
            { x = 37, y =  0, w =  4, h =  4, r = -45 },
            -- b-right piece, bottom side, 2
            { x = 32, y =  3, w =  5, h =  5, r = -45 },
            -- b-right piece, bottom side, 3
            { x = 29, y =  8, w =  3, h =  2, r = -45 },
            -- b-right piece, bottom side, 4
            { x = 25, y = 10, w =  4, h =  4, r = -45 },
            
            -- b-left piece, bottom side, 1
            { x = 21, y = 10, w =  4, h =  4, r =  45 },
            -- b-left piece, bottom side, 2
            { x = 18, y =  8, w =  3, h =  2, r =  45 },
            -- b-left piece, bottom side, 3
            { x = 12, y =  3, w =  5, h =  5, r =  45 },
            -- b-left piece, bottom side, 4
            { x =  8, y =  0, w =  4, h =  4, r =  45 },
            
            -- b-left piece, top side, 1
            { x =  3, y =  0, w =  3, h =  7, r =  90 },
            -- b-left piece, top side, 2
            { x =  4, y =  6, w =  4, h =  7, r =  45 },
            -- b-left piece, top side, 3
            { x =  8, y = 13, w =  4, h =  7, r =  45 },
            
            -- left piece, bottom side, 1
            { x =  8, y = 20, w =  4, h =  2, r = -45 },
            -- left piece, bottom side, 2
            { x =  4, y = 22, w =  4, h =  2, r = -45 },
            -- left piece, bottom side, 3
            { x =  0, y = 26, w =  4, h =  3, r = -45 },
            -- left piece, top side
            { x =  0, y = 31, w = 17, h =  2, r =   0 }
        }
    end
end

function Update()
    -- fade in cover
    if timer < 40 then
        cover.alpha = cover.alpha + (1/60)
    end
    
    -- move real...well, "real" arena down
    if timer == 20 then
        Arena.speed = Arena.speed / 6
        Arena.y = Arena.y - 60
    end
    
    -- begin to draw little box
    if timer == 50 then
        Audio.PlaySound("Waves/Screen/0800")
    
    -- part 1: draw left and right sides
    elseif timer > 50 and timer <= 100 then
        local val = ((timer - 50) / 50) * box.yscale
          left.yscale = val
         right.yscale = val
    
    -- part 2: draw top and bottom sides
    elseif timer > 120 and timer <= 170 then
        local val = ((timer - 120) / 50) * box.xscale
        box.alpha = box.alpha + (1/50)
           top.xscale = val
        bottom.xscale = val
    
    -- part 3: shape time
    elseif timer == 230 then
        Audio.PlaySound("Waves/Screen/0721")
        
        pic = CreateSprite("Waves/Geno2/" .. ({"bullet", "heart", "menacing", "star"})[shape], "Topper")
        pic.SetParent(box)
        pic.MoveTo(0, 0)
        pic.alpha = 0
        
        -- stretch to box
        pic.Scale(box.xscale / pic.width, box.yscale / pic.height)
    elseif timer > 230 and timer <= 260 then
        pic.alpha = (timer - 230) / 30
    
    -- part 4: slAM
    elseif timer == 320 then
        Audio.PlaySound("Waves/Screen/0799")
        
        white = CreateSprite("UI/sq_white", "Toppest", 1)
        white.Scale(700/4, 500/4)
        white.alpha = 0
    elseif timer > 320 and timer < 335 then
        white.alpha = white.alpha + (1/15)
        box.Scale((Arena.width/2.5) + (((timer-320) / 15) * (Arena.width - (Arena.width/2.5))), (Arena.height/2.5) + (((timer-320) / 15) * (Arena.height - (Arena.height/2.5))))
        pic.xscale = pic.xscale + (1/15)
        pic.yscale = pic.yscale + (1/15)
        
          left.yscale = box.yscale
         right.yscale = box.yscale
           top.xscale = box.xscale
        bottom.xscale = box.xscale
    
    -- part 5: impact
    elseif timer == 335 then
        bullet = CreateProjectile(pic.spritename, 0, 0)
        bullet.ppcollision = true
        bullet.sprite.Scale(Arena.width / bullet.sprite.width, Arena.height / bullet.sprite.height)
        
        left.Remove()
        right.Remove()
        top.Remove()
        bottom.Remove()
        box.Remove()
        boxparent.Remove()
        
        pic.Remove()
        
        Audio.PlaySound("Waves/Screen/0798")
        
        
        -- TEST: sparkable box test drawer
        --[[
        for i = 1, #area do
            local range = area[i]
            local spr = CreateSprite("px", "Topper")
            spr.SetPivot(0, 0)
            spr.color = {1, 1, 0, 0.5}
            spr.absx = (bullet.sprite.absx - ( bullet.sprite.width * bullet.sprite.xscale)/2) + (range.x * bullet.sprite.xscale)
            spr.absy = (bullet.sprite.absy - (bullet.sprite.height * bullet.sprite.yscale)/2) + (range.y * bullet.sprite.yscale)
            spr.Scale(range.w * bullet.sprite.xscale, range.h * bullet.sprite.yscale)
        end
        ]]--
        
        
    elseif timer > 335 then
		if timer == 336 then
			Misc.ShakeScreen(60, 10, true)
		end

        -- fade out stuff
        white.alpha = white.alpha - (1/20)
        cover.alpha = cover.alpha - (1/400)
        
        -- create sparks
        if timer%5 == 0 and not safe then
            local spark = CreateSprite("Waves/bolt1", "Toppest")
            spark.SetAnimation({"bolt1", "bolt2", "bolt3"}, 1/16, "Waves")
            spark.loopmode = "ONESHOTEMPTY"
            spark.SetPivot(math.random(0, 10) / 10, math.random(0, 10) / 10)
            
            -- choose a random position
            local range = area[math.random(#area)]
            spark.absx = (bullet.sprite.absx - ( bullet.sprite.width * bullet.sprite.xscale)/2) + (math.random(range.x, range.x + range.w) * bullet.sprite.xscale)
            spark.absy = (bullet.sprite.absy - (bullet.sprite.height * bullet.sprite.yscale)/2) + (math.random(range.y, range.y + range.h) * bullet.sprite.yscale)
            spark.rotation = range.r + 90 + math.random(-22, 22)
            
            sparks[spark] = true
        end
    end
    
    timer = timer + 1
end

function OnHit(bullet)
    Player.Hurt(3, 1)
end

function EndingWave()
    if cover then
        cover.Remove()
    end
    
    if box then
        left.Remove()
        right.Remove()
        top.Remove()
        bottom.Remove()
        box.Remove()
        boxparent.Remove()
    end
    
    for spark in next, sparks, spark do
        if spark.isactive then
            spark.Remove()
        end
    end
    
    Arena.speed = Arena.speed * 6

	Misc.StopShake()
	Misc.ResetCamera()
end
