require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



timer = -60
angletimer = 0
bullets = {}

SetPPCollision(true)

local angle = 40
for i = 1, 4 do
    local bul = CreateProjectile("Waves/Geno2/devilsknife", 0, 0)
    bul.x = math.sin(math.rad(angle)) * 200
    bul.y = math.cos(math.rad(angle)) * 200
    
    bul.sprite.alpha = 0
    bul["dir"] = bul.y < 0 and -1 or 1
    bul["ang"] = angle
    bullets[bul] = true
    
    angle = (angle + 90) % 360
end

function Update()
    -- fade in bullets
    if timer < 0 then
        for bul in next, bullets, bul do
            bul.sprite.alpha = bul.sprite.alpha + (1/60)
        end
    
    -- do stuff
    else
        angletimer = angletimer + (math.sin(math.rad(timer * 1.5)) * 1.5)
        
        local dist = math.cos(math.rad(timer * 2)) * 200
        
        if math.abs(dist) < 0.01 then
            Audio.PlaySound("Waves/scytheburst")
        end
        
        for bul in next, bullets, bul do
            bul.x = math.sin(math.rad(bul["ang"] + angletimer)) * dist
            bul.y = math.cos(math.rad(bul["ang"] + angletimer)) * dist
            bul.sprite.rotation = bul.sprite.rotation + (bul["dir"] * 2)
        end
    end
    
    
    
    timer = timer + 1
end

function OnHit(bullet)
    Player.Hurt(3, 1)
end

function EndingWave()
    SetPPCollision(false)
end
