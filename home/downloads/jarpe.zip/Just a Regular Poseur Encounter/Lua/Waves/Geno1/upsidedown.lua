require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



Arena.sprite.SetPivot(0.5, 0.5)
Arena.y = Arena.y + Arena.height/2

timer = -10
vel = 0

function Update()
    Encounter["Wave"][1]["timer"] = -200
    Encounter["Wave"][1]["frequency"] = 60
    
    Encounter["Wave"][2]["timer"] = -130
    
    function Update()
        if timer < 0 then
            goto bottom
        end
        
        if timer < 30 then
            vel = -math.sin(math.rad(timer * 4)) * 20
        elseif timer < 70 then
            vel = vel + math.sin(math.rad(timer * 3)) * 11.5
        elseif timer < 110 then
            vel = lerp(vel, 180, 0.05)
        elseif timer == 110 then
            Arena.rotation = 180
            
            Arena.sprite.ypivot = 0
            Arena.y = Arena.y + Arena.height/2
            Arena.sprite.y = Arena.sprite.y + Arena.height/2
            
            function Update() Arena.rotation = 180 end
            
            return
        end
        
        ::bottom::
        Arena.rotation = vel
        timer = timer + 1
    end
end

function lerp(a, b, t)
    return a + ((b - a) * t)
end

function EndingWave()
    Arena.y = 95
    Arena.sprite.y = 95
    Arena.rotation = 0
end
