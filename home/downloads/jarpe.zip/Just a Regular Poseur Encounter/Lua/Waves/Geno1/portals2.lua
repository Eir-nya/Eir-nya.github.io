require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



-- UPSIDE-DOWN VERSION of portals.lua

NewAudio.CreateChannel("fire")
NewAudio.PlaySound("fire", "Waves/Portals/0765", true, 0)

-- Waves/Portal/0796 - open portal
-- Waves/Portal/0764 - initial fire
-- Waves/Portal/0794 - close portal
-- Waves/Portal/0765 - fire loop

timer     =  -1
sparks    =  {}
frequency = 160

function Update()
    if timer >= 0 and timer % frequency == 0 then
        -- set new variables
        local x1, y1
        
        local side = math.random(1, 4)
        
        -- spawn above/below the arena
        if side < 3 then
            x1 = math.random(-( Arena.width/2) - 30, ( Arena.width/2) + 30)
            
            if side == 1 then
                y1 =  Arena.height/2 + 30
            else
                y1 = -Arena.height/2 - 30
            end
        
        -- spawn on left/right side of the arena
        else
            y1 = math.random(-(Arena.height/2) - 30, (Arena.height/2) + 30)
            
            if side == 3 then
                x1 = - Arena.width/2 - 30
            else
                x1 =   Arena.width/2 + 30
            end
        end
        
        -- calculate end position
        -- hardcoding for upside-down arena
        local angle = math.atan2(-Player.y - y1, x1 + Player.x) + math.rad(270)
        
        -- move end position
        local x2, y2 = x1 + math.sin(angle) * 60, y1 + math.cos(angle) * 60
        while (x2 < ( Arena.width/2) + 30 and x2 > ( -Arena.width/2) - 30)
          and (y2 < (Arena.height/2) + 30 and y2 > (-Arena.height/2) - 30) do
            x2 = x2 + math.sin(angle) * 5
            y2 = y2 + math.cos(angle) * 5
        end
        
        x1 = x1 + Arena.currentx
        x2 = x2 + Arena.currentx
        y1 = y1 + Arena.currenty - Arena.currentheight/2 -- hardcoding for upside-down arena
        y2 = y2 + Arena.currenty - Arena.currentheight/2
        
        Audio.PlaySound("Waves/Portals/0796")
        
        portal1 = CreateSprite("Waves/Geno1/portal0", "Topper")
        portal1.MoveToAbs(x1, y1)
        portal1.rotation = -math.deg(angle - math.rad(90))
        portal1.SetAnimation({"portal0", "portal1", "portal2", "portal3"}, 1/5, "Waves/Geno1")
        portal1.loopmode = "ONESHOT"
        portal1.Scale( 2, 2)
        
        portal2 = CreateSprite("Waves/Geno1/portal0", "Topper")
        portal2.MoveToAbs(x2, y2)
        portal2.rotation = -portal1.rotation
        portal2.SetAnimation({"portal0", "portal1", "portal2", "portal3"}, 1/5, "Waves/Geno1")
        portal2.loopmode = "ONESHOT"
        portal2.Scale(-2, 2)
        
        portal1.rotation = portal1.rotation
        portal2.rotation = portal2.rotation
        
        -- calculate distance for scaling
        dist = math.sqrt((portal2.x - portal1.x)^2 + (portal2.y - portal1.y)^2)
        
        
        beam = CreateProjectileAbs("Waves/Geno1/beam", portal1.absx, portal1.absy)
        beam.sprite.SetPivot(0, 0.5)
        beam.sprite.alpha = 0
        beam.sprite.yscale = 2
        beam.ppcollision = true
        beam.sprite.rotation = portal1.rotation
        
        -- left side of beam
        beamL = CreateSprite("Waves/Geno1/beam_base0", "Topper")
        beamL.SetAnimation({"beam_base0", "beam_base1", "beam_base2", "beam_base3", "beam_base4", "beam_base5"}, 1/14, "Waves/Geno1")
        beamL.SetParent(beam.sprite)
        beamL.SetAnchor(0, 0.5)
        beamL.xpivot = 1
        beamL.MoveTo(0, 0)
        beamL.alpha = 0
        beamL.yscale = 2
        beamL.rotation = beam.sprite.rotation
        
        -- right side of beam
        beamR = CreateSprite("Waves/Geno1/beam_base0", "Topper")
        beamR.SetAnimation({"beam_base0", "beam_base1", "beam_base2", "beam_base3", "beam_base4", "beam_base5"}, 1/14, "Waves/Geno1")
        beamR.SetParent(beam.sprite)
        beamR.SetAnchor(1, 0.5)
        beamR.xpivot = 1
        beamR.MoveTo(0, 0)
        beamR.alpha = 0
        beamR.Scale(-1, -2)
        beamR.rotation = beam.sprite.rotation
    
    -- expand beam
    elseif timer >= 0 and timer % frequency > 40 and timer % frequency <= 50 then
        NewAudio.SetVolume("fire", ((timer % frequency) - 40) / 15)
        
        beam.sprite.xscale = dist * (((timer % frequency) - 40) / 10)
        
        beam.sprite.alpha = 1
        beamL.alpha = 1
        if timer % frequency == 50 then
            beamR.alpha = 1
        end
        
        Misc.ShakeScreen(90, 2, true)
    
    -- close portals
    elseif timer >= 0 and timer % frequency == 120 then
        NewAudio.SetVolume("fire", 0)
        Audio.PlaySound("Waves/Portals/0794")
        
        portal1.SetAnimation({"portal3", "portal2", "portal1", "portal0"}, 1/5, "Waves/Geno1")
        portal1.loopmode = "ONESHOTEMPTY"
        portal2.SetAnimation({"portal3", "portal2", "portal1", "portal0"}, 1/5, "Waves/Geno1")
        portal2.loopmode = "ONESHOTEMPTY"
        
        beam.Remove()
        beamL.Remove()
        beamR.Remove()
        
        ClearSparks()
    
    -- forced thing aa
    elseif timer >= 0 and timer % frequency == frequency - 1 then
        portal1.Remove()
        portal2.Remove()
    end
    
    -- create sparks!
    if not safe then
        if beam and beam.isactive and beam.sprite.xscale > 1 and timer%8 == 0 then
            local spark = CreateSprite("Waves/bolt1", "Toppest")
            spark.SetAnimation({"bolt1", "bolt2", "bolt3"}, 1/16, "Waves")
            spark.loopmode = "ONESHOTEMPTY"
            
            local side = math.random(0, 1)
            
            spark.SetParent(tostring(beam) == "ProjectileController" and beam.sprite or beam)
            spark.SetAnchor(math.random(0, 20) / 20, side)
            spark.ypivot = side == 0 and 0.2 or 0.8
            spark.xscale = math.random(0, 1) == 0 and -1 or 1
            spark.MoveTo(0, 0)
            spark.rotation = beam.sprite.rotation -- spark.rotation = 0 -- spark.rotation = portal1.rotation
            
            sparks[spark] = true
        end
    end
    
    timer = timer + 1
end

-- clears all sparks
function ClearSparks()
    for spark in next, sparks, spark do
        if spark.isactive then
            spark.Remove()
        end
    end
end

function OnHit(bullet)
    Player.Hurt(3, 1)
end

function EndingWave()
    NewAudio.DestroyChannel("fire")
    
    if cover then
        cover.Remove()
    end
    
    if portal1 then
        portal1.Remove()
        portal2.Remove()
    end
    
    if beam then
        beam.Remove()
        beamL.Remove()
        beamR.Remove()
    end
    
    ClearSparks()
end
