require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



NewAudio.CreateChannel("spin")
NewAudio.CreateChannel("fire")
NewAudio.PlaySound("fire", "Waves/Portals/0765", true, 0)

-- make pointy arrows
do
    pointBL = CreateSprite("Waves/he point", "Topper")
    pointBL.SetParent(Arena.sprite)
    pointBL.SetAnchor(0, 0)
    pointBL.SetPivot(0, 0)
    pointBL.MoveTo( 20,  16)
    pointBL.Scale( 2,  2)

    pointBR = CreateSprite("Waves/he point", "Topper")
    pointBR.SetParent(Arena.sprite)
    pointBR.SetAnchor(1, 0)
    pointBR.SetPivot(0, 0)
    pointBR.MoveTo(-20,  16)
    pointBR.Scale(-2,  2)

    pointTL = CreateSprite("Waves/he point", "Topper")
    pointTL.SetParent(Arena.sprite)
    pointTL.SetAnchor(0, 1)
    pointTL.SetPivot(0, 0)
    pointTL.MoveTo( 20, -16)
    pointTL.Scale( 2, -2)

    pointTR = CreateSprite("Waves/he point", "Topper")
    pointTR.SetParent(Arena.sprite)
    pointTR.SetAnchor(1, 1)
    pointTR.SetPivot(0, 0)
    pointTR.MoveTo(-20, -16)
    pointTR.Scale(-2, -2)
end



Audio.PlaySound("ding")
Arena.sprite.SetPivot(0.5, 0.5)
Arena.y        =             95 + Arena.height/2
Arena.currenty = Arena.currenty + Arena.height/2
local height = Arena.currentheight
Arena.currentheight = 200



-- create stars
starU = CreateProjectile("Waves/Geno1/spinstar0", 0,             0)
starU.y = starU.y + starU.sprite.height/2 + 9
starU.sprite.rotation = 180
starU.sprite.alpha = 0
-- spin version of this star
starUSpin = CreateSprite("Waves/Geno1/spinstar1", "Topper")
starUSpin.SetParent(starU.sprite)
starUSpin.MoveTo(0, 0)
starUSpin.rotation = starU.sprite.rotation
starUSpin.alpha = 0

starD = CreateProjectile("Waves/Geno1/spinstar0", 0, -Arena.height)
starD.y = starD.y - starD.sprite.height/2
--
starD.sprite.alpha = 0
-- spin version of this star
starDSpin = CreateSprite("Waves/Geno1/spinstar1", "Topper")
starDSpin.SetParent(starD.sprite)
starDSpin.MoveTo(0, 0)
starDSpin.rotation = starD.sprite.rotation
starDSpin.alpha = 0



direction = math.random(0, 1) == 0 and -1 or 1
timer = -60
spinVel = 0
rot = 0
sparks = {}

Arena.currentheight = height

function Update()
    -- on the first frame of the wave, do stuff with the other wave
    Encounter["Wave"][1]["blue"].speed = 4
    
    -- REAL update function
    function Update()
        timer = timer + 1
        
        -- handle pointy arrows
        if timer <= 60 then
            pointBL.x =  20 + math.sin(math.rad(timer * 8)) * 4
            pointTL.x =  20 + math.sin(math.rad(timer * 8)) * 4
            pointBR.x = -20 - math.sin(math.rad(timer * 8)) * 4
            pointTR.x = -20 - math.sin(math.rad(timer * 8)) * 4
            
            if timer >= 40 and timer <= 60 then
                pointBL.alpha = pointBL.alpha - (1/20)
                pointBR.alpha = pointBL.alpha
                pointTL.alpha = pointBL.alpha
                pointTR.alpha = pointBL.alpha
            end
            
            if timer == 60 then
                pointBL.Remove()
                pointBR.Remove()
                pointTL.Remove()
                pointTR.Remove()
            end
        end
        
        -- fade in stars
        if timer >= 79 and timer < 110 then
            starU.sprite.alpha = starU.sprite.alpha + (1/30)
            starD.sprite.alpha = starD.sprite.alpha + (1/30)
        
        -- begin spinning
        elseif timer == 140 then
            NewAudio.PlaySound("spin", "Waves/spincharge_2",  true)
            NewAudio.PlaySound("spin", "Waves/spincharge_1", false)
        
        -- spin stuff
        elseif timer > 140 then
            if timer == 225 or NewAudio.isStopped("spin") then
                NewAudio.PlaySound("spin", "Waves/spincharge_2", true, 0.25)
            end
            
            spinVel = spinVel < 14 and spinVel + (1/6) or spinVel
            
            if spinVel > 4 then
                starUSpin.alpha = starUSpin.alpha + (1/10)
                starU.sprite.alpha = 1 - starUSpin.alpha
                starDSpin.alpha = starUSpin.alpha
                starD.sprite.alpha = starU.sprite.alpha
            end
            
            -- move stars up a bit 
            if spinVel < 14 then
                starU.y = starU.y - 0.125
                starD.y = starD.y + 0.125
            end
            
            starU.sprite.rotation = starU.sprite.rotation + (spinVel * direction)
            starD.sprite.rotation = starD.sprite.rotation - (spinVel * direction)
            
            rot = rot + (spinVel / 14) * direction
            
            
            
            --==============--
            -- portal stuff --
            --==============--
            
            if timer < 200 then
                goto rotate
            end
            
            local timer = (timer - 200) % 200
            
            -- spawn portals and beam
            if timer == 0 then
                --[[
                -- HOW TO FIND THE ACTUAL ABSOLUTE POSITION OF THE PLAYER WITH A ROTATED ARENA IN THIS MOD
                
                local ang = (90 - math.deg(math.atan2(Player.y, Player.x))) % 360
                ang = ang - (rot % 360)
                local dist = math.sqrt(Player.x^2 + Player.y^2)
                
                test.MoveToAbs(Arena.x + math.sin(math.rad(ang)) * dist, 95 + (Arena.height/2) + math.cos(math.rad(ang)) * dist)
                ]]--
                
                portaly = 95 + (Arena.height/2) + math.cos(math.rad(((90 - math.deg(math.atan2(Player.y, Player.x))) - rot) % 360)) * math.sqrt(Player.x^2 + Player.y^2)
                dist = 250
                
                Audio.PlaySound("Waves/Portals/0796")
                
                -- create portals --
                
                portal1 = CreateSprite("Waves/Geno1/portal0", "Topper")
                portal1.MoveToAbs(Arena.x - (dist/2), portaly)
                portal1.SetAnimation({"portal0", "portal1", "portal2", "portal3"}, 1/5, "Waves/Geno1")
                portal1.loopmode = "ONESHOT"
                portal1.Scale( 2, 2)
                
                portal2 = CreateSprite("Waves/Geno1/portal0", "Topper")
                portal2.MoveToAbs(Arena.x + (dist/2), portaly)
                portal2.SetAnimation({"portal0", "portal1", "portal2", "portal3"}, 1/5, "Waves/Geno1")
                portal2.loopmode = "ONESHOT"
                portal2.Scale(-2, 2)
                
                
                
                -- create beam --
                
                beam = CreateProjectileAbs("Waves/Geno1/beam", portal1.absx, portaly)
                beam.sprite.SetPivot(0, 0.5)
                beam.sprite.alpha = 0
                beam.sprite.yscale = 2
                beam.ppcollision = true
                
                -- left side of beam
                beamL = CreateSprite("Waves/Geno1/beam_base0", "Topper")
                beamL.SetAnimation({"beam_base0", "beam_base1", "beam_base2", "beam_base3", "beam_base4", "beam_base5"}, 1/14, "Waves/Geno1")
                beamL.SetParent(beam.sprite)
                beamL.SetAnchor(0, 0.5)
                beamL.xpivot = 1
                beamL.MoveTo(0, 0)
                beamL.alpha = 0
                beamL.yscale = 2
                beamL.rotation = beam.sprite.rotation
                
                -- right side of beam
                beamR = CreateSprite("Waves/Geno1/beam_base0", "Topper")
                beamR.SetAnimation({"beam_base0", "beam_base1", "beam_base2", "beam_base3", "beam_base4", "beam_base5"}, 1/14, "Waves/Geno1")
                beamR.SetParent(beam.sprite)
                beamR.SetAnchor(1, 0.5)
                beamR.xpivot = 1
                beamR.MoveTo(0, 0)
                beamR.alpha = 0
                beamR.Scale(-1, -2)
                beamR.rotation = beam.sprite.rotation
            
            -- expand beam
            elseif timer > 70 and timer <= 80 then
                NewAudio.SetVolume("fire", (timer - 70) / 15)
                
                beam.sprite.xscale = dist * ((timer - 70) / 10)
                
                beam.sprite.alpha = 1
                beamL.alpha = 1
                if timer == 80 then
                    beamR.alpha = 1
                end
                
                Misc.ShakeScreen(90, 2, true)
            
            -- close portals
            elseif timer == 150 then
                NewAudio.SetVolume("fire", 0)
                Audio.PlaySound("Waves/Portals/0794")
                
                portal1.SetAnimation({"portal3", "portal2", "portal1", "portal0"}, 1/5, "Waves/Geno1")
                portal1.loopmode = "ONESHOTEMPTY"
                portal2.SetAnimation({"portal3", "portal2", "portal1", "portal0"}, 1/5, "Waves/Geno1")
                portal2.loopmode = "ONESHOTEMPTY"
                
                beam.Remove()
                beamL.Remove()
                beamR.Remove()
                
                ClearSparks()
            end
            
            
            
            -- create sparks!
            if not safe then
                if beam and beam.isactive and beam.sprite.xscale > 1 and timer%8 == 0 then
                    local spark = CreateSprite("Waves/bolt1", "Toppest")
                    spark.SetAnimation({"bolt1", "bolt2", "bolt3"}, 1/16, "Waves")
                    spark.loopmode = "ONESHOTEMPTY"
                    
                    local side = math.random(0, 1)
                    
                    spark.SetParent(tostring(beam) == "ProjectileController" and beam.sprite or beam)
                    spark.SetAnchor(math.random(0, 20) / 20, side)
                    spark.ypivot = side == 0 and 0.2 or 0.8
                    spark.xscale = math.random(0, 1) == 0 and -1 or 1
                    spark.MoveTo(0, 0)
                    
                    sparks[spark] = true
                end
            end
        end
        
        -- rotate arena
        ::rotate::
        Encounter["fakearena"].offset[2] = 0
        Arena.rotation = rot
    end
end

-- clears all sparks
function ClearSparks()
    for spark in next, sparks, spark do
        if spark.isactive then
            spark.Remove()
        end
    end
end

function OnHit(bullet)
    if timer >= 110 then
        Player.Hurt(2, 1)
    end
end

function EndingWave()
    NewAudio.DestroyChannel("spin")
    NewAudio.DestroyChannel("fire")
    
    Arena.sprite.SetPivot(0.5, 0)
    Arena.y        = 95
    Arena.currenty = 95
    
    Player.sprite.color = {1, 0, 0}
    
    -- remove sprites
    if pointBL then
        pointBL.Remove()
        pointBR.Remove()
        pointTL.Remove()
        pointTR.Remove()
    end
    
    if starDSpin then
        starDSpin.Remove()
        starUSpin.Remove()
    end
    
    if portal1 then
        portal1.Remove()
        portal2.Remove()
    end
    
    if beam then
        beam.Remove()
        beamL.Remove()
        beamR.Remove()
    end
    
    ClearSparks()
end
