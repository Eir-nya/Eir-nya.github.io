require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



NewAudio.CreateChannel("home")



function ScaleAThingByRotation(spr, side, dir)
    -- okay it's big brain time
    --[[
    x of intersection = ((1 / slope) * target y) - ((1 / slope) * starting y)
    360 degree rotation to slope: slope = tan(rad(r))
    ]]--

    local targety    = dir and 0 or Arena.height
    local startingy  = spr.y
    local slope      = math.tan(math.rad(spr.rotation)) * (side and 1 or -1)
    local xintercept = ((1 / slope) * targety) - ((1 / slope) * startingy)  -- the x point where y = `targety`
    local dist       = math.sqrt(xintercept^2 + (targety - startingy)^2)
    spr.xscale = dist
    
    return {targety = targety, startingy = startingy, slope = slope, xintercept = xintercept, dist = dist}
end



--      dir: true = going down | false =   going up
--     side: true =  from left | false = from right
-- rotation: CCW
--     ypos: y-intercept, with 0 being bottom of arena
function Project(dir, side, rotation, ypos)
    if not ypos then ; ypos = 0 ; end
    
    if not side then
        dir = not dir
    end
    
    red1 = CreateSprite("UI/sq_white", "Topper")
    red1.SetPivot(0, 0.5)
    red1.SetAnchor(0, 0)
    red1.SetParent(Arena.sprite)
    red1.SendToBottom()
    red1.MoveTo(side and 0 or Arena.width, ypos)
    red1.color = {1, 0, 0}

    red1.rotation = rotation
    local results = ScaleAThingByRotation(red1, side, dir)
    red1.xscale = red1.xscale / 4
    red1.rotation = Arena.rotation + red1.rotation



    red2 = CreateSprite("UI/sq_white", "Topper")
    red2.SetPivot(0, 0.5)
    red2.SetAnchor(0, 0)
    red2.SetParent(Arena.sprite)
    red2.SendToBottom()
    red2.MoveTo(red1.x + (results.xintercept * (side and 1 or -1)), results.targety)
    red2.color = {1, 0, 0, 0.5}

    red2.rotation = -rotation
    local results = ScaleAThingByRotation(red2, side, not dir)
    red2.xscale = red2.xscale / 4
    red2.rotation = Arena.rotation + red2.rotation
    
    
    
    red3 = CreateSprite("UI/sq_white", "Topper")
    red3.SetPivot(0, 0.5)
    red3.SetAnchor(0, 0)
    red3.SetParent(Arena.sprite)
    red3.SendToBottom()
    red3.MoveTo(red2.x + (results.xintercept * (side and 1 or -1)), results.targety)
    red3.color = {1, 0, 0, 0.25}

    red3.rotation = rotation
    results = ScaleAThingByRotation(red3, side, dir)
    red3.xscale = red3.xscale / 4
    red3.rotation = Arena.rotation + red3.rotation
    
    if not side then
        red1.rotation = 180 + red1.rotation
        red2.rotation = 180 + red2.rotation
        red3.rotation = 180 + red3.rotation
    end
end

timer   = -1
bullets = {}

fadeOutAmount = (1/10)
speed = 3
bulletImage = "Waves/Geno1/star"
rotationSpeed = 10
frequency = 30

function Update()
    
    if timer < 0 then
        goto bottom
    end
    
    -- create red warning lines
    if timer % frequency == 0 then
        nextDir = ({[0] = true, [1] = false})[math.random(0, 1)]
        nextRot = math.random(40, 60)
        nextSide = ({[0] = true, [1] = false}) [timer % (frequency * 2) / frequency]
        local yintercept = math.random(1, 4) * 30
        
        Project(nextDir, nextSide, nextRot * ({[true] = -1, [false] = 1})[nextDir], yintercept)
        
        -- play sound
        NewAudio.PlaySound("home", "Waves/home", true, 0.75)
    -- fade out red warning lines
    elseif timer % frequency > frequency - 15 and timer % frequency < frequency - 5 then
        red1.alpha = red1.alpha - fadeOutAmount
        red2.alpha = red2.alpha - fadeOutAmount
        red3.alpha = red3.alpha - fadeOutAmount
        
        NewAudio.SetVolume("home", (((timer % frequency) - (frequency - 15)) / (frequency - 5)) * 0.75)
    -- create bullets
    elseif timer % frequency == frequency - 5 then
        local bul = CreateProjectileAbs(bulletImage, red1.absx, red1.absy)
        bul.ppcollision = true
        bul.sprite.SetParent(Arena.sprite)
        bul.sprite.rotation = Arena.rotation
        bul["xvel"] = math.sin(math.rad(nextRot + 90))
        bul["xvel"] = bul["xvel"] * (nextSide and  1 or -1)
        bul["yvel"] = math.cos(math.rad(nextRot - 90))
        bul["yvel"] = bul["yvel"] * ( nextDir and -1 or  1)
        bul["yvel"] = bul["yvel"] * (nextSide and  1 or -1)
        
        if not safe then
            for i = 1, 2 do
                local shadow = CreateSprite(bul.sprite.spritename, "Topper")
                shadow.SetParent(Arena.sprite)
                shadow.MoveBelow(bul.sprite)
                shadow.rotation = Arena.rotation
                shadow.MoveTo(bul.sprite.x, bul.sprite.y)
                shadow.alpha = (0.8 - (i / 3))
                bul["shadow" .. i] = shadow
            end
            
            bul["oldpos1"] = {bul.absx, bul.absy}
            bul["oldpos2"] = {bul.absx, bul.absy}
            bul["oldpos3"] = {bul.absx, bul.absy}
            bul["oldpos4"] = {bul.absx, bul.absy}
        end
        
        
        bullets[bul] = true
        
        red1.Remove()
        red2.Remove()
        red3.Remove()
        
        -- stop sound
        NewAudio.Stop("home")
    end
    
    -- update bullets
    for bul in next, bullets, bul do
        if not safe then
            bul["oldpos4"] = bul["oldpos3"]
            bul["oldpos3"] = bul["oldpos2"]
            bul["oldpos2"] = bul["oldpos1"]
            bul["oldpos1"] = {bul.absx, bul.absy}
        end
        
        if math.abs(bul.x) < Arena.width/2 then
            if bul["yvel"] < 0 and bul.y - bul.sprite.height/3 < -Arena.height/2
            or bul["yvel"] > 0 and bul.y + bul.sprite.height/3 >  Arena.height/2 then
                bul["yvel"] = -bul["yvel"]
            end
        end
        
        bul.Move(bul["xvel"] * speed, bul["yvel"] * speed)
        if bul["shadow1"] then
            bul["shadow1"].MoveToAbs(unpack(bul["oldpos2"]))
            bul["shadow2"].MoveToAbs(unpack(bul["oldpos4"]))
        end
        
        bul.sprite.rotation     = bul.sprite.rotation +  rotationSpeed
        if bul["shadow1"] then
            bul["shadow1"].rotation = bul.sprite.rotation -  rotationSpeed
            bul["shadow2"].rotation = bul.sprite.rotation - (rotationSpeed * 2)
        end
        
        -- remove if off srceen
        if math.abs(bul.x) > 330 then
            if not safe then
                bul["shadow1"].Remove()
                bul["shadow2"].Remove()
            end
            bul.Remove()
            bullets[bul] = nil
        end
    end
    
    
    
    ::bottom::
    timer = timer + 1
    Arena.rotation = Arena.rotation * 2
end

function OnHit(bullet)
    if not Player.isHurting then
        Player.Hurt(3, 1)
        if bullet["shadow1"] then
            bullet["shadow1"].Remove()
            bullet["shadow2"].Remove()
        end
        bullet.Remove()
        bullets[bullet["wrapped"]] = nil
    end
end

function EndingWave()
    if red1 and red1.isactive then
        red1.Remove()
        red2.Remove()
        red3.Remove()
    end
    
    for bul in next, bullets, bul do
        if bul["shadow1"] then
            bul["shadow1"].Remove()
            bul["shadow2"].Remove()
        end
        bul.Remove()
    end
    
    NewAudio.DestroyChannel("home")
end
