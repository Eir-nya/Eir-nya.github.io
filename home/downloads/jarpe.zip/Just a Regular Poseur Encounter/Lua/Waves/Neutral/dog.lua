require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



bark = ({ [1] = true, [2] = false })[math.random(1, 2)]

bullet = CreateProjectile(bark and "Waves/Neutral/dog_4" or "Waves/Neutral/dog_0", 120, -45)
bullet.sprite.alpha = 0
bullet.ppcollision = true

-- advanced stuff
do
    cover = CreateSprite("px", "Topper")
    cover.SetParent(Encounter["fakearena"].right)
    cover.MoveTo(0, 0)
    cover.color = {0, 0, 0}
    cover.SetPivot(0, 0.5)
    cover.SetAnchor(1, 0.5)
    cover.Scale(100, Encounter["fakearena"].right.yscale)
    cover.layer = "Topper"

    cover2 = CreateSprite("px", "Topper")
    cover2.SetParent(cover)
    cover2.Scale(5, cover.yscale)
    cover2.SetPivot(0, 0.5)
    cover2.SetAnchor(0, 0.5)
    cover2.MoveTo(0, 0)
end

local timer = 0

function Update()
    if resized then
        timer = timer + 1
    elseif Arena.currentwidth == Arena.width then
        resized = true
        bullet.sprite.alpha = 1
    end
    
    cover.absx = Encounter["fakearena"].right.absx
    
    -- advanced stuff
    if timer > 0 and timer < 20 then
        Arena.x = Arena.x + 2
        Arena.width = Arena.width + 4
        cover.absx = Encounter["fakearena"].right.absx + 3
        Player.x = Player.x - 2
    elseif timer == 30 then
        if bark then
            bullet.sprite.SetAnimation({"dog_4", "dog_5"}, 1/4, "Waves/Neutral/")
        else
            bullet.sprite.SetAnimation({"dog_1", "dog_2"}, 1/4, "Waves/Neutral/")
        end
        bullet.sprite.SetParent(Arena.sprite)
        bullet.sprite.SendToBottom()
    elseif bark and (timer == 80) then
        bullet.sprite.SetAnimation({"dog_5", "dog_6", "dog_4", "dog_6"}, 2/5, "Waves/Neutral/")
        bullet.sprite.SetParent(Arena.sprite)
        bullet.sprite.SendToBottom()
        lastframe = 1
    elseif bark and timer > 80 then
        -- VERY IMPROTANT dog boarking function
        if bullet.sprite.currentframe ~= lastframe and bullet.sprite.currentframe % 2 == 0 then
            Audio.PlaySound("wuf")
        end
        
        lastframe = bullet.sprite.currentframe
    end
end

function OnHit(bullet)
    Player.Hurt(1, 1)
end



function EndingWave()
    cover.Remove()
    cover2.Remove()
    bullet.sprite.StopAnimation()
    bullet.Remove()
end
