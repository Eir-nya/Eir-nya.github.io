require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



local parent = CreateSprite("empty", "Topper")
parent.MoveTo(Arena.x, Arena.y + Arena.height/2)

bullets = {}

for i = 1, 30 do
    local amount = i - 1
    local dist = 60
    
    local bullet = CreateProjectile("bullet", 0, 0)
    bullet.sprite.SetParent(parent)
    bullet.MoveTo(dist * math.sin(amount), dist * math.cos(amount))
    
    bullets[bullet] = true
end

timer = 0

function Update()
    timer = timer + 1
    
    parent.rotation = parent.rotation + 1.5
    
    for bullet in pairs(bullets) do
        bullet.sprite.rotation = 0
        
        if timer > 10 and timer < 80 then
            bullet.y = bullet.y - 0.75
        end
    end
end

function OnHit(bullet)
    if not Player.isHurting then
        Player.Hurt(1, 1)
        bullet.Remove()
        bullets[bullet] = nil
    end
end

function EndingWave()
    for bullet in next, bullets, bullet do
        bullet.Remove()
    end
    
    parent.Remove()
end
