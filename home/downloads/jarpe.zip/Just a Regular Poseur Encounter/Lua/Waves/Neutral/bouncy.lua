require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



bullet = CreateProjectile("boolet", math.random(-40, 40), 50)
bullet.sprite.MoveBelow(Arena.sprite)

timer = 0

dir = bullet.x <= 0 and 1 or -1
vely = 3

Audio.PlaySound("Waves/jump")

function Update()
    timer = timer + 1
    
    if timer > 0 and timer < 31 then
        vely = vely - (3/30)
        
        bullet.Move(dir, vely)
    elseif timer == 31 then
        vely = 0
        bullet.sprite.MoveAbove(Arena.sprite)
    -- regular wave stuff
    elseif timer > 0 then
        vely = vely - (5/30)
        
        bullet.Move(dir, vely)
        
        -- hit detection with walls
        if bullet.x - bullet.sprite.width/2 < -Arena.width/2
        or bullet.x + bullet.sprite.width/2 >  Arena.width/2 then
            dir = -dir
            bullet.Move(dir, 0)
        end
        
        -- hit detection with floor
        if bullet.y - bullet.sprite.height/2 < -Arena.height/2 then
            vely = 0
            bullet.MoveTo(bullet.x, -Arena.height/2 + bullet.sprite.height/2)
            
            Audio.PlaySound("Waves/drop")
            Misc.ShakeScreen(15, 3, true)
            timer = -18
        end
    elseif timer == 0 then
        Audio.PlaySound("Waves/jump")
        vely = 5 + (math.random(1, 10) / 10)
        
        timer = 32
    end
end



function OnHit(bullet)
    if timer < 1 or timer > 32 then
        Player.Hurt(3, 1)
    end
end
