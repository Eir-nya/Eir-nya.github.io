require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



NewAudio.CreateChannel("void")

bullets = {}
timer = -60

bg = CreateSprite("Waves/Geno3/space", "Topper", 2)
bg.alpha = 0
bg.y = bg.y - 360

Arena.speed = Arena.speed / 4

function Update()
    timer = timer + 1
    
    -- do glitchy movement awawawawa
    if timer < 60 and timer%8 == 0 then
        Audio.PlaySound("Waves/Static/s" .. math.random(1, 3))
        
        Arena.MoveToAndResize(math.random(100, 540), math.random(75, 125), math.random(100, 300), math.random(75, 200), false, true) 
        Player.MoveTo(0, 0)
        
        Arena.currentx = Arena.x + math.random(-10, 10)
        Arena.currenty = Arena.y + math.random(-10, 10)
        Arena.currentwidth = Arena.currentwidth + math.random(-10, 10)
        Arena.currentheight = Arena.currentheight + math.random(-10, 10)
    
    -- create cover
    elseif timer == 58 then
        Audio.PlaySound("flash")
        cover = CreateSprite("UI/sq_white", "Topper")
        cover.Scale(700/4, 500/4)
    
    -- enter the v o i d
    elseif timer == 60 then
        cover.Remove()
        
        if windows then
            Misc.WindowName = "The Void."
        end
        
        NewAudio.PlaySound("void", "Waves/void", true, 1)
        
        Encounter.Call("loadstring", "musicIntroLoop.Pause()")
        Encounter.Call("loadstring", "enemies[1]['anim'].glitch = false")
        Encounter.Call("loadstring", "enemies[1].Call(\"loadstring\", \"anim.gstatic.y = 480\")")
        Encounter.Call("loadstring", "enemies[1].Call(\"loadstring\", \"for art in next, anim.gartifacts, art do ; if art.isactive then ; art.Remove() ; anim.gartifacts[art] = nil ; end ; end\")")
        Encounter.Call("loadstring", "enemies[1].Call(\"loadstring\", \"for rub in next, anim.grubble, rub do ; if rub.isactive then ; rub.Remove() ; anim.grubble[rub] = nil ; end ; end\")")
        Encounter.Call("SetButtonLayer", "BelowArena")
        Encounter.Call("loadstring", "enemies[1].Call(\"loadstring\", \"anim.gcamoffset = {x = 0, y = 240}\")")
        Misc.MoveCameraTo(0, -250)
        
        -- workaround time
        Encounter["unescape"] = CYFversion == "0.6.3"
        
        Arena.MoveToAndResize(280 + (math.random() * 60), 50 + (math.random() * 40), 155, 130, false, true)
        Arena.rotation = -10 + (math.random() * 20)
        
        Player.MoveTo(0, 0)
        
        bg.alpha = 0.1
    
    -- animate void stuff
    elseif timer > 60 then
        if timer%90 == 0 then
            Arena.rotation = Arena.rotation + (Arena.rotation < 0 and -1 or 1) * 0.1
            Arena.x = Arena.x + (Arena.rotation < 0 and -1 or 1) * 0.2
            Arena.y = Arena.y - 1
            bg.y = bg.y + 0.2
        end
        
        bg.alpha    =    bg.alpha + (1/1000)
    end
    
    -- workaround time
    if Input.GetKey("Escape") == 1 and Encounter["unescape"] then
        function EndingWave() Misc.ResetCamera() end
        local stuff = (require "Libraries/fakeModSelect")(Encounter["debuggetinfo"])
        stuff.cover.layer = "Toppest"
        State("DONE")
    end
    
    
    
    --=============--
    -- ACTUAL WAVE --
    --=============--
    
    if timer > 90 then
        if timer%45 == 0 then
            local bullet = CreateProjectile("bullet", math.random(-45, 45), Arena.height/2)
            bullet.SetVar("velx", bullet.x > 0 and (-0.5 - (math.random() * 1.5)) or (0.5 + (math.random() * 1.5)))
            bullet.SetVar("vely", 0)
            
            -- flip
            if bullet.GetVar("velx") > 0 then
                bullet.sprite.xscale = -1
            end
            
            bullets[bullet] = true
        end
        
        -- update bullets
        for bullet in next, bullets, bullet do
            if bullet.x > -Arena.width/2 and bullet.x < Arena.width/2 and bullet.y - bullet.sprite.height/2 < -Arena.height/2 then
                bullet.SetVar("vely", 1.5)
            
            -- sad time
            elseif bullet.y < -Arena.height and not bullet.GetVar("sad") then
                if not sad then
                    sad = true
                    Audio.PlaySound("Waves/hurt", 0.2)
                end
                
                bullet.SetVar("sad", true)
                bullet.sprite.Set("Waves/Geno3/sadbullet")
                
                local flare = CreateSprite("Waves/Geno3/flare1", "Topper")
                flare.SetAnimation({"flare1", "flare2"}, 1/5, "Waves/Geno3")
                flare.SetParent(bullet.sprite)
                flare.MoveTo(0, 0)
                flare.xscale = bullet.sprite.xscale
                flare.rotation = bullet.sprite.rotation
                flare.alpha = 0
                
                bullet["flare"] = flare
            
            -- animate flare
            elseif bullet.GetVar("sad") then
                bullet["flare"].alpha = bullet["flare"].alpha + (1/240)
            end
            
            bullet.SetVar("vely", bullet.GetVar("vely") - 0.02)
            bullet.Move(bullet.GetVar("velx"), bullet.GetVar("vely"))
            
            bullet.sprite.rotation = (-math.deg(math.atan2(bullet.GetVar("vely"), math.abs(bullet.GetVar("velx"))))) / 2
        end
    end
end

function OnHit(bullet)
    if not Player.isHurting then
        Player.Hurt(2, 1, false)
        if bullet["flare"] and bullet["flare"].isactive then
            bullet["flare"].Remove()
        end
        bullet.Remove()
        bullets[bullet["wrapped"]] = nil
    end
end

function EndingWave()
	bg.Remove()
    
    Encounter["unescape"] = false
    
    NewAudio.DestroyChannel("void")
    
    Arena.speed = Arena.speed * 4
    Arena.MoveTo(320, 95)
    Arena.rotation = 0
    
    Encounter.Call("loadstring", "enemies[1].Call(\"loadstring\", \""
     .. "local cover = CreateSprite('UI/sq_white', 'Topper') ; "
     .. "cover.Scale(700/4, 500/4) ; "
     .. "Audio.PlaySound('flash', 1) ; "
     .. "local bool = false ; "
     
     .. "local updateFunc = function() ; "
     ..     "if not bool then ; "
     ..         "bool = true ; "
     ..     "else ; "
     ..         "cover.Remove() ;"
     ..         "return true ;"
     ..     "end ; "
     .. "end ; "
     .. "callbacks.AddCallback(updateFunc)"
     .. "\")"
    )
    
    Misc.ResetCamera()
    Misc.ShakeScreen(16, 30, true)
    Encounter.Call("loadstring", "musicIntroLoop.Unpause()")
    Encounter.Call("loadstring", "enemies[1]['anim'].glitch = true")
    Encounter.Call("loadstring", "enemies[1].Call(\"loadstring\", \"anim.gcamoffset = {x = 0, y = 0}\")")
    Encounter.Call("loadstring", "enemies[1].Call(\"loadstring\", \"anim.gstatic.y = 240\")")
    Encounter.Call("SetButtonLayer", "Topper")
end
