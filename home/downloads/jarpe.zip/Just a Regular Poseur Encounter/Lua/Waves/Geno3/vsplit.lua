require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



Player.SetControlOverride(true)
Arena.Hide()

Arena.ResizeImmediate(Arena.width, Arena.height)


timer = 0
-- effective position of the player
pos = {x = -16, y = 0}

-- this wave script will work differently on 0.6.4 and higher
versionoffset = CYFversion == "0.6.3" and 0 or 8
versionoffset2 = CYFversion == "0.6.3" and 6.5 or 2.5
-- 9 - versionoffset2


bullet = CreateSprite("boolet", "Topper")
bullet.MoveToAbs(Arena.x + math.random(-40, 40), Arena.y + Arena.height/2 + 190)
bullet.alpha = 0

dir = bullet.x <= 0 and 1 or -1
vely = 3

function Update()
    timer = timer + 1
    
    -- intro sequence
    if timer == 10 then
        cover = CreateSprite("UI/sq_white", "Toppest")
        cover.Scale(700/4, 500/4)
        cover.MoveTo(320, 240)
        
        Misc.ShakeScreen(6, 6, false)
        Audio.PlaySound("thunk")
        
        -- hide player
        Player.sprite.alpha = 0
        
        -- create arena
        do
            -- LEFT --
            
            ArenaL = CreateSprite("px", "Topper")
            ArenaL.Scale(Arena.width/2, Arena.height)
            ArenaL.MoveToAbs(Arena.x, Arena.y + Arena.height/2)
            ArenaL.xpivot = 1
            ArenaL.color = {0, 0, 0}
            
            ArenaLTop = CreateSprite("px", "Topper")
            ArenaLTop.SetParent(ArenaL)
            ArenaLTop.SetPivot(1, 0)
            ArenaLTop.Scale(Arena.width/2, 5)
            ArenaLTop.SetAnchor(1, 1)
            ArenaLTop.MoveTo(0, 0)
            
            ArenaLBottom = CreateSprite("px", "Topper")
            ArenaLBottom.SetParent(ArenaL)
            ArenaLBottom.SetPivot(1, 1)
            ArenaLBottom.Scale(Arena.width/2, 5)
            ArenaLBottom.SetAnchor(1, 0)
            ArenaLBottom.MoveTo(0, 0)
            
            ArenaLLeft = CreateSprite("px", "Topper")
            ArenaLLeft.SetParent(ArenaL)            
            ArenaLLeft.xpivot = 1
            ArenaLLeft.Scale(5, Arena.height + 10)
            ArenaLLeft.SetAnchor(0, 0.5)
            ArenaLLeft.MoveTo(0, 0)
            
            ArenaLRight = CreateSprite("px", "Topper")
            ArenaLRight.SetParent(ArenaL)
            if CYFversion == "0.6.3" then
                ArenaLRight.xpivot = 0
                ArenaLRight.Scale(16, Arena.height + 10)
                ArenaLRight.SetAnchor(1, 0.5)
                ArenaLRight.MoveTo(-8, 0)
                ArenaLRight.color = {0, 0, 0, 0}
            else
                -- use this sprite as a Mask instead
                ArenaLRight.Scale(Arena.width/2, Arena.height + 10)
                ArenaLRight.xscale = ArenaLRight.xscale - 8
                ArenaLRight.MoveTo(0, 0)
                ArenaLRight.Mask("stencil")
                
                -- shrink left arena by 8px
                ArenaL.xscale = ArenaL.xscale - 8
                ArenaLBottom.xscale = ArenaLBottom.xscale - 4
                ArenaLTop.xscale = ArenaLTop.xscale - 4
            end
            
            -- RIGHT --
            
            ArenaR = CreateSprite("px", "Topper")
            ArenaR.Scale(Arena.width/2, Arena.height)
            ArenaR.MoveToAbs(Arena.x, Arena.y + Arena.height/2)
            ArenaR.xpivot = 0
            ArenaR.color = {0, 0, 0}
            
            ArenaRTop = CreateSprite("px", "Topper")
            ArenaRTop.SetParent(ArenaR)
            ArenaRTop.SetPivot(0, 0)
            ArenaRTop.Scale(Arena.width/2, 5)
            ArenaRTop.SetAnchor(0, 1)
            ArenaRTop.MoveTo(0, 0)
            
            ArenaRBottom = CreateSprite("px", "Topper")
            ArenaRBottom.SetParent(ArenaR)
            ArenaRBottom.SetPivot(0, 1)
            ArenaRBottom.Scale(Arena.width/2, 5)
            ArenaRBottom.SetAnchor(0, 0)
            ArenaRBottom.MoveTo(0, 0)
            
            ArenaRLeft = CreateSprite("px", "Topper")
            ArenaRLeft.SetParent(ArenaR)            
            if CYFversion == "0.6.3" then
                ArenaRLeft.xpivot = 0.5
                ArenaRLeft.Scale(16, Arena.height + 10)
                ArenaRLeft.SetAnchor(0, 0.5)
                ArenaRLeft.MoveTo(0, 0)
                ArenaRLeft.color = {0, 0, 0, 0}
            else
                -- use this sprite as a Mask instead
                ArenaRLeft.Scale(Arena.width/2, Arena.height + 10)
                ArenaRLeft.xscale = ArenaRLeft.xscale - 8
                ArenaRLeft.MoveTo(0, 0)
                ArenaRLeft.Mask("stencil")
                
                -- shrink left arena by 8px
                ArenaR.xscale = ArenaR.xscale - 8
                ArenaRBottom.xscale = ArenaRBottom.xscale - 4
                ArenaRTop.xscale = ArenaRTop.xscale - 4
            end
            
            ArenaRRight = CreateSprite("px", "Topper")
            ArenaRRight.SetParent(ArenaR)
            ArenaRRight.xpivot = 0
            ArenaRRight.Scale(5, Arena.height + 10)
            ArenaRRight.SetAnchor(1, 0.5)
            ArenaRRight.MoveTo(0, 0)
        end
        
        -- create fake players
        PlayerL = CreateSprite("ut-heart", "Topper")
        if CYFversion == "0.6.3" then
            PlayerL.SetParent(ArenaL)
            PlayerL.MoveBelow(ArenaLRight)
        else
            PlayerL.SetParent(ArenaLRight)
        end
        PlayerL.SetAnchor(1, 0.5)
        PlayerL.MoveTo(-16, 0)
        PlayerL.color = {1, 0, 0}
        
        PlayerR = CreateSprite("ut-heart", "Topper")
        if CYFversion == "0.6.3" then
            PlayerR.SetParent(ArenaR)
            PlayerR.MoveBelow(ArenaRLeft)
        else
            PlayerR.SetParent(ArenaRLeft)
        end
        PlayerR.SetAnchor(0, 0.5)
        PlayerR.MoveTo(-versionoffset, 0)
        PlayerR.color = {1, 0, 0, 0}
    elseif timer == 11 then
        cover.Remove()
        cover = nil
    
    -- slide away pieces
    elseif timer >= 20 then
        -- alpha stuff
        if timer == 20 then
            ArenaLRight.alpha = 1
            ArenaRLeft.alpha = 1
            PlayerR.alpha = 1
            
            Audio.PlaySound("Waves/shatter", 0.25)
        end
        
        ArenaL.x = lerp(ArenaL.x, 320 + (ArenaL.xscale/2) + versionoffset2, 0.1)
        ArenaL.y = lerp(ArenaL.y, 300, 0.1)
        ArenaR.x = lerp(ArenaR.x, 320 - (ArenaR.xscale/2) - versionoffset2, 0.1)
    end
    
    
    
    --==========--
    -- CONTROLS --
    --==========--
    
    if timer >= 60 then
        local velx = 0
        local vely = 0
        
        if     Input.   Up > 0 and Input. Down < 1 then
            vely =  2
        elseif Input. Down > 0 and Input.   Up < 1 then
            vely = -2
        end
        
        if     Input. Left > 0 and Input.Right < 1 then
            velx = -2
        elseif Input.Right > 0 and Input. Left < 1 then
            velx =  2
        end
        
        
        
        if Input.Cancel > 0 then
            velx = velx / 2
        end
        
        -- limit left and right
        if     pos.x + velx < (-Arena.width/2) + (8 + versionoffset) then
            velx = pos.x + (Arena.width/2) - (8 + versionoffset)
        elseif pos.x + velx > ( Arena.width/2) - (24 - versionoffset) then --workaround for right side soul offset
            velx = (Arena.width/2) - (24 - versionoffset) - pos.x
        end
        
        -- limit up and down
        if     pos.y + vely > ( Arena.height/2) - 8 then
            vely = (Arena.height/2) - 8 - pos.y
        elseif pos.y + vely < (-Arena.height/2) + 8 then
            vely = pos.y + (Arena.height/2) - 8
        end
        
        pos = { x = pos.x + velx, y = pos.y + vely }
        
        
        
        -- update sprites
        if CYFversion == "0.6.3" then
            PlayerL.x = pos.x <   0 and pos.x      or 0
            PlayerR.x = pos.x > -16 and pos.x + 16 or 0
            
            PlayerL.y = pos.y
            PlayerR.y = pos.y
        else
            PlayerL.MoveTo(pos.x, pos.y)
            PlayerR.MoveTo(pos.x, pos.y)
        end
        
        -- decorative hurting colors
        if Player.isHurting then
            PlayerL.alpha = 0.5
            PlayerR.alpha = 0.5
        else
            PlayerL.alpha =   1
            PlayerR.alpha =   1
        end
    end
    
    
    
    -- spawn and handle bullets
    if timer >= 60 then
        local timer = timer - 60
        
        if not firstThing then
            -- initial set alpha
            if timer == 0 and bullet.alpha == 0 then
                bullet.alpha = 1
                Audio.PlaySound("Waves/jump")
            end
            
            -- initial jump
            if timer > 0 and timer < 31 then
                vely = vely - (3/30)
                
                bullet.Move(dir, vely)
            
            -- initial fall
            elseif timer == 31 then
                vely = 0
                bullet.MoveAbove(ArenaR)
                
                firstThing = true
            end
        -- regular wave stuff
        else
            local timer = _G["timer"] - (60 + 31)
            
            if timer > 0 then
                vely = vely - (5/30)
                
                bullet.Move(dir, vely)
                
                -- hit detection with walls
                if     bullet.x - bullet.width/2 < Arena.x + -Arena.width/4 then
                    dir = -dir
                    bullet.x = Arena.x + -Arena.width/4 + bullet.width/2
                elseif bullet.x + bullet.width/2 > Arena.x +  Arena.width/4 then
                    dir = -dir
                    bullet.x = Arena.x +  Arena.width/4 - bullet.width/2
                end
                
                -- hit detection with floor
                if bullet.y - bullet.height/2 < Arena.y then
                    vely = 0
                    bullet.MoveTo(bullet.x, Arena.y + bullet.height/2)
                    
                    Audio.PlaySound("Waves/drop")
                    Misc.ShakeScreen(15, 3, true)
                    _G["timer"] = 60
                end
            elseif timer == 0 then
                Audio.PlaySound("Waves/jump")
                vely = 8.5 + math.random()
                
                _G["timer"] = 60 + 32
            end
            
            
            
            -- collision detection
            if not Player.isHurting then
                local player = pos.x < (-8 + versionoffset) and PlayerL or PlayerR
                if math.sqrt((player.absx - bullet.absx)^2 + (player.absy - bullet.absy)^2) < 16 then
                    -- check sides
                    if     bullet.absx +  bullet.width/2 > player.absx - ( player.width/4)
                       and bullet.absx -  bullet.width/2 < player.absx + ( player.width/4)
                       and bullet.absy + bullet.height/2 > player.absy - (player.height/4)
                       and bullet.absy - bullet.height/2 < player.absy + (player.height/4) then
                        OnHit(bullet, true)
                    end
                end
            end
            
            
            
            -- do a glitch effect
            if math.random() < 0.01 and not glitch then
                glitch = CreateSprite("glitch/sheet_" .. math.random(1, 16), "Topper")
                glitch.SetParent(bullet)
                bullet.alpha = 0
                
                glitch.Scale(2, 2)
                glitch.MoveTo(0, 0)
                glitch.SetAnimation({glitch.spritename, "glitch/sheet_" .. math.random(1, 16)}, 1/8)
                glitch.loopmode = "ONESHOT"
                glitch.xpivot = math.random()
                glitch.rotation = math.random(0, 3) * 90
            elseif glitch and glitch.animcomplete then
                bullet.alpha = 1
                glitch.Remove()
                glitch = nil
            end
        end
    end
end

function OnHit(bullet, custom)
    -- only account for manual collision detection from wave
    if custom then
        Player.Hurt(3, 1)
    end
end

function lerp(a, b, t)
    return a + ((b - a) * t)
end

function EndingWave()
    -- show arena
    Arena.Show()
    
    -- remove fake arena
    ArenaL.Remove()
    ArenaLTop.Remove()
    ArenaLBottom.Remove()
    ArenaLLeft.Remove()
    ArenaLRight.Remove()
    
    ArenaR.Remove()
    ArenaRTop.Remove()
    ArenaRBottom.Remove()
    ArenaRLeft.Remove()
    ArenaRRight.Remove()
    
    -- remove fake players
    PlayerL.Remove()
    PlayerR.Remove()
    
    -- show player
    Player.sprite.alpha = 1
    
    
    
    -- remove glitch sprite if applicable
    if glitch then
        glitch.Remove()
    end
    
    if bullet then
        bullet.Remove()
    end
end
