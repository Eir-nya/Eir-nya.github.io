require "Libraries/fakearena_WAVE_BEGIN"    -- always required
--══════════════════════════════════════════════════════════--



-- SPECIAL ATTACK: MEGA DESTRUCTION DATA BEAM OF DELETION AND DESTRUCTION...AND KNUCKLES
-- https://www.youtube.com/watch?v=H1PTN0Zdy7E&t=1m40s

Player.speed = 4

count = math.floor(Arena.width/40)
warnings = {}
beams = {}
order = {}
numbers = {}
nexthole = math.ceil(count / 2)

Player.MoveTo(0, 0)

timer = 0

function Update()
    timer = timer + 1
    
    local timer = timer % 110
    
    -- choose next safe place
    if timer == 0 then
        nexthole = nexthole + (math.random() < 0.5 and -1 or 1)
        nexthole = nexthole <     1 and         2 or nexthole
        nexthole = nexthole > count and count - 1 or nexthole
    
    -- start to spawn beams
    elseif timer >= 42 and timer % 6 == 0 and timer - 42 < (count * 6) then
        local id = (timer - 36) / 6
        
        -- spawn warning or whatever
        if id ~= nexthole then
            local warning = CreateSprite("Waves/Geno3/exclamation", "Topper")
            warning.x = Arena.x - (math.ceil(count/2) * 40) + (id * 40)
            warning.y = Arena.y + Arena.height/2
            warning["timer"] = 0
            warnings[warning] = true
            Audio.PlaySound("Waves/home")
        end
    
    -- special one comes last
    elseif timer == 109 then
        local warning = CreateSprite("Waves/Geno3/exclamation", "Topper")
        warning.x = Arena.x - (math.ceil(count/2) * 40) + (nexthole * 40)
        warning.y = Arena.y + Arena.height/2
        warning["timer"] = 0
        warnings[warning] = true
        Audio.PlaySound("Waves/home")
    end
    
    
    
    -- update beams
    for beam in next, beams, beam do
        beam["timer"] = beam["timer"] + 1
        
        beam.sprite.alpha = beam.sprite.alpha - (1/30)
        
        if beam["timer"]%4 == 0 then
            beam.sprite.Set("Waves/Geno3/beam" .. math.random(1, 3))
        end
        
        -- remove condition
        if beam.sprite.alpha <= 0 then
            beam.Remove()
            beams[beam] = nil
        end
    end
    
    -- update numbers
    for num in next, numbers, num do
        num["timer"] = num["timer"] - 1
        num.alpha = num["timer"] / 20
        num.x = num.x + (num["dir"] * (num["timer"] / 6))
        
        -- remove condition
        if num["timer"] == 0 then
            num.Remove()
            numbers[num] = nil
        end
    end
    
    -- update warnings then spawn beams
    for warning in next, warnings, warning do
        warning["timer"] = warning["timer"] + 1
        
        if warning["timer"] > 10 and warning.alpha > 0 then
            warning.alpha = warning.alpha - (1/20)
        elseif warning["timer"] == 50 then
            -- create beam
            Audio.PlaySound("Waves/Static/s" .. math.random(1, 3), 1)
            Misc.ShakeScreen(20, 3, false)
            
            local beam = CreateProjectileAbs("Waves/Geno3/beam" .. math.random(1, 3), warning.absx, 240)
            beam.sprite.yscale = 480/beam.sprite.height
            beam.sprite.color32 = {34 + math.random(0, 1) * 111, 179 + math.random(0, 1) * 77, 221 + math.random(0, 1) * 35}
            beam["timer"] = 0
            beams[beam] = true
            
            -- create number particles
            if not safe then
                local count = math.random(5, 10)
                for i = 1, count do
                    local num = CreateSprite("Waves/Geno3/" .. math.random(0, 1), "Topper")
                    num.color = {1, 0, 0}
                    num.MoveToAbs(beam.absx, (i / (count + 1)) * 480)
                    num.Scale(2, 2)
                    num["dir"] = math.random() * (math.random() < 0.5 and -1 or 1)
                    num["timer"] = 20
                    numbers[num] = true
                end
            end
            
            warning.Remove()
            warnings[warning] = nil
        end
    end
end

function OnHit(bullet)
    if bullet.sprite.alpha > 0.5 then
        Player.Hurt(4, 1)
    end
end

function EndingWave()
	for warning in next, warnings, warning do
        if warning.isactive then
            warning.Remove()
        end
    end
    
    for num in next, numbers, num do
        if num.isactive then
            num.Remove()
        end
    end

	Misc.StopShake()
	Misc.ResetCamera()
end
