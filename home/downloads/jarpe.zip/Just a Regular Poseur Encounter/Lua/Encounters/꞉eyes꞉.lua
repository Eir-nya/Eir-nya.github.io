encountertext = "Poseur strikes a pose!"
music = CYFversion == "0.6.3" and "mus_battle1 old" or "mus_battle1"
wavetimer = 6.0
arenasize = {155, 130}
nextwaves = {}

enemies = {"poseur"}
enemypositions = {{0, 0}}



function EncounterStarting()
    -- error handler
    local bul = CreateSprite("bullet", "Top")
    bul.Remove()
    if not isCYF or CYFversion < "0.6.3" then
        error("\n\n<size='22'>This mod requires <b><color='#ffff00'>Create Your Frisk v0.6.3</color></b> or higher to play.</size>"
           .. "\n<color='#111'>poseur awaits your challenge</color>"
           .. "\n<color='#000'><quad material=1 size=460 x=0.54 y=0.01 width=1.0 height=0.5></color>")
    elseif bul.isactive then
        error((CYFversion == "0.6.3" and "\n\n" or "\n") .. "<size='22'>Please <b><color='#ffff00'>disable retrocompatibility mode</color></b> to play this mod.</size>", 0)
    elseif GetAlMightyGlobal("CrateYourFrisk") then
        SetAlMightyGlobal("CrateYourFrisk", false)
        Audio.Stop()
        if CYFversion == "0.6.3" then
            State("DONE")
        else
            Misc.cameraY = -480
            Misc.DestroyWindow()
        end
        return
    end
    
    if EnableDebugger then
        EnableDebugger(false)
    end
    
    --====================--
    
    require "Libraries/loadstring"
    
    -- create layers
    CreateLayer("Topper",  "VeryHighest")
    CreateLayer("Toppest", "VeryHighest")
    
    -- cover bg
    bg = CreateSprite("bg", "Topper")
    bg.color32 = {3, 114, 18}
    SetButtonLayer("Topper")
    
    fakearena = require "Libraries/fakearena"
    
    Player.name = "Frisk"
    Player.sprite.layer = "Topper"
    Player.sprite.MoveAbove(fakearena.arena)
    Player.sprite.MoveToAbs(320, 160)
    
    
    
    -- mute music, state none, cover regular battle --
    
    -- preload music...
    if not safe and not GetAlMightyGlobal("wd geno bool") then
        if not GetAlMightyGlobal("super excellent intro owo") then
            NewAudio.PlayMusic("src", "AUDIO_ANOTHERHIM", true)
        end
        NewAudio.PlayMusic("src",                 "mus_battle1",   true)
        if CYFversion == "0.6.3" then
            NewAudio.PlayMusic("src",         "mus_battle1 old",   true)
        else
            NewAudio.PlayMusic("src",        "mus_battle1 fj7x",   true)
        end
        NewAudio.PlayMusic("src",                       "joker",   true)
        NewAudio.PlayMusic("src",        "Dino Piranha (Intro)",  false)
        NewAudio.PlayMusic("src",         "Dino Piranha (Loop)",   true)
        NewAudio.PlayMusic("src",       "King Caliente (Intro)",  false)
        NewAudio.PlayMusic("src",        "King Caliente (Loop)",   true)
        NewAudio.PlayMusic("src", "Smithy First Battle (Intro)",  false)
        NewAudio.PlayMusic("src",  "Smithy First Battle (Loop)",   true)
        NewAudio.PlayMusic("src",              "Father and Son",   true)
        NewAudio.PlayMusic("src",    "Working Together (Intro)",  false)
        NewAudio.PlayMusic("src",     "Working Together (Loop)",   true)
        NewAudio.PlayMusic("src",              "Sinister Dance",   true)
    end
    
    Audio.Stop()
    
    State("NONE")
    black = CreateSprite("black", "Topper")
    black.ypivot = 0
    black.y = 0
    black.yscale = 1620 / 480
    
    
    
    -- player has completed a genocide route
    if GetAlMightyGlobal("wd geno bool") then
        require "Libraries/ending_geno"
        return
    end
    
    
    
    debuggetinfo = debug.getinfo(1, "S").source:sub(2)
    local intro = require "Libraries/intro"
    intro(debuggetinfo)
    updateDebugger = require "Libraries/debugger"
    route = require "Libraries/route"
    musicIntroLoop = require "Libraries/musicIntroLoop"
    
    
    
    -- for real
    function EncounterStarting(natural)
        route.neutral()
        
        Player.sprite.layer = "Toppest"
        Player.sprite.SetAnchor(0.5, 0.5)
        Player.sprite.SendToBottom()
        
        text = nil
        
        Audio.Stop()
        
        autolinebreak = true
        flee = false
        
        
        local prefix = "[effect:none]"
        -- if intro finished naturally
        if natural then
            black.SendToBottom()
            
            enemies[1].Call("SetSprite", "poseur_read1")
            enemies[1]["currentdialogue"] = {
                prefix .. "Wait,[w:10] what?",
                          "[noskip][func:Bubble,false][w:10][func:SetSprite,poseur_read2][w:30][func:SetSprite,poseur_read1][func:Bubble,true][w:10][next]",
                prefix .. "Who wrote this\nscript?!",
                          "[noskip][func:Bubble,false][w:20][func:Bubble,true][func:SetSprite,poseur_read2][next]",
                prefix .. "[noskip]Eh,[w:10] whatever.[w:10][sound:paper][func:SetSprite,poseur_stand][w:20][func:Paper][w:40][next]",
                prefix .. "So anyway...",
                prefix .. Player.name .. ",[w:5] right?",
                prefix .. "You're the human\nthat's been going\naround here lately.",
                          "[noskip][func:Bubble,false][w:10][func:Bubble,true][next]",
                prefix .. "I know you are\ngoing up against\n[color:ff0000]ASGORE[color:000000] soon...",
                prefix .. "I am[w:10] conflicted,[w:5]\nto be honest.",
                          "[noskip][func:Bubble,false][w:15][func:Bubble,true][next]",
                prefix .. "But [w:10]I've come here[w:10]\nto help you.",
                          "[noskip][func:Bubble,false][w:5][sound:thunk][func:SetSprite,poseur][w:15][func:Bubble,true][next]",
                prefix .. "I'll train you to\ndefend yourself,[w:5]\n" .. Player.name .. "!",
                prefix .. "I have three years\nof experience in\nmagic combat!",
                prefix .. "I can't just let you\ngo there and die...",
                prefix .. "You won't last a\nsecond without help.",
                          "[noskip][func:Bubble,false][w:20][func:Bubble,true][next]",
                prefix .. "[waitall:2]Sooo...[waitall:1][w:15]\nLet's do this!",
                prefix .. "Your training begins\nnow!",
                prefix .. "Ready when you are!",
                          "[noskip][w:5][sound:heartsplosion][w:15][next]"
            }
            text = nil
        -- player has seen the intro before
        else
            enemies[1]["currentdialogue"] = {
                prefix .. "Let's go!",
                          "[noskip][func:Bubble,false][w:5][sound:thunk][func:SetSprite,poseur][w:20][func:Bubble,true][next]",
            }
        end
        
        table.insert(enemies[1]["currentdialogue"], "[noskip][func:loadstring,Audio.LoadFile(Encounter[\"music\"]) ; Audio.Volume(0.75) ; anim.animate = true][func:State,ACTIONSELECT][next]")
        
        State("ENEMYDIALOGUE")
        
        
        
        -- set up items
        Inventory.AddCustomItems({"Bisicle", "Unisicle", "Cinnamon Bunny", "Nice Cream", "Starfait", "Music Box"}, {0, 0, 0, 0, 0, 3})
        Inventory.SetInventory({"Bisicle", "Cinnamon Bunny", "Nice Cream", "Starfait", "Music Box"})
        
        inventory = {
            Bisicle             = { name =   "Bisicle", desc = "Heal [color:ff8040]11[color:ffffff] HP x2" },
            Unisicle            = { name =  "Unisicle", desc = "Heal [color:ff8040]11[color:ffffff] HP" },
            ["Cinnamon Bunny"]  = { name =  "CinnaBun", desc = "Heal [color:ff8040]20[color:ffffff] HP" },
            ["Nice Cream"]      = { name = "NiceCream", desc = "Heal [color:ff8040]15[color:ffffff] HP" },
            Starfait            = { name =  "Starfait", desc = "Heal [color:ff8040]14[color:ffffff] HP" },
            ["Music Box"]       = { name = "Music Box", desc = "Alternate music" },
        }
        
        local losscounter = 60 + math.random(0, 200)
        
        -- for real
        function Update()
            -- update Intro/Loop music
            musicIntroLoop.Update()
            
            -- update debugger
            updateDebugger()
            if debuggerSpr1 then
                debuggerSpr1.MoveToAbs(Misc.cameraX + 460, Misc.cameraY + 410)
            end
            
            -- update enemy
            enemies[1].Call("Update")
            
            -- update fake arena
            fakearena.Update()
            
            
            
            -- best easter egg
            if GetCurrentState() == "DEFENDING" and losscounter > 0 and route.route == 0 and bg.spritename == "bg" then
                losscounter = losscounter - 1
                
                if losscounter == 0 then
                    bg.Set("bg2")
                    losscounter = 360 + (math.random(0, 200) * 3)
                end
            elseif bg.spritename == "bg2" then
                bg.Set("bg")
            end
        end
        
        Player.sprite.MoveToAbs(320, 160)
    end
end



function EnteringState(newstate, oldstate)
    -- manually call this function
    if newstate == "ACTIONSELECT" and oldstate == "DEFENDING" then
        DefenseEnding(true)
    
    -- forcefully enter "DEFENDING" from "ENEMYDIALOGUE" through `State` rather than naturally
    elseif newstate == "ENEMYDIALOGUE" then
        -- collect next dialogue
        if not enemies[1]["currentdialogue"] then
            enemies[1]["currentdialogue"] = { enemies[1]["randomdialogue"][math.random(#enemies[1]["randomdialogue"])] }
        end
        
        -- add enemy's `prefix` variable as a prefix to every line
        for i = 1, #enemies[1]["currentdialogue"] do
            enemies[1]["currentdialogue"][i] = (enemies[1]["prefix"] and enemies[1]["prefix"] or "") .. enemies[1]["currentdialogue"][i]
        end
        
        -- add new string to the end
        if not enemies[1]["currentdialogue"][#enemies[1]["currentdialogue"]]:find("func:State,DEFENDING") then
            table.insert(enemies[1]["currentdialogue"], "[noskip][func:loadstring,Encounter.Call(\"EnemyDialogueEnding\")][func:State,DEFENDING]")
        end
    end
    
    fakearena.EnterState(newstate, oldstate)
end



-- I want arena size to be chosen in THIS function
-- which is why I'm using it for waves
function EnemyDialogueStarting()
    arenasize = {155, 130}
    
    if route.route == 2 then
        enemies[1]["wavecount"] = enemies[1]["wavecount"] + 1
    end
    
    if route.route == 1 and route.genostep > 0 and route.genostep < 4 and enemies[1]["attackcount"] > #wavetable.geno[route.genostep] then
        pcall(function() enemies[1].Call("GenocideRouteEndOfSegmentDialogue") end)
    else
        pcall(EnemyDialogueEnding)
    end
end


-- ROUTE-BASED WAVES
-- can't be called `waves` due to a CYF bug
wavetable = {
    -- NEUTRAL WAVES
    -- see EnemyDialogueEnding
    
    -- GENOCIDE WAVES
    geno = {
        {           -- Genocide part 1:  Space
            { [1] = "Geno1/ricochet", arenasize = { 400, 135 }, wavetimer = 10 },
            { [1] = "Geno1/portals", arenasize = { 300, 200 }, wavetimer = 19.125 },
            { [1] = "Geno1/ricochet", [2] = "Geno1/portals2", [3] = "Geno1/upsidedown", arenasize = { 400, 200 }, wavetimer = 18 },
            { [1] = "Geno1/arrows_bottom&top", [2] = "Geno1/rotatechase", arenasize = { 200, 200 }, wavetimer = 17 },
        },
        {
                    -- Genocide part 2:  Jevil
            { [1] = "Geno2/horseracing" .. (CYFversion == "0.6.3" and "_0.6.3" or ""), arenasize = { 300, 200 }, wavetimer = 10 },
            { [1] = "Geno2/screen", arenasize = { 300, 175 }, wavetimer = 10 },
            { [1] = "Geno2/gravitron", arenasize = { 300, 200 }, wavetimer = 13.5 },
            { [1] = "Geno2/devilsknife", arenasize = { 170, 175 }, wavetimer = 10.2 },
        },
        {
                    -- Genocide part 3: Glitch
            { [1] = "Geno3/hsplit", arenasize = { 250, 130 }, wavetimer = 11 },
            { [1] = "Geno3/SAMDDBODADAK", arenasize = { 280, 32 }, wavetimer = 10 },
            { [1] = "Geno3/fakeout", arenasize = { 155, 130 }, wavetimer = 6 },
            { [1] = "Geno3/vsplit", arenasize = { 250, 130 }, wavetimer = 11 },
            { [1] = "Geno3/bullettest_void", arenasize = { 155, 130 }, wavetimer = 14 },
        }
    },
    
    -- PACIFIST WAVES
    pacifist = {
        { "Pacifist/hand1", arenasize = { 250, 130 }, wavetimer = 6.75 },
        { "Pacifist/flamecircle", arenasize = { 300, 200 }, wavetimer = 8 },
        { "Pacifist/hand2", arenasize = { 300, 130 }, wavetimer = 6.25 },
        { "Pacifist/firesinerotate", arenasize = { 155, 155 }, wavetimer = 10 },
        { "Pacifist/impact", arenasize = { 155, 130 }, wavetimer = 9 },
        { "Pacifist/dogmobile", arenasize = { 300, 130 }, wavetimer = 12 },
        { "Pacifist/chainlightning", arenasize = { 200, 155 }, wavetimer = 8 },
        { "Pacifist/shieldintro", arenasize = { 75, 70 }, wavetimer = math.huge },
        { "Pacifist/firepillars", arenasize = { 300, 130 }, wavetimer = 13 },
        { "Pacifist/zawarudo", arenasize = { 155, 130 }, wavetimer = 8 },
        { "Pacifist/dogmobile2", arenasize = { 250, 130 }, wavetimer = 16 },
        { "Pacifist/rising", arenasize = { 250, 350 }, wavetimer = math.huge },
        { "Pacifist/tetris", arenasize = { 10 * 16, 14 * 16 }, wavetimer = math.huge },
    }
}


function EnemyDialogueEnding()
    -- neutral
    
    if route.route == 0 then
        if math.random(1, 10) == 1 then
            nextwaves = { "Neutral/dog" }
        else
            nextwaves = { ({ "Neutral/swipes", "Neutral/bouncy", "Neutral/ring" })[math.random(3)] }
            
            if enemies[1]["posecount"] > 0 then
                table.insert(nextwaves, "Neutral/menacing")
            end
        end
        
        wavetimer = 6.0
    
    -- genocide
    
    elseif route.route == 1 and route.genostep > 0 then
        if enemies[1]["attackcount"] < 1 then
            enemies[1]["attackcount"] = 1
        end
        
        nextwaves = wavetable.geno[route.genostep][enemies[1]["attackcount"]] and wavetable.geno[route.genostep][enemies[1]["attackcount"]] or wavetable.geno[route.genostep][1]
        arenasize = nextwaves.arenasize
        wavetimer = nextwaves.wavetimer
    
    -- pacifist
    
    elseif route.route == 2 then
        if wavetable.pacifist[enemies[1]["wavecount"]] and enemies[1]["hp"] > 0 then
            nextwaves = wavetable.pacifist[enemies[1]["wavecount"]]
            arenasize = nextwaves.arenasize
            wavetimer = nextwaves.wavetimer
        else
            nextwaves = {}
            arenasize = {155, 130}
            wavetimer = 0.25
        end
    end
    
    realwavetimer = wavetimer
    wavetimer     = (#nextwaves > 0 and math.huge or wavetimer)
end



function DefenseEnding(forced)
    if forced then
        -- regular code
        if route.route ~= 2 or (route.route == 2 and enemies[1]["wavecount"] >= #wavetable.pacifist) then
            -- be careful :eyes:
            if #enemies[1]["comments"] > 1 then
                local old = encountertext
                repeat
                    local chosen = math.random(#enemies[1]["comments"])
                    
                    if type(enemies[1]["comments"][chosen]) == "table" then
                        encountertext = {}
                        for i = 1, #enemies[1]["comments"][chosen] do
                            encountertext[i] = enemies[1]["comments"][chosen][i]
                        end
                    else
                        encountertext = enemies[1]["comments"][chosen]
                    end
                until (type(encountertext) == "table" and encountertext[1] or encountertext) ~= (type(old) == "table" and old[1] or old)
            elseif #enemies[1]["comments"] == 1 then
                encountertext = enemies[1]["comments"][1]
            end
        -- special condition for incrementing comment text
        else
            encountertext = enemies[1]["comments"][enemies[1]["wavecount"]]
        end
    end
end



function HandleSpare()
    State("ENEMYDIALOGUE")
end



function HandleItem(ItemID, index)
    -- Bisicle
    if ItemID == "BISICLE" then
        Player.Heal(11)
        Inventory.AddItem("Unisicle", index + 1)
        BattleDialog({"You ate one half of\rthe Bisicle.[w:10]\n" .. (Player.hp < Player.maxhp and "You recovered 11 HP!" or "Your HP was maxed out!")})
    -- Unisicle
    elseif ItemID == "UNISICLE" then
        Player.Heal(11)
        BattleDialog({"You ate the Unisicle.[w:10]\n" .. (Player.hp < Player.maxhp and "You recovered 11 HP!" or "Your HP was maxed out!")})
    -- Cinnamon Bunny
    elseif ItemID == "CINNAMON BUNNY" then
        Player.Heal(22)
        BattleDialog({"You ate the Cinnabon Bun.[w:10]\n" .. (Player.hp < Player.maxhp and "You recovered 22 HP!" or "Your HP was maxed out!")})
    -- Nice Cream
    elseif ItemID == "NICE CREAM" then
        Player.Heal(15)
        BattleDialog({({
                        "You're super spiffy!",
                        "Are those claws natural?",
                        "Love yourself! I love you!",
                        "You look nice today!",
                        "(An illustration of a hug)",
                        "Have a wonderful day!",
                        "Is this as sweet as you?",
                        "You're just great!",
                    })[math.random(8)]
                .. "[w:10]\n" .. (Player.hp < Player.maxhp and "You recovered 15 HP!" or "Your HP was maxed out!")})
    -- Starfait
    elseif ItemID == "STARFAIT" then
        Player.Heal(14)
        BattleDialog({"You ate the Starfait.[w:10]\n" .. (Player.hp < Player.maxhp and "You recovered 14 HP!" or "Your HP was maxed out!")})
    -- Music Box
    elseif ItemID == "MUSIC BOX" then
        -- special case for jevil!
        if enemies[1]["anim"].jevil then
            Audio.Pause()
            BattleDialog({"You activate the music box...",
                          "[instant:stopall][noskip][func:loadstring,Audio.PlaySound(\"dududu_du_du\")][w:20]no[w:20][func:loadstring,Audio.Unpause()][func:State,ACTIONSELECT]"})
            return
        
        -- special case for end of pacifist section where there is silence
        elseif route.route == 2 and enemies[1]["wavecount"] >= #wavetable.pacifist then
            BattleDialog({"Not right now.", "[noskip][func:State,ACTIONSELECT]"})
            return
        end
        
        local songSwitcher = {
            ["mus_battle1 old"]             = { name = "mus_battle1",                               volume =  0.5 },
            ["mus_battle1 fj7x"]            = { name = "mus_battle1",                               volume = 0.75 },
            ["mus_battle1"]                 = { name = "mus_battle1 fj7x",                          volume =  0.5 },
            ["king caliente (loop)"]        = { name =  "Dino Piranha (Loop)",       loop =  2.818, volume = 0.75 },
            ["dino piranha (loop)"]         = { name = "King Caliente (Loop)",       loop =  8.591, volume = 0.55 },
            ["smithy first battle (loop)"]  = { name = "Father and Son",                            volume =    1 },
            ["father and son"]              = { name = "Smithy First Battle (Loop)", loop =  9.273, volume =  0.6 },
            ["working together (loop)"]     = { name = "Sinister Dance",                            volume =  0.6 },
            ["sinister dance"]              = { name = "Working Together (Loop)",    loop = 11.8,   volume =  0.6 },
        }
        
        if CYFversion == "0.6.3" then
            songSwitcher["mus_battle1"].name = "mus_battle1 old"
        end
        
        -- special case for shield mode
        if route.route == 2 and (Player.sprite["outline"] or (musicIntroLoop.GetPlaying() and musicIntroLoop.GetPlaying():lower():find("hand in hand"))) then
            songSwitcher["sinister dance"]      = { name = "Hand in Hand (Loop)",        loop = 12.581, volume = 0.75 }
            songSwitcher["hand in hand (loop)"] = { name = "Working Together (Loop)",    loop = 11.8,   volume =  0.6 }
        end
        
        
        
        local currentsong = musicIntroLoop.active and musicIntroLoop.GetPlaying() or (not NewAudio.isStopped("src") and NewAudio.GetAudioName("src"):sub(7))
        
        if songSwitcher[currentsong:lower()] then
            local newsong = songSwitcher[currentsong:lower()]
            
            local lstring = newsong.name:find("%(Loop%)") and ("musicIntroLoop.StartSong(\"" .. newsong.name:gsub("%(Loop%)", "(Intro)") .. "\", \"" .. newsong.name .. "\", " .. newsong.loop .. ", " .. (newsong.volume and newsong.volume or "0.75") .. ")")
                                                           or ("musicIntroLoop.StartSongRegular(\"" .. newsong.name .. "\", " .. (newsong.volume and newsong.volume or "0.75") .. ")")
            
            BattleDialog({"You activate the music box...",
                          "[noskip][func:loadstring," .. lstring .. "][noskip:off][w:10]A new song fills the area!",
                          "[noskip][func:State,ACTIONSELECT]"})
        end
        
        Audio.Stop()
        musicIntroLoop.Stop()
    end
end



-----------------------



-- pass along these functions that were supposed to be "inherited" in the first place
for func in pairs(({EncounterStarting = true, EnemyDialogueStarting = true, EnemyDialogueEnding = true, DefenseEnding = true, HandleItem = true, HandleSpare = true, EnteringState = true})) do
    local _func = _G[func]
    _G[func] = function(...)
        _func(...)
        if enemies[1][func] then
            enemies[1].Call(func, {...})
        end
    end
end
