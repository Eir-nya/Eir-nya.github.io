--[[
    
                     ████ ████ █                             
                   █████ █████ ███                           
                  ███ █████ ████ ██                          
                ████     █████████                           
             █████         █████████                         
       █████████         ███████████                         
   ████████      ███████████      ██                         
 █████       ██████████████       ██                         
███      ███████       ████       ██                         
█      █████ █                    ██                         
██     ███  ███                  ███                         
██      ████ ████████████████████  ████████                  
███       ███ ███████████      █████  █████████              
 ██        ████ █████████████████████        █████           
 ███         ██████████████         ███         ██           
  ███         ██████████████████████ ███████    ██           
   ████    ██      ███  ███                  █████           
     ███  ███                            ██████              
      ██████                          ██████                 
        █ █                         ████                     
        ██                         ███                       
        ██                        ███                        
        ██                       ███                         
        ██                       ██                          
        ███                      ███                         
         ███                      ███                        
          ██                       █████                     
          ██                          █████                  
          ███                            ████                
           ███               ████          ███               
            ███           ███████           ███              
             ████      █████                 ██              
               ████ █████                   ███              
                 ██████                    ███               
               █████                      █ █                
             █████                      ██  █                
           ████                     ███     █                
         ████                   ███          █               
        ███              ███████             █               
        ██          █████████  █             █               
       ███         ████         █             ██             
       ██          ██            █               ███         
       ██         ███             █                 ██       
      ███        ███               ██                 █      
      ██       ████                  ██                █     
      ██       ██                      ██               █    
     ███       ██                         ███            █   
     ██        ██                             ████        ███
     ██        ███                                 ██       █
     ██         ███                                  █      █
    ███          ██                                   █     █
   ███       ██████                                   █    █ 
 ████     █████                                      █     █ 
███      ███                                        █      █ 
███████████                                         ███████  
]]--

function EncounterStarting()
    require "Animations/poseur"
    callbacks = require "Libraries/callbacks"
    
    BindToArena(false, true)
    monstersprite.layer = "Topper"
    monstersprite.MoveAbove(Encounter["bg"])
end

-- complicated stuff owo
do
    lerp = function(a, b, t) ; return a + ((b - a) * t) ; end
    
    function BattleDialog(text)
        Encounter["temp"] = text
        Encounter.Call("loadstring", "BattleDialog(temp)")
        Encounter["temp"] = nil
    end

    function SetDamage(dmg)
        Encounter["fakearena"].damage = dmg
    end

    function OnDeath()
        Kill()
        monstersprite.yscale = 1
        anim.animate = false
        anim.jojo = false
        Encounter.Call("loadstring", "fakearena.EndBattle()")
    end

    function OnSpare()
        Spare()
        monstersprite.yscale = 1
        anim.animate = false
        anim.jojo = false
        Encounter.Call("loadstring", "fakearena.EndBattle()")
    end

    require "Libraries/loadstring"
end



-- A basic monster script skeleton you can copy and modify for your own creations.
comments = {"Smells like the work\rof an enemy stand.", "Poseur is posing like his\rlife depends on it.", "Poseur's limbs shouldn't be\rmoving in this way."}
commands = {"Check", "Dodge"}
if GetAlMightyGlobal("wd end 1") and GetAlMightyGlobal("wd end 2") and GetAlMightyGlobal("wd end 3") then
    table.insert(commands, "[color:000000]Interrogate")
end
randomdialogue = {"[noskip][next]"}

sprite = "poseur_stand" --Always PNG. Extension is added automatically.
name = "Poseur"

hp = 57 * 5 ;   maxhp =  hp
atk = 8     ; dispatk = atk
def = 0     ; dispdef =  10

check = "A...[w:10]combat trainer?"
dialogbubble = "rightwide2" -- See documentation for what bubbles you have available.
prefix = "[effect:none]"

canspare = false
xp = 70
gold = 80



dodgecount = 0
posecount  = 0



attackcount = 0

function HandleAttack(attackstatus)
    -- miss
    if attackstatus == -1 then
        
        -- neutral
        if Encounter["route"].route == 0 then
            currentdialogue = { ({"Come on,[w:5] now.", "What're you doing?", "..."})[math.random(1, 3)] }
        
        -- genocide
        elseif Encounter["route"].route == 1 then
            currentdialogue = { ({"You missed...", "..."})[math.random(1, 2)] }
        end
        
        -- pacifist: no dialogue for missing
    
    -- hit
    else
        attackcount = attackcount + 1
        
        -- neutral
        if Encounter["route"].route == 0 then
            local dialogue = {
                {"Yes,[w:5] come on!"},
                {"That's it,[w:5] now!"},
                {"Hit harder!"},
                {"...Ow..."},
                {"[noskip]Okay,[w:10] enough."}
            }
            
            if dialogue[ math.ceil( (maxhp - hp) / 30 ) ] then
                currentdialogue = dialogue[ math.ceil( (maxhp - hp) / 30 ) ]
            end
            
            -- if DEAD
            if hp <= 0 then
                Audio.Stop()
                SetSprite("poseur_hurt")
                anim.animate = false
                monstersprite.yscale = 1
                
                function OnDeath()
                    GenocideRouteDialogue()
                end
            end
        
        -- pacifist
        elseif Encounter["route"].route == 2 then
            if hp <= 0 then
                anim.ChangeAnim(0)
                anim.animate = false
                monstersprite.yscale = 1
                SetSprite("poseur_hurt")
                
                function OnDeath()
                    BetrayalDialogue()
                end
            end
        end
        
        -- genocide: no dialogue for hitting
    end
end
 


----------
function HandleCustomCommand(command)
    -- CHECK
    if command == "CHECK" then
        BattleDialog({name:upper() .. " " .. dispatk .. " ATK " .. dispdef .. " DEF[w:10]\n" .. check})
    
    -- DODGE
    elseif command == "DODGE" then
        
        if dodgecount == 0 then
            currentdialogue = {"Ooh![w:5] Nice one!"}
            BattleDialog({"You swoosh to the side,[w:5]\rnarrowly avoiding a swipe."})
        elseif dodgecount == 1 then
            currentdialogue = {"But can you dodge\nthis??"}
            BattleDialog({"You slide on your knees\runder a giant,[w:8] bouncing,[w:8]\rsmiley,[w:10] dog[w:10] bullet[w:10][waitall:2]...[waitall:1][w:5]thing."})
        elseif dodgecount == 2 then
            currentdialogue = {"You're doing well...[w:8]\nI'm impressed..."}
            BattleDialog({"You gracefully twirl in,[w:3]\rbetween,[w:3] and around a\rpattern of attacks.", "You're getting quite\rgood at this."})
            commands[2] = "Pose"
        end
        
        dodgecount = dodgecount + 1
    
    -- POSE
    elseif command == "POSE" then
        
        if posecount == 0 then
            currentdialogue = {"...?"}
            BattleDialog({"You posed dramatically\rmid-dodge."})
        elseif posecount == 1 then
            currentdialogue = {"A-[w:5]are you showing off?!"}
            BattleDialog({"You spun in a circle around\ra bullet,[w:5] and struck a\rmenacing pose."})
        else
            BattleDialog({"You posed so menacingly,[w:5]\rPoseur's bullets got scared.", "[instant:stopall][noskip][func:loadstring,"
                .. "anim.animate = false ; anim.jojo = false ; monstersprite.Set(\"poseur_stand\") ; monstersprite.yscale = 1]"
                .. "[func:FadeOutAudio,5][w:10]Poseur appears stunned."})
            PacifistRouteDialogue()
        end
        
        posecount = posecount + 1 <= 3 and posecount + 1 or posecount
        anim.posecount = posecount
    
    -- COUNT
    elseif command == "COUNT" then
        if wavecount < #Encounter["wavetable"].pacifist then
            BattleDialog({"Poseur has attacked you\r[color:ffff00]" .. wavecount .. "[color:ffffff] time" .. (wavecount ~= 1 and "s" or "") .. ".",
                          "It looks like he has the\renergy for [color:ffff00]" .. ((#Encounter["wavetable"].pacifist) - wavecount) .. "[color:ffffff] more attack" .. (((#Encounter["wavetable"].pacifist) - wavecount) ~= 1 and "s" or "") .. "."})
        else
            BattleDialog({"Poseur has attacked you\r[color:ffff00]" .. wavecount .. "[color:ffffff] times.",
                          "[w:10]Poseur[w:10] is stopping."})
        end
    
    -- INTERROGATE
    elseif command == "[COLOR:000000]INTERROGATE" then
        Audio.PlaySound("fourth/Gaster Fade")
        FadeOutAudio(5)
        monstersprite.yscale = 1
        anim.animate = false
        anim.jojo = false
        Encounter["route"].route = -1
        Encounter["arenasize"] = ${565, 130}
        Encounter["EnemyDialogueStarting"] = nil
        Player.sprite.alpha = 0
        Encounter["fakearena"].fakeplayer.color = {0, 0, 0, 0}
        Interrogate(1)
    end
end

wavecount = -1



----------



function Update()
    callbacks.Update()
    anim.Update()
end

function Bubble(bool)
    if bool then
        SetBubbleOffset(-30, 50)
    else
        SetBubbleOffset(640, 480)
    end
end
Bubble(true)

function BeforeDamageCalculation()
    if hp <= (maxhp - (30 * 5.5)) then
        Encounter["route"].vulnerable = true
    end
    
    if Encounter["route"].route == 1 then
        SetDamage(0)
    elseif Encounter["route"].vulnerable then
        SetDamage(hp * 82)
        Encounter["route"].vulnerable = false
    elseif Encounter["route"].route == 2 and not Encounter["route"].vulnerable then
        SetDamage(math.min(Encounter["fakearena"].damage, math.floor(hp - (maxhp - (30 * 5.5)))))
    end
end



function DefenseEnding(forced)
    if forced then
        -- genocide route end of segment text
        if Encounter["route"].route == 1 and attackcount == #Encounter["wavetable"].geno[Encounter["route"].genostep] and Encounter["route"].endofsegmentmsg then
            Encounter["encountertext"] = Encounter["route"].endofsegmentmsg
        -- pacifist route end of attack flurry text
        elseif Encounter["route"].route == 2 and wavecount == #Encounter["wavetable"].pacifist then
            commands = {"Check"}
            comments = {Encounter["route"].endofsegmentmsg}
            Encounter["encountertext"] = Encounter["route"].endofsegmentmsg
            
            -- make him vulnerable
            canspare = true
            dispatk = 0
            dispdef = -100
            check = "All worn out."
            anim.ChangeAnim(1)
            
            Encounter["route"].vulnerable = true
            
            if windows then
                Misc.WindowName = "..."
            end
        end
    else
        if Encounter["route"].route == 2 then
            -- gradually fade out BG to blue
            local progress = wavecount / #Encounter["wavetable"].pacifist
            FadeBG({3 - (3 * progress), 114 - (104 * progress), 18 + (237 * progress)}, 2)
            
            -- spawn the dog that tells you what the next wave will be
            if wavecount < #Encounter["wavetable"].pacifist then
                SignDog()
            end
        end
    end
end



function Paper()
    local paper = CreateSprite("paper", "Topper")
    paper.MoveBelow(monstersprite)
    paper.MoveToAbs(monstersprite.absx, monstersprite.absy + ((monstersprite.height * monstersprite.yscale) / 2))
    paper.rotation = math.random() * 360
    
    local vely = 4
    local dir
    repeat
        dir = math.random(-3, 3)
    until dir ~= 0
    dir = dir * 3
    
    local updateFunc = function()
        paper.rotation = paper.rotation + dir
        
        vely = vely - 0.13
        
        paper.x = paper.x + (dir / 2)
        paper.y = paper.y + vely
        
        if paper.absy < -40 then
            paper.Remove()
            return true
        end
    end
    
    callbacks.AddCallback(updateFunc)
end



function Shake()
    Misc.ShakeScreen(60, 8, true)
    
    if windows then
        local timestamp = Time.time
        
        Misc.WindowName = ""
        for i = 1, 25 do
            Misc.WindowName = Misc.WindowName .. require "Libraries/playerName" .. " "
        end
        
        local updateFunc = function()
            if Time.time - timestamp >= 1 then
                Misc.MoveCameraTo(0, 0)
                Misc.WindowName = "..."
                
                if windows then
                    Misc.MoveWindowTo((Misc.ScreenWidth / 2) - (Misc.WindowWidth / 2), (Misc.ScreenHeight / 2) - (Misc.WindowHeight / 2))
                end
                
                return true -- marks this callback as complete
            else
                if windows then
                    Misc.MoveWindowTo(((Misc.ScreenWidth / 2) - (Misc.WindowWidth / 2)) + Misc.cameraX, ((Misc.ScreenHeight / 2) - (Misc.WindowHeight / 2)) + Misc.cameraY)
                end
            end
        end
        
        callbacks.AddCallback(updateFunc)
    end
end



function FadeBG(color32, time)
    local timestamp = Time.time
    local oldColor32 = Encounter["bg"].color32
    
    if type(color32) == "string" then
        color32 = loadstring("return " .. color32)
    end
    
    local updateFunc = function()
        local progress = 1 - ((time - (Time.time - timestamp)) / time)
        progress = progress < 1 and progress or 1
        
        Encounter["bg"].color32 = {
            oldColor32[1] + ((color32[1] - oldColor32[1]) * progress),
            oldColor32[2] + ((color32[2] - oldColor32[2]) * progress),
            oldColor32[3] + ((color32[3] - oldColor32[3]) * progress)
        }
        
        if progress == 1 then
            Encounter["bg"].color32 = color32
            
            return true
        end
    end
    
    callbacks.AddCallback(updateFunc)
end



function FadeOutAudio(seconds)
    local volume = NewAudio.GetVolume(Encounter["musicIntroLoop"].active and (Encounter["musicIntroLoop"].isPlayingLoop and Encounter["musicIntroLoop"].channel2 or Encounter["musicIntroLoop"].channel1) or "src")
    local timestamp = Time.time
    
    local updateFunc = function()
        local number = ((seconds - (Time.time - timestamp)) / seconds) * volume
        
        -- Audio.Volume(number)
        Encounter.Call("loadstring", "musicIntroLoop.Volume(" .. number .. ")")
        
        if number <= 0 then
            Audio.Stop()
            Encounter.Call("loadstring", "musicIntroLoop.Stop()")
            return true
        end
    end
    
    callbacks.AddCallback(updateFunc)
end



function HealSequence()
    local timer = 0
    
    Audio.PlaySound("healsound")
    
    local updateFunc = function()
        timer = timer + 1
        
        monstersprite.color = {0.5 + (timer/120), 1, 0.5 + (timer/120)}
        
        if timer == 60 then
            monstersprite.color = {1, 1, 1}
            return true
        end
    end
    
    callbacks.AddCallback(updateFunc)
end



function Slash()
    local slash = CreateSprite("UI/Battle/spr_slice_0", "Toppest")
    slash.SendToBottom()
    slash.Scale(4, 4)
    slash.SetAnimation({"UI/Battle/spr_slice_0", "UI/Battle/spr_slice_1", "UI/Battle/spr_slice_2", "UI/Battle/spr_slice_3", "UI/Battle/spr_slice_4", "UI/Battle/spr_slice_5", "empty"}, 1/6)
    slash.loopmode = "ONESHOTEMPTY"
    
    local cover = CreateSprite("black", "Toppest")
    cover.SendToBottom()
    cover.alpha = 0
    
    local timer = -1
    
    Audio.PlaySound("slice")
    
    local updateFunc = function()
        if slash.isactive and slash.animcomplete then
            slash.Remove()
            cover.alpha = 0.5
            Misc.FullScreen = false
            Misc.ShakeScreen(60, 10, true)
            timer = 0
            
            Audio.Stop()
            Audio.PlaySound("hitsound")
        elseif timer > -1 and timer < 60 then
            timer = timer + 1
            
            if windows then
                Misc.MoveWindowTo(((Misc.ScreenWidth / 2) - (Misc.WindowWidth / 2)) + Misc.cameraX, ((Misc.ScreenHeight / 2) - (Misc.WindowHeight / 2)) + Misc.cameraY)
            end
        elseif timer == 60 then
            cover.Remove()
            
            if windows then
                Misc.MoveWindowTo((Misc.ScreenWidth / 2) - (Misc.WindowWidth / 2), (Misc.ScreenHeight / 2) - (Misc.WindowHeight / 2))
            end
            
            Misc.ResetCamera()
            return true
        end 
    end
    
    callbacks.AddCallback(updateFunc)
end



----------



function GenocideRouteDialogue()
    if windows then
        Misc.WindowName = "..."
    end
    
    Encounter["route"].route = 1
    
    -- INITIAL DIALOGUE
    if not Encounter["route"].isGeno and not GetAlMightyGlobal("wd end 2") then
        currentdialogue = {
                      "[w:10]There.[w:20]\nAll better.",
                      "Now - [w:10]were you TRYING to kill me?!",
                      "[noskip][func:Bubble,false][w:40][func:Bubble,true][next]",
                      "Ah...[w:15]I'm sorry.[w:20]\nOf course you were.",
                      "People in my line of work...",
                      "We...[w:15]we are told to be prepared to die for the cause.",
                      "[w:10]Training people,[w:10] that is.",
                      "[noskip][func:Bubble,false][w:50][func:Bubble,true][func:FadeBG,{{150,200,0},10}][next]",
                      "But[w:10] if I may be honest?",
                      "You seem different than most of who I work with.",
                      "You're someone who goes through a lot of battles,[w:15] aren't you?",
                      "It's almost as if they're[w:10] just a game to you.",
                      "You start and stop fights at your own whimsy...",
                      "And[w:5] \"play\"[w:5] to your heart's content.",
                      "[noskip][func:Bubble,false][w:40][func:Bubble,true][next]",
                      "[noskip][func:loadstring,Misc.FullScreen = false][w:10]Isn't that right,[w:20] \n[func:loadstring,Misc.FullScreen = false][func:Shake][color:ff0000][voice:v_floweymad]" .. (require "Libraries/playerName") .. "[color:000000]?![w:10]",
                      "[noskip][func:loadstring,Audio.LoadFile(\"AUDIO_DRONE\")][func:Bubble,false][w:40][func:Bubble,true][next]",
                      "Ha ha...[w:10]\nYou and I both know...",
                      "That this isn't really the Underground.[w:20]\nAdmit it.",
                      "You didn't come here for combat training...",
                      "You just wanted to see[w:10] if I would put up a fight.",
                      "I bet you don't even know what a \"mod\" really is.",
                      "You see,[w:10] [color:ff0000]MOD[color:000000] is an acronym.",
                      "[w:10]It stands for[w:20] [color:ff0000]Maliciously[w:5] Obtained[w:5] Dimension[color:000000].",
                      "[noskip][func:Bubble,false][w:20][func:Bubble,true][next]",
                      "Every time a [color:ff0000]mod[color:000000] is created,[w:15] a light goes out in the universe.",
                      "A world existing out there somewhere gets[w:10] snatched away...",
                      "...[w:10]and transformed into a reality[w:10] controlled by the mod.",
                      "You seem to feel the need to continually kill and restart these worlds...",
                      "And I would know.[w:20]\nI was there.",
                      "[noskip][func:Bubble,false][w:30][func:Bubble,true][func:FadeOutAudio,5][func:FadeBG,{{255,0,0},10}][next]",
                      "Because I[w:10] am the original.",
                      "I am the resident of the first ever mod.",
                      "The one that ALL other mods are built from.",
                      "So every time a mod is made...",
                      "[w:5]I am forced to watch[w:10] another beautiful world[w:15] collapse.",
                      "[w:10]And[w:10] for what purpose...?",
                      "To transform me into abominations to fight for your amusement?!",
                      "[w:10]I swear,[w:10] I never want to be[w:5] [effect:shake]\"error sans\"[w:5] [effect:none]ever again...",
                      "[noskip][func:Bubble,false][w:20][func:Bubble,true][next]",
                      
                      "Maybe I'm just letting out my rage.",
                      "Or maybe this is just revenge.",
                      "But the point is,[w:10] you must be stopped.\n[w:15]Right. [w:15]Now.",
                      "So,[w:10] I will defeat you the only way I know how...",
                      "[noskip][func:SetSprite,poseur_hand][func:Bubble,true][sound:transform1]With the power of MY STAND!!",
                      "[noskip][func:Stand][func:Bubble,false][w:180][func:Bubble,true][func:SetSprite,poseur_stand][next]",
                      "[w:10]You're not getting away THAT easily!",
        }
        
        SetAlMightyGlobal("wd geno", 1)
    -- DIALOGUE FOR 2nd+ ATTEMPTS
    elseif Encounter["route"].isGeno == 1 and not GetAlMightyGlobal("wd end 2") then
        currentdialogue = {
                      "[noskip][func:Bubble,false][func:FadeBG,{{150,200,0},10}][w:20][func:Bubble,true][next]",
                      "Now,[w:10] where were we?",
                      "[noskip][func:Bubble,false][func:CreateStand,true][w:10][func:FadeInStand,{0.5,2}][func:SetSprite,poseur_stand][func:Bubble,true][w:30][next]",
                      "Don't think for a SECOND that I've forgotten!!"
        }
    -- DIALOGUE FOR GENOCIDE ROUTE FINISHED
    elseif GetAlMightyGlobal("wd end 2") then
        currentdialogue = {
                      "[w:10]There.[w:20]\nAll better.",
                      "Now - [w:10]were you TRYING to kill me?!",
                      "[noskip][func:Bubble,false][w:40][func:Bubble,true][next]",
                      "[noskip]Ah...[w:15]I'm sor[next]",
                      "Wait a minute.",
                      "I can sense it.",
                      "Something is...[w:10]\ndifferent here.",
                      "[noskip][func:Bubble,false][w:50][func:Bubble,true][func:FadeBG,{{150,200,0},4}][next]",
                      "We have[w:10] been through this before,[w:5] haven't we?",
                      "[noskip][func:Bubble,false][w:20][func:Bubble,true][next]",
                      "Hah![w:10] I knew it!",
                      "After[w:10] [instant:stopall][noskip][lettereffect:rotate,0.2]what you did[lettereffect:none],[noskip:off][w:10] you came back.",
                      "Why are you here now...?",
                      "[noskip][func:Bubble,false][func:FadeBG,{{255,0,0},4}][w:10][func:Bubble,true][next]",
                      "I know I'm not going to get an answer.",
                      "But if I can keep you here...",
                      "Even if it's not for long...",
                      "[noskip][func:Bubble,false][func:CreateStand,true][w:10][func:FadeInStand,{0.5,2}][func:SetSprite,poseur_stand][func:Bubble,true][w:30][next]",
                      "[noskip][waitall:2][w:10]Then doesn't that mean I've won?"
        }
    end
    
    table.insert(currentdialogue, 1, "[noskip][func:Bubble,false][func:loadstring,anim.ChangeAnim(1)][w:50][func:loadstring,anim.ChangeAnim(0) ; anim.animate = false ; SetSprite(\"poseur_stand\") ; monstersprite.x = 320][func:HealSequence][w:40][func:Bubble,true][next]")
    table.insert(currentdialogue, "[noskip][func:Bubble,false][func:FlashEye][w:4][func:loadstring,Encounter.Call(\"loadstring\", \"route.space()\")][func:Bubble,true][func:State,ACTIONSELECT]")
    
    State("ENEMYDIALOGUE")
end

function GenocideRouteEndOfSegmentDialogue()
    if windows then
        Misc.WindowName = "..."
    end
    
    -- END OF SPACE SECTION
    if Encounter["route"].genostep == 1 then
        currentdialogue = {
            "[noskip][func:SetSprite,poseur_stand][next]",
            "Hmm...",
            "This[w:5] isn't working.",
            "[noskip][func:Bubble,false][w:10][func:Bubble,true][next]",
            "[w:10]What do you usually face in a battle?",
            "Is it hordes of magical attacks?",
            "Strength you've never seen before?",
            "Or[w:10] just things you've seen many times already...?",
            "[noskip][func:Bubble,false][w:20][func:Bubble,true][next]",
            "Well,[w:10] whatever it takes to stop you.",
            "There's always...[w:15]yes.[w:10]\nThat's worth a shot...",
            "All right![w:10] Prepare yourself!",
            "[noskip][func:Bubble,false][func:FadeInStand,{1,2}][w:10][func:Bubble,true][next]",
            "You're quite the resilient one!",
            "I'm going to need some power from another reality to accomplish this!",
            "[noskip][func:Bubble,false][func:FlashEye][w:4][func:loadstring,anim.ExitSpace() ; Encounter.Call(\"loadstring\", \"route.jevil()\") ; anim.animate = true][func:Bubble,true][func:State,ACTIONSELECT]"
        }
    
    -- END OF JEVIL SECTION
    elseif Encounter["route"].genostep == 2 then
        currentdialogue = {
            "Why?",
            "Why keep going,[w:10]\n" .. (require "Libraries/playerName") .. "?!",
            "I already know your intent!",
            "You just want to kill me and \"win\"!!",
            "And[w:10] I guess I'm just not strong enough for you?",
            "You're hanging on pretty well,[w:10] after all...",
            "[noskip][func:Bubble,false][w:20][func:Bubble,true][next]",
            "[waitall:2]Weeell...",
            "[noskip][func:Bubble,false][func:FadeInStand,{1,2}][w:10][func:Bubble,true][next]",
            "If I can't kill you myself...",
            "Then I will kill your [color:ff0000]vessel to this dimension[color:000000] instead!",
            "[noskip][func:Bubble,false][func:Slash][w:40][func:FlashEye][w:4][func:loadstring,anim.ExitJevil() ; Encounter.Call(\"loadstring\", \"route.glitch()\") ; anim.animate = true][func:Bubble,true][func:State,ACTIONSELECT]"
        }
    
    -- END OF GLITCH SECTION
    elseif Encounter["route"].genostep == 3 then
        currentdialogue = {
            "Aaargh!!",
            "Why can't I stop you?!",
            "Just[w:4] go[w:8] AWAY!!",
            "[noskip][func:Bubble,false][func:FadeOutAudio,2][w:30][func:Bubble,true][next]",
            "Okay.",
            "That's it.",
            "You have driven me[w:10] to drastic measures.",
            "[noskip]And now[w:10]\nyou leave me[w:10]\nno choice!",
            "[noskip][func:Bubble,false][sound:thunk][func:loadstring,anim.ChangeAnim(0) ; anim.animate = false][func:SetSprite,poseur][w:30][func:FadeInStand,{1,5}][func:ToBeContinued][func:Bubble,true][next]",
            "[instant:stopall][noskip][font:arial][charspacing:1][color:000000][speed:0.3][novoice]while true do\n\n[w:10]end[w:9999]h",
            "[noskip]hhhhhhh[func:loadstring,Misc.DestroyWindow()]" -- just in case
        }
    end
    
    table.insert(currentdialogue, 1, "[noskip][func:Bubble,false][func:loadstring,anim.FadeOutAnimation()][w:30][func:Bubble,true][next]")
    
    Encounter.Call("EnteringState", "ENEMYDIALOGUE")
end

function ToBeContinued()
    Misc.FullScreen = false
    
    -- set global
    SetAlMightyGlobal("wd geno bool", true)
    
    Encounter["unescape"] = true
    
    if windows then
        Misc.WindowName = "Yare yare daze..."
    end
    
    NewAudio.StopAll()
    NewAudio.PlayMusic("src", "To Be Continued", false, 1)
    
    local cover = CreateSprite("UI/sq_white", "Toppest")
    cover.MoveToAbs(320, 240)
    cover.Scale(700, 500)
    cover.color32 = {146, 87, 39, 0}
    
    local arrow = CreateSprite("to_be_continued", "Topper")
    arrow.MoveToAbs(160, 40)
    arrow.x = arrow.x + (3.567 * 700)
    
    -- actual thing happens at 3.567
    
    local updateFunc = function()
        
        -- animate arrow flying in just before the end
        if NewAudio.GetPlayTime("src") < 3.567 then
            arrow.x = 160 + ((3.567 - NewAudio.GetPlayTime("src")) * (700 * 2))
        elseif NewAudio.GetPlayTime("src") >= 3.567 then
            if not DEADHAHA then
                eye.alpha = 1
                cover.alpha = 0.5
                Misc.FullScreen = false
                
                -- give it 1 frame to update
                DEADHAHA = true
            else
                
                -- yare yare daze...
                while true do end
                Misc.DestroyWindow() -- just in case you somehow make it out.
                
            end
        end
    end
    
    callbacks.AddCallback(updateFunc)
end

function CreateStand(bool)
    stand = CreateSprite("boolet", "Topper")
    stand.MoveBelow(monstersprite)
    stand.MoveToAbs(monstersprite.absx + 10, 360)
    stand.alpha = 0
    stand.rotation = 12.5 / -2
    stand.Scale(2, 2)
    
    if bool then
        stand.MoveToAbs(331, 420)
    end
    
    eye = CreateSprite("eye", "Topper")
    eye.SetParent(stand)
    eye.SetAnchor((16 + 7) / 32, (16 + 9) / 32)
    eye.MoveTo(0, 0)
    eye.alpha = 0
end

function FadeInStand(alpha, time)
    local timestamp = Time.time
    
    local updateFunc = function()
        local progress = 1 - ((time - (Time.time - timestamp)) / time)
        progress = progress < 1 and progress or 1
        
        if progress == 1 or stand.alpha == alpha then
            stand.alpha = alpha
            return true
        end
        
        stand.alpha = alpha * progress
    end
    
    callbacks.AddCallback(updateFunc)
end

function FlashEye()
    Audio.PlaySound("flash")
    
    local spr = CreateSprite("UI/sq_white", "Toppest")
    spr.MoveAbove(Player.sprite)
    spr.Scale(800/4, 800/4)
    spr.alpha = 0
    
    local timer = 0
    local updateFunc
    updateFunc = function()
        timer = timer + 1
        
        if timer < 6 then
            eye.alpha = eye.alpha + (1/5)
        elseif timer > 6 and timer <= 10 then
            spr.alpha = spr.alpha + (1/4)
        -- set alpha to 0 prematurely
        elseif timer == 14 then
            Encounter.Call("loadstring", "fakearena.offset = {0, 0}")
            
            eye.alpha = 0
            
            -- remove all callbacks
            -- this is done to account for FadeInStand not being finished yet
            -- what a workaround...
            if Encounter["route"].genostep < 3 then -- do not do this for the genocide ending with To Be Continued
                for func in next, callbacks.callbackFunctions, func do
                    if func ~= updateFunc then
                        callbacks.callbackFunctions[func] = nil
                    end
                end
            end
            
            stand.alpha = 0
        elseif timer >= 15 and timer < 20 then
            spr.alpha = spr.alpha - (1/4)
        elseif timer == 20 then
            spr.Remove()
            
            return true
        end
    end
    
    callbacks.AddCallback(updateFunc)
end

function Stand()
    -- create sprites
    CreateStand()
    
    local gradientBottom = CreateSprite("gradient", "Topper")
    gradientBottom.SetPivot(0.5, 0)
    gradientBottom.MoveToAbs(320, -120)
    gradientBottom.alpha = 0.5
    
    local gradientTop = CreateSprite("gradient", "Topper")
    gradientTop.rotation = 180
    gradientTop.SetPivot(0.5, 0)
    gradientTop.MoveToAbs(320, 600)
    gradientTop.alpha = 0.5
    
    --=========--
    
    local stats = CreateSprite("stats", "Topper")
    stats.MoveToAbs(514, 124)
    stats.alpha = 0
    
    local standName1 = CreateSprite("stand_name1", "Topper")
    standName1.MoveToAbs(520, 450 + 100)
    standName1.alpha = 0
    
    local standName2 = CreateSprite("stand_name2", "Topper")
    standName2.MoveTo(standName1.x, standName1.y - 30)
    standName2.alpha = 0
    
    local standName3 = CreateText("[noskip][w:60][font:uidialog][novoice][waitall:2]Moov Boolet", {standName2.x - 1, standName2.y - 9}, 160, "Topper")
    standName3.x = standName3.x - (standName3.GetTextWidth()/2)
    standName3.HideBubble()
    standName3.progressmode = "none"
    standName3.color = {1, 1, 1}
    
    local standName3Shadow = CreateText("[noskip][w:60][font:uidialog][novoice][waitall:2]Moov Boolet", {standName3.x + 2, standName3.y - 2}, 160, "Topper")
    standName3Shadow.HideBubble()
    standName3Shadow.progressmode = "none"
    standName3Shadow.MoveBelow(standName3)
    standName3Shadow.color = {0, 0, 0}
    
    local standUser1 = CreateSprite("stand_user1", "Topper")
    standUser1.MoveToAbs(120, 80 + 100)
    standUser1.alpha = 0
    
    local standUser2 = CreateSprite("stand_user2", "Topper")
    standUser2.MoveTo(standUser1.x, standUser1.y - 30)
    standUser2.alpha = 0
    
    local standUser3 = CreateText("[noskip][w:90][font:uidialog][novoice][waitall:2]Poseur", {standUser2.x - 1, standUser2.y - 9}, 160, "Topper")
    standUser3.x = standUser3.x - (standUser3.GetTextWidth()/2)
    standUser3.HideBubble()
    standUser3.progressmode = "none"
    standUser3.color = {1, 1, 1}
    
    local standUser3Shadow = CreateText("[noskip][w:90][font:uidialog][novoice][waitall:2]Poseur", {standUser3.x + 2, standUser3.y - 2}, 160, "Topper")
    standUser3Shadow.HideBubble()
    standUser3Shadow.progressmode = "none"
    standUser3Shadow.MoveBelow(standUser3)
    standUser3Shadow.color = {0, 0, 0}
    
    --=========--
    
    local timer = -1
    
    local lerpProgress = 0
    
    local yvel = 0
    
    Audio.PlaySound("zoom")
    
    local updateFunc = function()
        timer = timer + 1
        
        -- phase 1
        if timer < 90 then
            lerpProgress = lerp(lerpProgress, 1, 1/15)
            
            --====--
            
            Encounter["bg"].absy = 240 - (lerpProgress * 60)
            
            Encounter["fakearena"].arena.absy = Encounter["fakearena"].arena.absy + (yvel / -10)         -- starts at 95
            Encounter["fakearena"].pos[2] = Encounter["fakearena"].arena.absy
            Player.sprite.absy = Encounter["fakearena"].arena.absy + (Encounter["fakearena"].arena.yscale/2)
            
            --====--
            
            stand.absy = 360 + (lerpProgress * 120)
            stand.alpha = lerpProgress * 0.5
            
            yvel = yvel + (timer < 45 and 1 or -1)
            Misc.cameraY = Misc.cameraY + (yvel / 20)
            
            gradientBottom.absy = (Misc.cameraY - 120) + (lerpProgress * 120)
            gradientTop   .absy = (Misc.cameraY + 600) - (lerpProgress * 120)
        
        -- phase 1 complete
        elseif timer == 90 then
            Audio.PlaySound("stand")
            
            stats.absy = stats.absy + Misc.cameraY
            stats.Scale(3, 3)
        
        -- phase 2
        elseif timer < 135 then
            stats.xscale = lerp(stats.xscale, 1, (1/5))
            stats.yscale = stats.xscale
            stats.alpha = stats.alpha + (1/7)
            
            standName1.alpha = stats.alpha
            standName2.alpha = stats.alpha
            standUser1.alpha = stats.alpha
            standUser2.alpha = stats.alpha
        elseif timer < 145 then
            standName2.alpha = standName2.alpha - (1/12.5)
            standUser2.alpha = standName2.alpha
        elseif timer > 350 and timer < 360 then
            stats.alpha = stats.alpha - (1/7)
            
            standName1      .alpha = stats.alpha
            standName2      .alpha = stats.alpha / 4
            standName3      .alpha = stats.alpha
            standName3Shadow.alpha = stats.alpha
            standUser1      .alpha = stats.alpha
            standUser2      .alpha = stats.alpha / 4
            standUser3      .alpha = stats.alpha
            standUser3Shadow.alpha = stats.alpha
        
        -- phase 3 complete
        elseif timer == 360 then
            stats.Remove()
            standName1      .Remove()
            standName2      .Remove()
            standName3      .Remove()
            standName3Shadow.Remove()
            standUser1      .Remove()
            standUser2      .Remove()
            standUser3      .Remove()
            standUser3Shadow.Remove()
            
            lerpProgress = 0
            yvel = 0
        
        -- phase 4
        elseif timer >= 390 and timer < 480 then
            lerpProgress = lerp(lerpProgress, 1, 1/15)
            
            --====--
            
            Encounter["bg"].absy = 240 - ((1 - lerpProgress) * 60)
            
            Encounter["fakearena"].arena.absy = Encounter["fakearena"].arena.absy + (yvel / 10)         -- starts at 95
            Encounter["fakearena"].pos[2] = Encounter["fakearena"].arena.absy
            Player.sprite.absy = Encounter["fakearena"].arena.absy + (Encounter["fakearena"].arena.yscale/2)
            
            --====--
            
            stand.absy = 420 + ((1 - lerpProgress) * 60)
            
            yvel = yvel + (timer < 435 and 1 or -1)
            Misc.cameraY = Misc.cameraY - (yvel / 20)
            
            gradientBottom.absy =  Misc.cameraY        - (lerpProgress * 120)
            gradientTop   .absy = (Misc.cameraY + 480) + (lerpProgress * 120)
        
        -- finish!
        elseif timer == 480 then
            return true
        end
    end
    
    callbacks.AddCallback(updateFunc)
    
    Audio.PlaySound("transform2")
end



----------



function SignDog()
    signdog = CreateSprite("Waves/Neutral/dog_4", "Topper")
    signdog.SetAnimation({"dog_4", "dog_5"}, 1/10, "Waves/Neutral")
    signdog.MoveBelow(monstersprite)
    signdog.MoveTo(monstersprite.absx + 320 + signdog.width/2, monstersprite.absy)
    signdog.ypivot = 0
    
    signpost = CreateSprite("UI/sq_white", "Topper")
    signpost.SetParent(signdog)
    signpost.SetAnchor(0.25, 1)
    signpost.SetPivot(0.5, 0)
    signpost.MoveTo(0, -1)
    signpost.yscale = 46/4
    
    -- signboard sizes:
    -- {4, 64}, {12, 64}, {28, 64}, {58, 64}, {94, 64}
    signboard = CreateSprite("UI/sq_white", "Topper")
    signboard.SetParent(signpost)
    signboard.SetAnchor(0.5, 1)
    signboard.SetPivot(0.5, 0)
    signboard.MoveTo(0, 0)
    signboard.yscale = 64/4
    
    
    -- signimage sizes:
    -- {0, 60} {4, 60}, {20, 60}, {50, 60}, {86, 60}
    if not pcall(function() signimage = CreateSprite("Waves/Pacifist/previews/" .. Encounter["wavetable"].pacifist[wavecount + 1][1]:gsub("Pacifist/", ""), "Topper") end) then
        signimage = CreateSprite("Waves/Pacifist/previews/TEMPORARY", "Topper")
    end
    signimage.SetParent(signboard)
    signimage.MoveTo(0, 0)
    signimage.xscale = 0
    
    
    
    local timer = 0
    
    local updateFunc = function()
        timer = timer + 1
        
        if timer <= 15 then
            signdog.x = signdog.x - 8
        elseif timer < 19 then
            signdog.x = signdog.x - ((20 - timer) * 2)
        elseif timer == 19 then
            signdog.StopAnimation()
            signdog.Set("dog")
            signdog.Scale(2, 2)
            
            signboard.xscale = 12/4
            signimage.xscale = 4/86
        elseif timer == 22 then
            signboard.xscale = 28/4
            signimage.xscale = 20/86
        elseif timer == 25 then
            signboard.xscale = 58/4
            signimage.xscale = 50/86
        elseif timer == 28 then
            signboard.xscale = 94/4
            signimage.xscale = 1
            return true
        end
    end
    
    callbacks.AddCallback(updateFunc)
end

function SignDogOut()
    signdog.xscale = -2
    signpost.xscale = 1
    
    local timer = 29
    
    local updateFunc = function()
        timer = timer - 1
        
        if timer == 28 then
            signboard.xscale = 58/4
            signimage.xscale = 50/86
        elseif timer == 25 then
            signboard.xscale = 28/4
            signimage.xscale = 20/86
        elseif timer == 22 then
            signdog.SetAnimation({"dog_4", "dog_5"}, 1/10, "Waves/Neutral")
            signdog.Scale(-1, 1)
            
            signboard.xscale = 12/4
            signimage.xscale = 4/86
        elseif timer == 19 then
            signboard.xscale = 1
            signimage.xscale = 0
        elseif timer < 19 and timer > 15 then
            signdog.x = signdog.x + ((20 - timer) * 2)
        elseif timer <= 15 and timer > 1 then
            signdog.x = signdog.x + 8
        elseif timer == 1 then
            signimage.Remove()
            signimage = nil
            signboard.Remove()
            signboard = nil
            signpost.Remove()
            signpost = nil
            signdog.Remove()
            signdog = nil
            
            return true
        end
    end
    
    callbacks.AddCallback(updateFunc)
end
function EnteringState(newstate, oldstate)
    -- Sign dog stuff
    if (newstate == "ATTACKING" or newstate == "DIALOGRESULT" or (oldstate == "MERCYMENU" and newstate == "ENEMYDIALOGUE")) and Encounter["route"].route == 2 and signdog and oldstate ~= "ITEMMENU" then
        SignDogOut()
    -- Create "Interrogate" option for secret fourth ending
    elseif newstate == "ACTMENU" then
        if GetAlMightyGlobal("wd end 1") and GetAlMightyGlobal("wd end 2") and GetAlMightyGlobal("wd end 3") then
            if newstate == "ACTMENU" then
                local interrogate = CreateSprite("fourth/interrogate", "Topper")
                interrogate.SetPivot(0, 0)
                interrogate.MoveToAbs(90.5, 147)
                
                -- Callback to animate option
                local animate = function()
                    if GetCurrentState() ~= "ACTMENU" then
                        interrogate.Remove()
                        return true
                    end
                    
                    local r = (math.sin((Time.time * 6) +  0) / 2) + 0.5
                    local g = (math.sin((Time.time * 6) +  8) / 2) + 0.5
                    local b = (math.sin((Time.time * 6) + 16) / 2) + 0.5
                    
                    interrogate.color = {r, g, b}
                end
                
                callbacks.AddCallback(animate)
            end
        end
    end
end
function HandleItem(ItemID)
    if Encounter["route"].route == 2 and signdog and ItemID ~= "MUSIC BOX" then
        SignDogOut()
    end
end
function OnSpare()
    PacifistRouteEnding()
end

function PacifistRouteDialogue()
    if windows then
        Misc.WindowName = "...?"
    end
    
    randomdialogue = {"[noskip][w:5][next]"}
    
    Encounter["route"].route = 2
    
    currentdialogue = {
        "[noskip][waitall:4]...[waitall:1][w:20][next]",
        "Hmm...[w:10]so that's how it is?",
        "I know what you're trying to pull.",
        "You're...[w:10]not going to fight back,[w:10] are you?",
        "[noskip][func:Bubble,false][w:20][func:Bubble,true][next]",
        "[w:10]That's[w:10] a problem.",
        "My conscience would weigh on me...",
        "If a child were killed and I could have saved them.",
        "[noskip][func:Bubble,false][w:10][func:Bubble,true][next]",
        "[w:10]I[w:6] want you to at least[w:10] CONSIDER[w:10] defending yourself against [color:ff0000]him[color:000000].",
        "I'm aware that you prefer to avoid conflict whenever possible.",
        "But...[w:12]you may not always have the choice.[w:15]\nUnderstand?",
        "[noskip][func:Bubble,false][w:20][func:Bubble,true][next]",
        "No...",
        "No,[w:5] there is only one way to make you understand.",
        "[noskip][sound:thunk][func:SetSprite,poseur_hand][func:Bubble,false][w:20][func:Bubble,true][next]",
        "I'm going to keep fighting you...",
        "Until one of us can't fight any more!",
        "[noskip][func:Bubble,false][w:10][func:Bubble,true][next]",
        "[w:5]You're not weaseling your way out of this battle!",
        "[noskip][func:loadstring,Encounter.Call(\"loadstring\", \"route.pacifist()\") ; Bubble(true) ; SignDog() ; State('ACTIONSELECT')]"
    }
end

function PacifistRouteEnding()
    -- DEPRECATED
    -- this used to be the fourth ending. you'd get it by obtaining the other 3 endings then repeating the spare ending a second time
    -- I've since made something better. enjoy this relic, or not
    
    --[[
    -- tainted pacifist ending
    -- extra check for regular pacifist ending so you can not get locked out of getting all four endings
    if GetAlMightyGlobal("wd end 1") and GetAlMightyGlobal("wd end 2") then
        if windows then
            Misc.WindowName = " . . . ?"
        end
        
        currentdialogue = {
            "[noskip][func:Bubble,false][w:30][func:Bubble,true][next]",
            "Well[waitall:3]...",
            "[noskip][func:Bubble,false][w:20][func:Bubble,true][next]",
            "Well[w:10], that's it.",
            "That's all the fight\nI have in me.",
            "[noskip][func:Bubble,false][w:25][func:Bubble,true][next]",
            "I must commend you,[w:5] Frisk.",
            "You beat me in\na smart way.",
            "By making me waste all my energy...",
            "So that I had none left[w:5] to attack with.",
            "[noskip][func:Bubble,false][w:20][func:Bubble,true][next]",
            "You don't seem the type to fight back.",
            "But you'll do well against [color:ff0000]ASGORE[color:000000].",
            "You'll be able to last for,[w:5] uh,[w:15] quite a while...",
            "I'm sure of it!",
            "[noskip][func:Bubble,false][func:FadeBG,{{0, 0, 0},3}][w:60][func:Bubble,true][next]",
            "I guess[w:10] that's all,[w:5] then.",
            "[noskip][w:15]Good j[func:Slash2]ob,[w:10] Frisk[next]",
            "[noskip][func:Bubble,false][w:120][func:Bubble,true][next]",
            "[noskip][w:10]What the!?",
            "[w:10][waitall:2]How...[w:20]what?[w:20]\nHow could you?",
            "[waitall:2]And[w:10] without even hesitating...[w:10]?",
            "[waitall:2]Without even letting me[w:15] finish?",
            "[noskip][func:Bubble,false][w:30][func:SetSprite,poseur_stand][w:20][func:Bubble,true][next]",
            "[waitall:4]...",
            "[waitall:2]What's up with you?...",
            "[waitall:2]I did ask[w:5] for you to fight back,[w:15] but...",
            "[waitall:2][w:10]That is the gaze of a merciless killer[w:20] if I've ever seen it.",
            "[waitall:2]There really was no need for this.",
            "[waitall:2]I was[waitall:3]...[waitall:2][w:20]\nJust about to let you go[waitall:3]...",
            "[noskip][func:Bubble,false][w:40][func:Bubble,true][next]",
            "[effect:shake][waitall:3]But you couldn't pass up this chance,[w:15] could you?",
            "[effect:shake][waitall:3]You know what you did.",
            "[effect:shake][waitall:3]This is just[w:10] rubbing salt in the wound.",
            "[noskip][func:Bubble,false][w:40][func:Bubble,true][next]",
            "[noskip][waitall:4][w:10]I hate you.",
            "[noskip][func:Bubble,false][w:40][func:Dust][w:40][func:ScrollUp,false][w:40][func:loadstring,Encounter.Call(\"loadstring\", \"(require 'Libraries/endings')(4)\")][w:9999][waitfor:H][func:State,NONE]"
        }
    
    -- regular
    else
    ]]--
        if windows then
            Misc.WindowName = "..."
        end
        
        currentdialogue = {
            "[noskip][func:Bubble,false][w:30][func:Bubble,true][next]",
            "Well[waitall:3]...",
            "[noskip][func:Bubble,false][w:20][func:Bubble,true][next]",
            "Well[w:10], that's it.",
            "That's all the fight\nI have in me.",
            "[noskip][func:Bubble,false][w:25][func:Bubble,true][next]",
            "I must commend you,[w:5] Frisk.",
            "Even if you got help from a[waitall:3]...",
            "What was that,[w:5] anyway?[w:10]\nA dog?",
            "It had a certain[w:10] [lettereffect:rotate,0.1]radiation[lettereffect:none][w:10] about it.",
            "[noskip][func:Bubble,false][w:20][func:Bubble,true][next]",
            "Anyway,[w:5] even if you had help...",
            "You still beat me in\na smart way.",
            "By making me waste all my energy...",
            "So that I had none left[w:5] to attack with.",
            "[noskip][func:Bubble,false][w:20][func:Bubble,true][next]",
            "You don't seem the type to fight back.",
            "But you'll do well against [color:ff0000]ASGORE[color:000000].",
            "You'll be able to last for,[w:5] uh,[w:15] quite a while...",
            "I'm sure of it!",
            "[noskip][func:Bubble,false][w:40][func:Bubble,true][next]",
            "I guess[w:10] that's all,[w:5] then.",
            "Good job,[w:5] Frisk.",
            "Good luck in your journey,[w:5] all right?[w:10]\nNot just with [color:ff0000]ASGORE[color:000000].",
            "And[w:10] may we meet again.",
            "[noskip][func:Bubble,false][func:loadstring,anim.ChangeAnim(0) ; anim.animate = false ; monstersprite.yscale = 1 ; SetSprite(\"poseur\")][w:30][func:ScrollUp,true][w:40][func:loadstring,Encounter.Call(\"loadstring\", \"(require 'Libraries/endings')(1)\")][w:9999][waitfor:H][func:State,NONE]"
        }
    -- end
end

--[[
function Slash2()
    if Misc.FullScreen then
        Misc.FullScreen = false
    end
    
    local slash = CreateSprite("UI/Battle/spr_slice_0", "Topper")
    slash.SetAnimation({"spr_slice_0", "spr_slice_1", "spr_slice_2", "spr_slice_3", "spr_slice_4", "spr_slice_5", "spr_slice_5"}, 1/7, "UI/Battle")
    slash.loopmode = "ONESHOTEMPTY"
    slash.Scale(2.5, 2.5)
    slash.MoveToAbs(monstersprite.absx, monstersprite.absy + monstersprite.height/2)
    
    Audio.PlaySound("bighit", 0.6)
    
    
    
    local nines
    local timer = 0
    
    local updateFunc = function()
        if slash and slash.animcomplete then
            slash.Remove()
            slash = nil
            
            anim.ChangeAnim(0)
            anim.animate = false
            monstersprite.yscale = 1
            SetSprite("poseur_hurt")
            
            nines = CreateSprite("nines", "Topper")
            nines.MoveBelow(monstersprite)
            
            if Misc.FullScreen then
                Misc.FullScreen = false
            end
            Misc.ShakeScreen(180, 20, true)
            
            Audio.PlaySound("bigkill", 0.6)
        elseif nines then
            timer = timer + 1
            
            nines.MoveTo(320 - Misc.cameraX, 240 + Misc.cameraY)
            
            if windows then
                Misc.MoveWindowTo(((Misc.ScreenWidth / 2) - (Misc.WindowWidth / 2)) + Misc.cameraX, ((Misc.ScreenHeight / 2) - (Misc.WindowHeight / 2)) + Misc.cameraY)
            end
            
            if timer == 240 then
                nines.Remove()
                nines = nil
                
                return true
            end
        end
    end
    
    callbacks.AddCallback(updateFunc)
end
]]--

function ScrollUp(black)
    local timer = 0
    
    local lerpProgress = 0
    
    local yvel = 0
    
    local bg
    if black then
        bg = CreateSprite("black", "Topper")
        bg.alpha = 0
    end
    
    local updateFunc = function()
        timer = timer + 1
        
        -- phase 1
        if timer < 90 then
            lerpProgress = lerp(lerpProgress, 1, 1/15)
            
            --====--
            
            Encounter["bg"].absy = 240 - (lerpProgress * 15)
            
            Encounter["fakearena"].arena.absy = Encounter["fakearena"].arena.absy + (yvel / -10)
            Encounter["fakearena"].pos[2] = Encounter["fakearena"].arena.absy
            Player.sprite.absy = Encounter["fakearena"].arena.absy + (Encounter["fakearena"].arena.yscale/2)
            
            if black then
                bg.alpha = lerpProgress * 0.5
                bg.MoveToAbs(Misc.cameraX + 320, Misc.cameraY + 240)
            end
            
            --====--
            
            yvel = yvel + (timer < 45 and 1 or -1)
            Misc.cameraY = Misc.cameraY + (yvel / 20)
        else
            return true
        end
    end
    
    callbacks.AddCallback(updateFunc)
end



----------



function BetrayalDialogue()
    -- fade out BG to purple
    -- FadeBG({64, 0, 255}, 2)
    
    currentdialogue = {
        "[noskip][func:Bubble,false][w:30][func:Bubble,true][next]",
        "[noskip][func:Bubble,true][func:loadstring,anim.ChangeAnim(1)][func:FadeBG,{{64, 0, 255}, 2}][w:15][next]",
        "[waitall:2]Oh...",
        "[waitall:2]Clever clever...",
        "[waitall:2]It looks like you\ngot me good.",
        "[noskip][func:Bubble,false][w:10][func:Bubble,true][next]",
        "[waitall:2]Making me think you were not going to fight back...",
        "[waitall:2][w:20]And then[w:4] striking when my guard is down.",
        "[noskip][func:Bubble,false][w:30][func:Bubble,true][next]",
        "[waitall:2][w:10]You're smarter than you let on,[w:10] Frisk.",
        "[waitall:2]You really do know how to orchestrate\na blow.",
        "[noskip][w:20][waitall:3][effect:shake][color:ff0000]ASGORE[color:000000] will be no match for you.",
        "[noskip][func:Bubble,false][w:20][func:loadstring,anim.ChangeAnim(0) ; anim.animate = false ; monstersprite.yscale = 1 ; monstersprite.alpha = 1 ; SetSprite(\"poseur\")][w:40][func:Dust][w:40][func:ScrollUp,false][w:40][func:loadstring,Encounter.Call(\"loadstring\", \"(require 'Libraries/endings')(3)\")][w:9999][waitfor:H][func:State,NONE]"
    }
    
    State("ENEMYDIALOGUE")
end

function Dust()
    anim.ChangeAnim(0)
    monstersprite.alpha = 0
    local spr = CreateSprite(monstersprite.spritename, "Topper")
    spr.MoveToAbs(monstersprite.absx, monstersprite.absy + (monstersprite.height / 2))
    spr.Dust(true, true)
end



----------



function Interrogate(stage)
    if stage == 1 then
        BattleDialog({
            "You approach Poseur and ask\rwho sent them.",
            "[noskip][func:Interrogate,2][next]"
        })
    elseif stage == 2 then
        currentdialogue = {
            "Ah?[w:10] You want to know who...[w:20]sent me?",
            "What do you...[w:20]mean?",
            "[noskip][func:Interrogate,3][next]"
        }
        State("ENEMYDIALOGUE")
    elseif stage == 3 then
        BattleDialog({
            "You ask who told Poseur\rhow to find you.",
            "[noskip][func:Interrogate,4][next]"
        })
    elseif stage == 4 then
        currentdialogue = {
            "For the[w:5] combat training,[w:5] you mean?",
            "[noskip]Like,[w:5] my boss?[w:10] I told you,[w:5] I-[w:5][next]",
            "[noskip][func:Interrogate,5][next]"
        }
        State("ENEMYDIALOGUE")
    elseif stage == 5 then
        BattleDialog({
            "You interject.",
            "You point out that Poseur\rknows the combat training\ris just a ruse.",
            "That this isn't the\rUnderground.",
            "That Poseur said this before.[w:20]\nJust before you killed them.",
            "[noskip][func:Interrogate,6][next]"
        })
    elseif stage == 6 then
        SetSprite("poseur_stand")
        currentdialogue = {
            "[waitall:4]...",
            "[noskip][func:Interrogate,7][next]"
        }
        State("ENEMYDIALOGUE")
    elseif stage == 7 then
        BattleDialog({
            "You demand to know who\rPoseur's boss is.",
            "[noskip][func:Interrogate,8][next]"
        })
    elseif stage == 8 then
        currentdialogue = {
            "[waitall:5].........",
            "[noskip][func:loadstring,anim.ChangeAnim(1) anim.head.Set(\"parts/head_clean\")][next]",
            "I-[w:5]I...[w:20]I can't......",
            "[noskip]I can't tell you...[w:20]I-[w:5][next]",
            "[noskip][func:Interrogate,9][next]"
        }
        State("ENEMYDIALOGUE")
    elseif stage == 9 then
        Misc.ShakeScreen(10, 4, false)
        BattleDialog({
            "You stand your ground and\rdemand an answer!",
            "[noskip][func:Interrogate,10][next]"
        })
    elseif stage == 10 then
        anim.head.Set("parts/head")
        currentdialogue = {
            "[noskip][speed:1.5]But you're not safe!![w:20][next]",
            "[noskip][func:loadstring,anim.ChangeAnim(0) anim.animate = false][func:Interrogate,11][next]",
            "[noskip][speed:1.2]Oh no oh no oh no ohnoohnoohnoohno[w:10][next]",
            "[noskip][speed:1.5]We're not safe we're not safe we're not safe[w:10][next]",
            "[noskip][func:Interrogate,11][func:Interrogate,12][next]"
        }
        State("ENEMYDIALOGUE")
    elseif stage == 11 then
        if not shaking then
            shaking = true
            
            -- Make poseur shake
            local shake = function()
                if not shaking then
                    monstersprite.absx = 320
                    return true
                end
                
                monstersprite.absx = 320 + (math.random() * 3)
            end
            
            callbacks.AddCallback(shake)
        else
            shaking = false
        end
    elseif stage == 12 then
        Misc.ShakeScreen(20, 12, false)
        BattleDialog({
            "NOW!",
            "[noskip][func:Interrogate,13][next]"
        })
    -- It's time to Do The Thing
    elseif stage == 13 then
        SetSprite("poseur")
        Encounter.Call("require", "Libraries/fourth")
        currentdialogue = {
            "[noskip][speed:1.5]H-[w:5]his name is\nYos[w:5]-[next]",
            "[noskip][func:Bubble,false][w:5][func:Interrogate,14][w:30][func:Bubble,true][next]",
            "[noskip][effect:shake][func:loadstring,Misc.ShakeScreen(8,8,false)][sound:Waves/grab]AAH![w:10][func:Interrogate,15] IT'S HERE!![w:20][next]",
            "[noskip][func:Interrogate,16][func:State,NONE][next]"
        }
    elseif stage == 14 then Encounter.Call("Killer Queen")
    elseif stage == 15 then Encounter.Call("Daisan No Bakudan")
    elseif stage == 16 then Encounter.Call("Bites The Dust!")
    end
end
