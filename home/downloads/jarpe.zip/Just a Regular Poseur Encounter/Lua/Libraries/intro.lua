return function(encountername)
    local skip = true

    if not GetAlMightyGlobal("super excellent intro owo") then
        skip = false
    end

    local timer = 0
    local sprites = {}

    --===========--
    local stuff = (require "Libraries/fakeModSelect")(encountername)
    local      cover =      stuff.cover
    local  bigparent =  stuff.bigparent
    local smolparent = stuff.smolparent
    local   modname1 =   stuff.modname1
    local   modname2 =   stuff.modname2
    local encounter1 = stuff.encounter1
    local encounter2 = stuff.encounter2
    --===========--

    local poseur = CreateSprite("poseur", "Topper")
    poseur.color = {0, 0, 0, 0}
    local text

    -- initial creations
    local CreateBG = function()
        local bg = CreateSprite("intro_bg", "Topper")
        bg.alpha = 0
        sprites[bg] = true
        
        if cover then
            bg.MoveBelow(cover)
        elseif poseur then
            bg.MoveBelow(poseur)
        end
    end

    if not skip then
        Audio.LoadFile("AUDIO_ANOTHERHIM")
        Audio.Volume(0)
        
        if windows then
            Misc.WindowName = ""
        end
        
        sprites = {}
        CreateBG()
    else
        black.SendToBottom()
    end

    fakearena.arena.Scale(arenasize[1] + 1, arenasize[2] + 2)

    --===========--

    function Update()
        fakearena.Update()
        updateDebugger()
        
        timer = timer + 1
        
        -- volume increases
        if timer <= 60 and not skip then
            Audio.Volume((timer / 60) * 0.25)
        end
        
        -- cover fades out
        if cover and cover.alpha > 0 then
            cover.alpha = cover.alpha - (1/120)
            modname1.alpha = cover.alpha
            modname2.alpha = cover.alpha
            encounter1.alpha = cover.alpha
            encounter2.alpha = cover.alpha
        elseif cover and cover.alpha == 0 then
            cover.Remove()
            modname1.Remove()
            modname2.Remove()
            bigparent.Remove()
            encounter1.Remove()
            encounter2.Remove()
            smolparent.Remove()
            cover = nil
            modname1 = nil
            modname2 = nil
            bigparent = nil
            encounter1 = nil
            encounter2 = nil
            smolparent = nil
        end
        
        -- update bgs
        if timer%2 == 0 then
            local count = 0
            for bg in pairs(sprites) do
                bg.xscale = bg.xscale + 0.0025
                bg.yscale = bg.xscale
                
                bg.alpha = math.sin((math.abs(bg.xscale) - 1) * 5) / 3
                
                if bg.alpha <= 0 then
                    bg.Remove()
                    sprites[bg] = nil
                end
                count = count + 1
            end
            
            if timer%240 == 0 then
                CreateBG()
            end
        end
        
        -- animate poseur
        if timer >= 240 and timer < 300 then
            poseur.alpha = poseur.alpha + (1/60)
        -- text
        elseif timer == 300 then
            poseur.alpha = 1
            text = CreateText("", {0, 0}, 600, "Topper")
            text.HideBubble()
            text.progressmode = "none"
            
            local txt = {
                "[noskip]♪[w:60][noskip:off]H...[w:20]hello?",
                "[noskip]♪[w:30][noskip:off]So...",
                "You have found me.",
                "[noskip]♪[w:40][noskip:off]Long have I waited[w:15] to be useful.",
                "To be used to help people\n    learn[w:10] and to grow.",
                "[noskip]♪[w:10][waitall:3]...",
                "[noskip]♪[w:30][noskip:off]Three years[w:20] have I waited.",
                "...[w:10]and I have only been abused[w:5]\n      time and time again.",
                "[noskip]♪[w:10][noskip:off]My feelings eluded me[w:10]\n for the longest time.",
                "But now.",
                "Now[w:10] I am being used again.",
                "[w:10]...[w:10]for a good cause.",
                "[noskip]♪[w:10][noskip:off] I feel...[w:10]included.",
                "I feel[w:4] loved.",
                "[noskip][w:20][waitall:1]I feel         [w:10][alpha:0]h"
            }
            
            for _, line in pairs(txt) do
                txt[_] = "[font:monster][color:ffffff][alpha:0.25][novoice]" .. line
            end
            
            text.SetText(txt)
            text.MoveTo(320 - text.GetTextWidth()/2, 240)
        -- end intro
        elseif text and text.allLinesComplete then
            text.Remove()
            
            poseur.Remove()
            poseur = nil
            
            for bg in pairs(sprites) do
                bg.Remove()
            end
            sprites = nil
            
            skip = true
        -- advance text
        elseif text and text.lineComplete and Input.Confirm == 1 then
            text.NextLine()
            text.MoveTo(320 - text.GetTextWidth()/2, 240)
        end
        
        --===========--
        
        if skip and not cover then
            if poseur then
                poseur.Remove()
                poseur = nil
            end
            
            SetAlMightyGlobal("super excellent intro owo", true)
            EncounterStarting(text ~= nil)
            return
        end
    end
end
