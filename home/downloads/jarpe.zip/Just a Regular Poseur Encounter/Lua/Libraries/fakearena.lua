local self = {}

--==============--
-- UI VARIABLES --
--==============--

self.speed = 8.3 * 2
self.pos = {320, 95}
self.offset = {0, 0}
self.font = "uidialog"
self.damagefont = "uidamagetext"
self.voice = "uifont"
self.effect = "[effect:twitch]"
self.charspacing = 3
self.spacewidth = 16

-- internal
self.menuAction = 1
self.page = 1
self.item = 1
self.attacking = 0 -- 0: not attacking 1: moving left 2: moving right
self.attackTimer = 0
self.damageTexts = {}



-- create sprites
self.arena = CreateSprite("px", "Topper")
self.arena.color = {0, 0, 0}
self.arena.ypivot = 0
self.arena.MoveTo(320, 95)
self.arena.Scale(565, 130)

do
    self.top = CreateSprite("px", "Topper")
    self.top.SetPivot(0.5, 0)
    self.top.yscale = 5
    self.top.SetParent(self.arena)
    self.top.SetAnchor(0.5, 1)
    self.top.MoveTo(0, 0)

    self.bottom = CreateSprite("px", "Topper")
    self.bottom.SetPivot(0.5, 1)
    self.bottom.yscale = 5
    self.bottom.SetParent(self.arena)
    self.bottom.SetAnchor(0.5, 0)
    self.bottom.MoveTo(0, 0)

    self.left = CreateSprite("px", "Topper")
    self.left.SetPivot(1, 0.5)
    self.left.xscale = 5
    self.left.SetParent(self.arena)
    self.left.SetAnchor(0, 0.5)
    self.left.MoveTo(0, 0)

    self.right = CreateSprite("px", "Topper")
    self.right.SetPivot(0, 0.5)
    self.right.xscale = 5
    self.right.SetParent(self.arena)
    self.right.SetAnchor(1, 0.5)
    self.right.MoveTo(0, 0)

    self.topleft = CreateSprite("px", "Topper")
    self.topleft.SetPivot(1, 0)
    self.topleft.Scale(5, 5)
    self.topleft.SetParent(self.arena)
    self.topleft.SetAnchor(0, 1)
    self.topleft.MoveTo(0, 0)

    self.topright = CreateSprite("px", "Topper")
    self.topright.SetPivot(0, 0)
    self.topright.Scale(5, 5)
    self.topright.SetParent(self.arena)
    self.topright.SetAnchor(1, 1)
    self.topright.MoveTo(0, 0)

    self.bottomleft = CreateSprite("px", "Topper")
    self.bottomleft.SetPivot(1, 1)
    self.bottomleft.Scale(5, 5)
    self.bottomleft.SetParent(self.arena)
    self.bottomleft.SetAnchor(0, 0)
    self.bottomleft.MoveTo(0, 0)
    
    self.bottomright = CreateSprite("px", "Topper")
    self.bottomright.SetPivot(0, 1)
    self.bottomright.Scale(5, 5)
    self.bottomright.SetParent(self.arena)
    self.bottomright.SetAnchor(1, 0)
    self.bottomright.MoveTo(0, 0)
end

self.target = CreateSprite("UI/spr_target_0", "Topper")
self.target.SetParent(self.arena)
self.target.MoveTo(0, 0)
self.target.alpha = 0

-- for menus
self.fakeplayer = CreateSprite("ut-heart", "Topper")
self.fakeplayer.SetParent(self.arena)
self.fakeplayer.MoveTo(0, 0)
self.fakeplayer.color = Player.sprite.color

self.enemyhpred = CreateSprite("px", "Topper")
self.enemyhpred.SetParent(self.arena)
self.enemyhpred.SetPivot(0, 0)
self.enemyhpred.MoveTo(-2, 21)
self.enemyhpred.color = {1, 0, 0}
self.enemyhpred.Scale(90, 20)
self.enemyhpred.alpha = 0

self.enemyhpgreen = CreateSprite("px", "Topper")
self.enemyhpgreen.SetParent(self.enemyhpred)
self.enemyhpgreen.SetPivot(0, 0)
self.enemyhpgreen.SetAnchor(0, 0)
self.enemyhpgreen.MoveTo(0, 0)
self.enemyhpgreen.color = {0, 1, 0}
self.enemyhpgreen.Scale(90, 20)
self.enemyhpgreen.alpha = 0



-- create text
self.textParent = CreateSprite("empty", "Topper")
self.textParent.SetParent(self.arena)
self.textParent.SetAnchor(0, 1)

self.textStars = CreateText("", {54, 183}, 65535, "Topper")
self.textStars.HideBubble()
self.textStars.progressmode = "none"
self.textStars.SetParent(self.textParent)
self.textStars.MoveTo(16, -122)

self.text = CreateText("", {92, 183}, 65535, "Topper")
self.text.HideBubble()
self.text.progressmode = "none"
self.text.SetParent(self.textParent)
self.text.MoveTo(38 + 16, -122)

-- update function
function self.Update()
    local state = GetCurrentState()
    
    --====================--
    -- ACTUAL ARENA STUFF --
    --====================--
    
    -- auto-resizing
    
    -- x
    if self.arena.xscale < arenasize[1] then
        local playerpos = Player.sprite.absx
        self.arena.xscale = self.arena.xscale + (self.speed * Time.mult)
        
        if self.arena.xscale > arenasize[1] then
            self.arena.xscale = arenasize[1]
        end
        
        if state == "DEFENDING" then
            Player.sprite.absx = playerpos
        end
    elseif self.arena.xscale > arenasize[1] then
        local playerpos = Player.sprite.absx
        self.arena.xscale = self.arena.xscale - (self.speed * Time.mult)
        
        if self.arena.xscale < arenasize[1] then
            self.arena.xscale = arenasize[1]
        end
        
        if state == "DEFENDING" then
            Player.sprite.absx = playerpos
        end
    end
    
    -- y
    if self.arena.yscale < arenasize[2] then
        local playerpos = Player.sprite.absy
        self.arena.yscale = self.arena.yscale + (self.speed * Time.mult)
        
        if self.arena.yscale > arenasize[2] then
            self.arena.yscale = arenasize[2]
        end
        
        if state == "DEFENDING" then
            Player.sprite.absy = playerpos
        end
    elseif self.arena.yscale > arenasize[2] then
        local playerpos = Player.sprite.absy
        self.arena.yscale = self.arena.yscale - (self.speed * Time.mult)
        
        if self.arena.yscale < arenasize[2] then
            self.arena.yscale = arenasize[2]
        end
        
        if state == "DEFENDING" then
            Player.sprite.absy = playerpos
        end
    end
    
    self.top   .xscale = self.arena.xscale
    self.bottom.xscale = self.arena.xscale
    
    self.left .yscale = self.arena.yscale -- + 10
    self.right.yscale = self.arena.yscale -- + 10
    
    
    
    self.target.Scale(self.arena.xscale / 565, self.arena.yscale / 130)
    
    
    
    -- auto-moving
    
    -- x
    if self.arena.x < (self.pos[1] + self.offset[1]) then
        self.arena.x = self.arena.x + (self.speed * Time.mult)
        
        if self.arena.x > (self.pos[1] + self.offset[1]) then
            self.arena.x = (self.pos[1] + self.offset[1])
        end
    elseif self.arena.x > (self.pos[1] + self.offset[1]) then
        self.arena.x = self.arena.x - (self.speed * Time.mult)
        
        if self.arena.x < (self.pos[1] + self.offset[1]) then
            self.arena.x = (self.pos[1] + self.offset[1])
        end
    end
    
    -- y
    if self.arena.y < (self.pos[2] + self.offset[2]) then
        self.arena.y = self.arena.y + (self.speed * Time.mult)
        
        if self.arena.y > (self.pos[2] + self.offset[2]) then
            self.arena.y = (self.pos[2] + self.offset[2])
        end
    elseif self.arena.y > (self.pos[2] + self.offset[2]) then
        self.arena.y = self.arena.y - (self.speed * Time.mult)
        
        if self.arena.y < (self.pos[2] + self.offset[2]) then
            self.arena.y = (self.pos[2] + self.offset[2])
        end
    end
    
    
    --========================--
    -- FAKE STATES AND THINGS --
    --========================--
    
    -- ACTIONSELECT
    
    
    if state == "ACTIONSELECT" then
        --[[
        if Input.Left == 1 then
            self.menuAction = (self.menuAction - 1) > 0 and self.menuAction - 1 or 4
        elseif Input.Right == 1 then
            self.menuAction = (self.menuAction + 1) < 5 and self.menuAction + 1 or 1
        end
        ]]--
        
        self.menuAction = ({ [48] = 1, [202] = 2, [361] = 3, [515] = 4 })[Player.absx]
    end
    
    if state == "ACTIONSELECT" and self.menuAction == 3 and Input.Confirm == 1 and Inventory.ItemCount == 0 then
        if CYFversion < "0.6.5" then
            self.text.DoSkipFromPlayer()
            self.textStars.DoSkipFromPlayer()
        else
            -- Text.DoSkipFromPlayer has been disabled in CYF v0.6.5
            -- So, here, I am recreating its behavior by hand instead
            
            -- Find where the text currently is
            local outputs = {self.textText[self.text.currentLine + 1], self.textStarsText[self.textStars.currentLine + 1]}
            
            for i = 1, 2 do
                local input = outputs[i]
                
                local commands = {}
                local match = input:find("%[[^%]]+%]")
                while match ~= nil do
                    table.insert(commands, {index = match, command = input:match("%[[^%]]+%]", #commands > 0 and (commands[#commands].index + 1) or 0)})
                    match = input:find("%[[^%]]+%]", commands[#commands].index + 1)
                end
                
                outputs[i] = {
                    inputtext = input,
                    visibletext = input:gsub("%[[^%]]+%]", ""),
                    commands = commands
                }
            end
            
            -- self.text first
            local remainingText = self.textText
            for i = 1, self.text.currentLine do
                table.remove(remainingText, 1)
            end
            
            remainingText[1] = outputs[1].visibletext
            local index = self.text.currentReferenceCharacter + 1
            remainingText[1] = remainingText[1]:sub(1, index - 1) .. outputs[1].visibletext:sub(index)
            
            offsetFromCommands = 0
            for i = 1, #outputs[1].commands do
                local command = outputs[1].commands[i]
                
                if i >= index + offsetFromCommands then
                    break
                end
                
                if not (string.startsWith(command.command, "[w") or string.startsWith(command.command, "[i") or string.startsWith(command.command, "[func")) then
                    remainingText[1] = remainingText[1]:sub(1, command.index - 1) .. command.command .. remainingText[1]:sub(command.index)
                    offsetFromCommands = command.index + #command.command
                end
            end
            
            remainingText[1] = "[instant]" .. remainingText[1]
            self.text.SetText(remainingText)
        end
    end
    
    -- ATTACKING
    
    -- damage text updater
    for _, pair in pairs(self.damageTexts) do
        pair[2] = pair[2] + 1
        
        if pair[2] < 30 then
            pair[1].y = 380 + (math.sin((pair[2] + 4) / 10) * 20)
        elseif pair[2] == 30 then
            pair[1].y = 380
        elseif pair[2] == 100 then
            pair[1].Remove()
            self.damageTexts[_] = nil
        end
    end
    
    if self.attacking > 0 then
        -- not yet pressed Z
        if self.attackTimer == 0 then
            self.bar.Move(7 * (self.attacking == 1 and -1 or 1) * Time.mult, 0)
            
            -- MISSED
            if math.abs(self.bar.absx - 320) >= self.arena.xscale/2 then
                self.bar.Remove()
                self.bar = nil
                
                -- miss text
                local text = CreateText("[font:" .. self.damagefont .. "][color:c2c2c2][instant]MISS", {320, 430}, 100, "Topper")
                text.HideBubble()
                text.MoveToAbs(320 - (text.GetTextWidth()/2), 430)
                
                enemies[1].Call("HandleAttack", -1)
                
                self.attacking = 0
                self.attackTimer = 0
                State("ENEMYDIALOGUE")
                return
            end
            
            -- PRESSED Z
            if Input.Confirm == 1 then
               Audio.PlaySound("slice")
               
               local atk = Player.weaponatk + Player.atk
               
               local diff = atk - enemies[1]["def"]
               local innerFormula = diff + math.random(0, 2)
               local proximity = math.abs(self.bar.absx - self.arena.absx) <= 12 and 2.2 or (1 - (math.abs(self.bar.absx - self.arena.absx) / (self.arena.xscale / 2))) * 2
               self.damage = math.floor((innerFormula * proximity) + 0.5)
               
               
               enemies[1].Call("BeforeDamageCalculation")
               
               self.bar.SetAnimation({"UI/Battle/spr_targetchoice_0", "UI/Battle/spr_targetchoice_1"}, 1/12) 
               
               self.slash = CreateSprite("UI/Battle/spr_slice_0", "Topper")
               self.slash.SetAnimation({"spr_slice_0", "spr_slice_1", "spr_slice_2", "spr_slice_3", "spr_slice_4", "spr_slice_5"}, 1/9, "UI/Battle")
               self.slash.loopmode = "ONESHOTEMPTY"
               self.slash.xscale = proximity > 2 and 2 or proximity < 1 and 1 or proximity
               self.slash.yscale = self.slash.xscale
               
               
               self.slash.SetParent(enemies[1]["monstersprite"])
               self.slash.MoveTo(0, 0)
               
               self.attackTimer = 1
            end
        -- pressed Z
        else
            -- wait for animation
            if self.slash and self.slash.animcomplete then
                self.slash.Remove()
                self.slash = nil
            -- animation has finished
            elseif not self.slash then
                self.attackTimer = self.attackTimer + 1
                
                -- first frame after slash animation is done
                if self.attackTimer == 2 then
                    -- deal damage to enemy
                    enemies[1].Call("BeforeDamageValues", self.damage)
                    enemies[1]["hp"] = enemies[1]["hp"] - self.damage
                    enemies[1].Call("HandleAttack", self.damage)
                    
                    -- damage text
                    local text = CreateText("[font:" .. self.damagefont .. "][color:" .. (self.damage > 0 and "ff0000" or "c2c2c2") .. "][instant]" .. (self.damage == 0 and "MISS" or self.damage), {0, 0}, 1000, "Topper")
                    text.HideBubble()
                    text.progressmode = "none"
                    -- text.SetParent(enemies[1]["monstersprite"])
                    text.MoveToAbs(enemies[1]["monstersprite"].absx - (text.GetTextWidth()/2), 380)
                    table.insert(self.damageTexts, {text, 0})
                    
                    if self.damage > 0 then
                        Audio.PlaySound("hitsound")
                        
                        self.hpbar1 = CreateSprite("UI/Battle/hp_back", "Topper")
                        self.hpbar1.SetParent(enemies[1]["monstersprite"])
                        self.hpbar1.absx = enemies[1]["monstersprite"].absx
                        self.hpbar1.y = -60
                        self.hpbar1.xscale = (enemies[1]["monstersprite"].width * enemies[1]["monstersprite"].xscale * 1.25) / 100
                        
                        self.hpbar2 = CreateSprite("UI/Battle/hp_front", "Topper")
                        self.hpbar2.SetParent(self.hpbar1)
                        self.hpbar2.SetPivot(0, 0.5)
                        self.hpbar2.x = (-(self.hpbar1.xscale * self.hpbar1.width) / 2) + 2
                        self.hpbar2.y = 0
                        
                        self.hpbar2.xscale = ((enemies[1]["hp"] + self.damage) / enemies[1]["maxhp"]) * self.hpbar1.xscale
                        
                        self.lastmove = 0
                    else
                        self.attackTimer = 73
                    end
                -- animate hp bar and shaking
                elseif self.attackTimer < 32 then
                    local amount = math.ceil((1 - ((self.attackTimer - 2) / 30)) * 5)
                    amount = self.attackTimer % 4 < 2 and -amount or amount
                    
                    enemies[1]["monstersprite"].x = enemies[1]["monstersprite"].x - self.lastmove
                    self.lastmove = amount
                    enemies[1]["monstersprite"].x = enemies[1]["monstersprite"].x + amount
                    
                    self.hpbar2.xscale = ((enemies[1]["hp"] + ((1 - ((self.attackTimer - 2) / 30)) * self.damage)) / enemies[1]["maxhp"]) * self.hpbar1.xscale
                    self.hpbar2.xscale = self.hpbar2.xscale > 0 and self.hpbar2.xscale or 0
                -- end attack
                elseif self.attackTimer == 72 or self.attackTimer == 143 then
                    self.damage = nil
                    self.lastmove = nil
                    
                    self.bar.Remove()
                    self.bar = nil
                    
                    if self.attackTimer == 72 then
                        self.hpbar2.Remove()
                        self.hpbar2 = nil
                        self.hpbar1.Remove()
                        self.hpbar1 = nil
                    end
                    
                    self.attacking = 0
                    self.attackTimer = 0
                    
                    -- kill if applicable
                    if enemies[1]["hp"] <= 0 then
                        if enemies[1]["OnDeath"] then
                            enemies[1].Call("OnDeath")
                        else
                            enemies[1].Call("Kill")
                        end
                    else
                        State("ENEMYDIALOGUE")
                    end
                    
                    return
                end
            end
        end
    else
        self.target.alpha = self.target.alpha - (1/30)
    end
    
    -- ACTMENU
    
    if state == "ACTMENU" then
        --[[
        local old = self.item
        
        -- LEFT, RIGHT
        if (Input.Left == 1 and Input.Right ~= 1) or (Input.Right == 1 and Input.Left ~= 1) then
            -- at left
            if self.item % 2 == 1 and #enemies[1]["commands"] >= self.item + 1 then
                self.item = self.item + 1
            -- at right
            else
                self.item = self.item - 1
            end
        end
        
        -- UP
        if Input.Up == 1 then
            -- at top
            if self.item < 3 and #enemies[1]["commands"] > 1 then
                self.item = self.item + (#enemies[1]["commands"] - 2)
            -- elsewhere
            else
                self.item = self.item - 2
            end
        end
        
        -- DOWN
        if Input.Down == 1 then
            -- at bottom
            if self.item > #enemies[1]["commands"] - 2 and self.item > 2 then
                self.item = self.item - (#enemies[1]["commands"] - 2)
            -- elsewhere
            elseif self.item + 2 <= #enemies[1]["commands"] then
                self.item = self.item + 2
            end
        end
        
        -- move fake player
        if old ~= self.item then
            self.fakeplayer.x = self.item % 2 == 1 and -255 or 0
            self.fakeplayer.y = (self.item - 1) % 4 < 2 and 30 or 0
        end
        ]]--
        self.fakeplayer.MoveTo(Player.absx - 320, Player.absy - 160)
    end
    
    -- ITEMMENU
    
    if state == "ITEMMENU" then
        local old = self.item
        
        -- LEFT
        if Input.Left == 1 then
            -- at left
            if self.item > 4 and self.item % 2 == 1 then
                self.item = self.item - 3
            -- at right
            elseif self.item % 2 == 0 then
                self.item = self.item - 1
            end
        
        -- RIGHT
        elseif Input.Right == 1 then
            -- at left
            if self.item % 2 == 1 then
                self.item = Inventory.itemCount >= self.item + 1 and self.item + 1 or self.item
            -- at right
            else
                if self.item == 8 or (Inventory.itemCount < 8 and self.item == 6) then
                    self.item = self.item - 5
                else
                    self.item = Inventory.itemCount >= self.item + 3 and self.item + 3 or self.item - 1
                end
            end
        
        -- DOWN, UP
        elseif Input.Down == 1 or Input.Up == 1 then
            -- at top
            if (self.item - 1) % 4 < 2 then
                self.item = Inventory.itemCount >= self.item + 2 and self.item + 2 or self.item
            -- at bottom
            else
                self.item = self.item - 2
            end
            
            -- overrides because of weird behavior >.>
            if     Inventory.itemCount == 6 and self.item == 6 then
                self.item = 4
            elseif Inventory.itemCount == 5 and self.item == 5 then
                self.item = 3
            end
        end
        
        if (self.item > 4 and old < 5) or (self.item < 5 and old > 4) then
            self.page = 3 - self.page
        end
        
        self.EnterState("ITEMMENU", "ITEMMENU")
        
        --[[
        -- move fake player
        if old ~= self.item then
            self.fakeplayer.x = self.item % 2 == 1 and -255 or 0
            self.fakeplayer.y = (self.item - 1) % 4 < 2 and 30 or 0
        end
        ]]--
        self.fakeplayer.MoveTo(Player.absx - 320, Player.absy - 160)
    end
    
    -- DIALOGRESULT
    if state == "DIALOGRESULT" and Input.Confirm == 1 and self.text.lineComplete and not self.text.allLinesComplete then
        local oldRot = self.arena.rotation
        
        self.arena.rotation = 0
        self.text.NextLine()
        self.textStars.NextLine()
        self.arena.rotation = oldRot
    end
end

-- enteringstate function
function self.EnterState(newstate, oldstate, post)
    if post then
        -- special stuff goes here
        
        -- DEFENDING --
        if newstate == "DEFENDING" then
            -- manually load a library into waves as soon as they become active!!!
            for i = 1, #Wave do
                Wave[i]["temp"] = Wave[i].Call("load", "(require \"Libraries/fakearena_WAVE_END\")(" .. tostring(i == 1) .. ")")
                Wave[i].Call("temp")
                Wave[i]["temp"] = nil
            end
        end
        
        return
    end
    
    --==============--
    -- ACTIONSELECT --
    --==============--
    if newstate == "ACTIONSELECT" then
        if oldstate == "ENEMYDIALOGUE" or oldstate == "DEFENDING" then
            arenasize = {565, 130}
            self.pos = {320, 95}
            Player.sprite.layer = "Toppest"
            Player.sprite.SetAnchor(0.5, 0.5)
            Player.sprite.SendToBottom()
            Player.sprite.rotation = 0
        end
        
        Player.sprite.alpha = 1
        if Player.sprite["outline"] then ; Player.sprite["outline"].alpha = 1 ; end
        self.fakeplayer.alpha = 0
        
        -- back up encountertext
        local oldEncounterText = type(encountertext) == "string" and encountertext or {}
        
        if type(encountertext) == "string" then
            encountertext = { encountertext }
        else
            for i, str in ipairs(encountertext) do
                oldEncounterText[i] = str
            end
        end
        
        self.FormatText(encountertext, true)
        
        encountertext = "[novoice]" .. encountertext[1]
        State("ACTIONSELECT")
        encountertext = oldEncounterText
    
    --=============--
    -- ENEMYSELECT --
    --=============--
    elseif newstate == "ENEMYSELECT" then
        Player.sprite.alpha = 0
        -- if Player.sprite["outline"] then ; Player.sprite["outline"].alpha = 0 ; end
        self.fakeplayer.color = {Player.sprite.color[1], Player.sprite.color[2], Player.sprite.color[3], 1}
        self.fakeplayer.MoveTo(-255, 30)
        
        self.textStars.SetText("")
        
        local enemyString = ""
        
        for i = 1, #enemies do
            enemyString = enemyString .. (enemies[1]["canspare"] and "[color:ffff00]" or "") .. "* " .. enemies[i]["name"] .. (next(enemies, i) and "\n" or "")
        end
        
        -- account for rotation
        local oldRot = self.arena.rotation
        
        self.arena.rotation = 0
        self.text.SetText("[noskip][font:" .. self.font .. "][color:ffffff][instant][effect:twitch]" .. enemyString)
        self.arena.rotation = oldRot
        
        -- show health bar!
        if self.menuAction == 1 then
            self.enemyhpred.alpha    = 1
            self.enemyhpgreen.alpha  = 1
            self.enemyhpgreen.xscale = (enemies[1]["hp"] / enemies[1]["maxhp"]) * 90
            self.enemyhpgreen.rotation = self.arena.rotation
        end
    
    --===========--
    -- ATTACKING --
    --===========--
    elseif newstate == "ATTACKING" then
        self.textStars.SetText("")
        self.text.SetText("")
        
        self.attacking = math.random(1, 2)
        
        self.target.alpha = 1
        
        self.bar = CreateSprite("UI/Battle/spr_targetchoice_0", "Topper")
        self.bar.SetParent(self.arena)
        self.bar.rotation = self.arena.rotation
        self.bar.SetAnchor(2 - self.attacking, 0.5)
        self.bar.MoveTo(0, 0)
        
        Player.MoveToAbs(-640, -480, true)
        self.fakeplayer.MoveToAbs(-640, 480)
        State("NONE")
    
    --=========--
    -- ACTMENU --
    --=========--
    elseif newstate == "ACTMENU" then
        self.item = 1
        
        self.textStars.SetText("")
        
        local actString = ""
        
        for i = 1, #enemies[1]["commands"] do
            local textToAdd = "* " .. enemies[1]["commands"][i]
            if i > 1 then
                textToAdd = (({[0] = "\t", [1] = "\n"})[i % 2]) .. textToAdd
            end
            
            actString = actString .. textToAdd
        end
        
        -- account for rotation
        local oldRot = self.arena.rotation
        
        self.arena.rotation = 0
        self.text.SetText("[noskip][font:" .. self.font .. "][color:ffffff][instant][effect:twitch]" .. actString)
        self.arena.rotation = oldRot
    
    --==========--
    -- ITEMMENU --
    --==========--
    elseif newstate == "ITEMMENU" then
        Player.sprite.alpha = 0
        -- if Player.sprite["outline"] then ; Player.sprite["outline"].alpha = 0 ; end
        self.fakeplayer.color = {Player.sprite.color[1], Player.sprite.color[2], Player.sprite.color[3], 1}
        self.fakeplayer.MoveTo(-255, 30)
        
        self.textStars.SetText("")
        
        local itemString = ""
        
        -- page 1
        if self.page == 1 then
            for i = 1, Inventory.itemCount > 4 and 4 or Inventory.itemCount do
                local textToAdd = (({[0] = "\t", [1] = "\n"})[i % 2]) .. "* "
                if i == 1 then
                    textToAdd = "* "
                end
                
                itemString = itemString .. textToAdd .. inventory[Inventory.GetItem(i)].name
            end
        -- page 2
        else
            for i = 5, Inventory.itemCount do
                local textToAdd = (({[0] = "\t", [1] = "\n"})[i % 2]) .. "* "
                if i == 5 then
                    textToAdd = "* "
                end
                
                itemString = itemString .. textToAdd .. inventory[Inventory.GetItem(i)].name
            end
        end
        
        itemString = itemString .. ((self.page == 1 and Inventory.itemCount or Inventory.itemCount - 4) >= 3 and "\n" or "\n\n") .. "[alpha:66]" .. inventory[Inventory.GetItem(self.item)].desc .. "[alpha:ff]\tPAGE " .. self.page
        
        -- account for rotation
        local oldRot = self.arena.rotation
        
        self.arena.rotation = 0
        self.text.SetText("[noskip][font:" .. self.font .. "][color:ffffff][instant]" .. itemString)
        self.arena.rotation = oldRot
    
    --===========--
    -- MERCYMENU --
    --===========--
    elseif newstate == "MERCYMENU" then
        Player.sprite.alpha = 0
        -- if Player.sprite["outline"] then ; Player.sprite["outline"].alpha = 0 ; end
        self.fakeplayer.color = {Player.sprite.color[1], Player.sprite.color[2], Player.sprite.color[3], 1}
        self.fakeplayer.MoveTo(-255, 30)
        
        self.textStars.SetText("")
        
        local anyEnemiesSparable = false
        for _, enemy in pairs(enemies) do
            if enemy["canspare"] then
                anyEnemiesSparable = true
                break
            end
        end
        
        local mercyString = (anyEnemiesSparable and "[color:ffff00]" or "") .. "* Spare" .. (flee == false and "" or "\n[color:ffffff]* Flee")
        
        -- account for rotation
        local oldRot = self.arena.rotation
        
        self.arena.rotation = 0
        self.text.SetText("[noskip][font:" .. self.font .. "][color:ffffff][instant]" .. mercyString)
        self.arena.rotation = oldRot
    
    --===============--
    -- ENEMYDIALOGUE --
    --===============--
    elseif newstate == "ENEMYDIALOGUE" then
        Player.sprite.alpha = 0
        if Player.sprite["outline"] then ; Player.sprite["outline"].alpha = 0 ; end
        self.fakeplayer.MoveTo(0, 0)
        
        self.textStars.SetText("")
        self.text.SetText("")
    
    --===========--
    -- DEFENDING --
    --===========--
    elseif newstate == "DEFENDING" then
        Player.sprite.rotation = self.arena.rotation
        Player.sprite.alpha = 1
        if Player.sprite["outline"] then ; Player.sprite["outline"].alpha = 0 ; end
        self.fakeplayer.alpha = 0
    end
    
    
    
    -- OLDSTATE: ITEMMENU
    
    if newstate ~= "ITEMMENU" and oldstate == "ITEMMENU" then
        self.page = 1
        self.item = 1
    
    -- OLDSTATE: ENEMYSELECT
    
    elseif oldstate == "ENEMYSELECT" then
        -- hide health bar
        self.enemyhpred.alpha   = 0
        self.enemyhpgreen.alpha = 0
    end
end

-- text formatter for encountertext and BattleDialog
function self.FormatText(tab, formatFirstOnly)
    if type(tab) == "string" then
        tab = {tab}
    end
    
    local textStarsTable = {}
    local textTable = {}
    
    for _, str in pairs(tab) do
        -- silence [func] commands and format
        local textToDisplay
        if (formatFirstOnly and _ == 1) or not formatFirstOnly then
            textToDisplay = "[charspacing:-" .. self.spacewidth .. "]  [charspacing:" .. self.charspacing .. "]" .. str:gsub("%[func:.-%]", ""):gsub("\r", "\n"):gsub("\n", "\n[charspacing:-" .. self.spacewidth .. "]  [charspacing:" .. self.charspacing .. "]")
        else
            textToDisplay = str
        end
        table.insert(textTable, "[noskip][voice:" .. self.voice .. "][font:" .. self.font .. "]" .. self.effect .. "[color:ffffff][noskip:off]" .. textToDisplay)
        
        -- format for * only
        local textToDisplay = ""
        local skip = 0
        
        for i = 1, #str do
            if skip > 0 then
                skip = skip - 1
            else
                local char = str:sub(i, i)
                if char == "[" then
                    local command = str:sub(i, str:find("%]", i))
                    skip = #command - 1
                    textToDisplay = textToDisplay .. ((string.startsWith(command, "[w") or string.startsWith(command, "[i")) and command or "")
                elseif char == "\n" then
                    textToDisplay = textToDisplay .. "\n*"
                elseif char == "\r" then
                    textToDisplay = textToDisplay .. "\n"
                else
                    textToDisplay = textToDisplay .. " "
                end
            end
        end
        
        textToDisplay = "*" .. textToDisplay
        table.insert(textStarsTable, "[noskip][voice:" .. self.voice .. "][font:" .. self.font .. "]" .. self.effect .. "[color:ffffff][noskip:off]" .. textToDisplay)
    end
    
    local oldRot = self.arena.rotation
    
    self.arena.rotation = 0
    
    self.text.SetText(textTable)
    self.textStars.SetText(textStarsTable)
    
    self.arena.rotation = oldRot
end

-- BattleDialog replacement
function BDialog(...)
    self.fakeplayer.MoveToAbs(-640, -480)
    if Player.sprite["outline"] then ; Player.sprite["outline"].alpha = 0 ; end
    
    local text = (...)
    
    if type(text) ~= "table" then
        text = ({...})
    end
    
    self.FormatText(text)
end

local _bd = BattleDialog
function BattleDialog(...)
    BDialog(...)
    
    local text = (...)
    
    if type(text) ~= "table" then
        text = ({...})
    end
    
    for _, str in pairs(text) do
        text[_] = "[novoice]" .. str
    end
    _bd(text)
end



-- this is not used anywhere in my battle I need to stop making things modulable if they are not meant to be

--[[
local lv = Player.lv

function self.EndBattle()
    Audio.Stop()
    
    if Player.lv > lv then
        Audio.PlaySound("levelup")
        BattleDialog({"YOU WON!\nYou earned " .. enemies[1]["xp"] .. " xp and " .. enemies[1]["gold"] .. " gold.\nYour LOVE increased.", "[noskip][func:State,DONE][next]"})
    else
        BattleDialog({"YOU WON!\nYou earned 0 xp and " .. enemies[1]["gold"] .. " gold.", "[noskip][func:State,DONE][next]"})
    end
end

-- OnDeath replacement
if not enemies[1]["OnDeath"] then
    enemies[1].Call("loadstring", "function OnDeath() ; Kill() ; Encounter.Call(\"loadstring\", \"fakearena.EndBattle()\") ; end")
end

-- OnSpare replacement
if not enemies[1]["OnSpare"] then
    enemies[1].Call("loadstring", "function OnSpare() ; Spare() ; Encounter.Call(\"loadstring\", \"fakearena.EndBattle()\") ; end")
end
]]--



-- wrap State

local _state = State
function State(state)
    _state(state)
    if state == "DONE" then ; return ; end
    
    self.EnterState(state, GetCurrentState(), true)
end

for _, enemy in pairs(enemies) do
    enemy.Call("loadstring",
                    "local _state = State ; "
                 .. "function State(state) ; "
                     .. "Encounter.Call(\"State\", state) ;"
                 .. "end")
end

return self
