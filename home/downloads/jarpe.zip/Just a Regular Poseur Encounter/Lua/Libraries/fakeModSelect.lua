return function(zerosixfourencounter)
    cover = CreateSprite("intro", "Topper")
    cover.Scale(0.5, 0.5)
    

    -- 100% ensure that the fake mod image matches the mod and encounter names possibly chosen by the user
    -- First, get the name of the mod and encounter
    local modname   = "Just a regular Poseur encounter"
    local encounter =             "꞉eyes꞉"
    if CYFversion == "0.6.3" then
        local _, errormsg = xpcall(function() CreateProjectile("asdbfiosdjfaosdijcfiosdjsdo", 0, 0) end, debug.traceback)
        errormsg = errormsg:sub(1, errormsg:find("asdbfiosdjfaosdijcfiosdjsdo") - 10)
        modname = errormsg:sub(errormsg:gsub("/", "\\"):find("\\[^\\]*$") + 1)

        -- in Encounter script currently
        if not Encounter then
            local test = CreateText("", {0, 0}, 0)
            encounter = test.caller.scriptname
            test.DestroyText()
        -- in any other script
        else
            encounter = Encounter.scriptname
        end
    else
        local thing = Misc.OpenFile("", "w")
        modname = thing.filePath
        for i = #modname - 1, 1, -1 do
            if modname:sub(i, i) == "/" then
                modname = modname:sub(i + 1, #modname - 1)
                break
            end
        end

        if zerosixfourencounter then
            encounter = zerosixfourencounter
        end
    end


    -- Second, create 2 sprites and 4 text objects to recreate the mod selection screen
    local bigparent = CreateSprite("empty", "Topper")
    bigparent.SetParent(cover)
    local smolparent = CreateSprite("empty", "Topper")
    smolparent.SetParent(cover)

    -- mod name
    local modname1 = CreateText("[font:PixelOperatorBig][instant]" .. modname, {0, 0}, 1000)
    modname1.HideBubble()
    modname1.progressmode = "none"
    modname1.SetParent(bigparent)
    modname1.MoveTo(0, 0)
    bigparent.MoveToAbs(321 - modname1.GetTextWidth()/2, 384)
    -- now the shadow
    local modname2 = CreateText("[font:PixelOperatorBig][instant]" .. modname, {0, 0}, 1000)
    modname2.HideBubble()
    modname2.progressmode = "none"
    modname2.color = {0, 0, 0}
    modname2.SetParent(bigparent)
    modname2.MoveBelow(modname1)
    modname2.MoveTo(2, -2)

    -- encounter name
    local encounter1 = CreateText("[font:PixelOperatorBig][instant]" .. encounter, {0, 0}, 1000)
    encounter1.HideBubble()
    encounter1.progressmode = "none"
    encounter1.Scale(1/2, 1/2)
    encounter1.SetParent(smolparent)
    encounter1.MoveTo(0, 0)
    smolparent.MoveToAbs((320 + (1/3)) - encounter1.GetTextWidth()/4, 359 + (1/3))
    -- now the shadow
    local encounter2 = CreateText("[font:PixelOperatorBig][instant]" .. encounter, {0, 0}, 1000)
    encounter2.HideBubble()
    encounter2.progressmode = "none"
    encounter2.color = {0, 0, 0}
    encounter2.Scale(1/2, 1/2)
    encounter2.SetParent(smolparent)
    encounter2.MoveBelow(encounter1)
    encounter2.MoveTo(2, -2)


    return {cover = cover, bigparent = bigparent, smolparent = smolparent, modname1 = modname1, modname2 = modname2, encounter1 = encounter1, encounter2 = encounter2, realModName = modname, realEncounterName = encounter}
end
