unescape = true

Audio.LoadFile("mus_wind")

if windows then
    Misc.WindowName = "The End."
end



enemies[1].Call("EncounterStarting")
enemies[1].Call("loadstring", "anim.ChangeAnim(1) ; anim.legs.absy = 140")



-- hide arena
for spr in pairs(({[fakearena.arena] = true,
                   [fakearena.top] = true,
                   [fakearena.topleft] = true,
                   [fakearena.topright] = true,
                   [fakearena.bottom] = true,
                   [fakearena.bottomleft] = true,
                   [fakearena.bottomright] = true,
                   [fakearena.left] = true,
                   [fakearena.right] = true,
                   [fakearena.fakeplayer] = true})) do
    spr.alpha = 0
end
bg.alpha = 0
SetButtonLayer("BelowArena")
black.layer = "Top"
Player.sprite.alpha = 0



-- god I'm lazy lol
enemies[1].Call("loadstring", "wrapper = require \"Libraries/userdataWrapper\" ; "
     .. "wrapper.WrapTime({ time = { get = function(_tim, tim) ; return _tim.time / Encounter[\"speed\"] ; end } })"
)
speed = 2



local cover = CreateSprite("black", "Topper")
local timer = -240
local kill  = false



local dialogue = {
    "[noskip][w:180][next]",
    "...",
    "...[w:10]You're back.",
    "[noskip][w:30][next]",
    "I[w:20] can't believe it.",
    "I...[w:20]failed?",
    "[w:10]I couldn't destroy your vessel...",
    "[w:10]You can still manipulate\n    worlds at will...",
    "[w:20]And[w:15] I suppose you got\n  what you wanted.",
    "...[w:10]Didn't you?",
    "What kind of messed-up point are\n     you trying to prove?!",
    "[w:10]...",
    "[w:10]Okay,[w:20] fine.[w:20] You won.",
    "Go ahead,[w:5] then.[w:10]\n   Do it.",
    "I know you're just here\n     to kill me.",
    "[w:10]...[w:5]And to think...",
    "This all started[w:10] with me saying\n       \"I feel loved.\"",
    "[noskip][w:20][next]",
    "[noskip]You are unforgiveable.",
    
    "[noskip][func:KillPoseur][w:120][func:loadstring,enemies[1].Call(\"SetSprite\",\"poseur\")][w:30][next]",
    "[noskip][effect:shake]See you in the next\n    mod,[w:20] I guess.",
    "[noskip][w:10][func:KillPoseur,1][w:1][func:KillPoseur,2][w:120][next]"
}

-- alternate ending text
if GetAlMightyGlobal("wd end 2") then
    dialogue = {
        "[noskip][w:180][next]",
        "...",
        "...[w:10]You're back.",
        "[noskip][w:30][next]",
        "I...[w:20]I did it.",
        "I managed to keep you here...",
        "...[w:10]just a bit longer.",
        "[noskip][w:20][next]",
        "Ha ha ha...",
        "I'd die a thousand deaths if it\n  means keeping you here!!",
        
        "[noskip][func:KillPoseur][w:120][func:loadstring,enemies[1].Call(\"SetSprite\",\"poseur\")][w:30][next]",
        "[noskip][effect:shake]You still haven't won\n  yet,[w:20] you monster.",
        "[noskip][w:10][func:KillPoseur,1][w:1][func:KillPoseur,2][w:120][next]"
    }
end



for i = 1, #dialogue do
    dialogue[i] = "[noskip][waitall:2][novoice]" .. dialogue[i]:gsub("%[next%]", "[func:AdvanceText]")
end

local text = CreateText(dialogue, {320, 60}, 640, "Topper")
text.HideBubble()
text.progressmode = "none"
text.SetFont("uidialog2")

local slash



function Update()
    enemies[1].Call("loadstring", "anim.Update()")
    
    timer = timer + 1
    
    if timer < 1000 then
        cover.alpha = 1 - (timer / 666)
        Audio.Volume(((timer + 180) / 180) * 0.75)
    end
    
    
    
    if text and text.isactive then
        if text.lineComplete and Input.Confirm == 1 then
            AdvanceText()
        end
    else
        SetAlMightyGlobal("wd geno bool", false)
        local thing = require "Libraries/endings"
        thing(2)
        return
    end
    
    if kill and slash and slash.animcomplete then
        slash.Remove()
        slash = nil
        
        enemies[1].Call("loadstring", "monstersprite.MoveToAbs(anim.legs.absx, anim.legs.absy) ; anim.ChangeAnim(0) ; anim.animate = false ; SetSprite(\"poseur_hurt\")")
        
        nines = CreateSprite("nines", "Topper", 2)
        
        if Misc.FullScreen then
            Misc.FullScreen = false
        end
        Misc.ShakeScreen(180, 20, true)
        
        Audio.PlaySound("bigkill", 0.6)
        
        timer = 1000
    elseif kill and nines then
        nines.MoveTo(320 - Misc.cameraX, 240 + Misc.cameraY)
        if windows then
            Misc.MoveWindowTo(((Misc.ScreenWidth / 2) - (Misc.WindowWidth / 2)) + Misc.cameraX, ((Misc.ScreenHeight / 2) - (Misc.WindowHeight / 2)) + Misc.cameraY)
        end
        
        Audio.Volume(0.75 - ((timer - 1000) / 180))
        
        if timer == 1240 then
            nines.Remove()
            nines = nil
        end
    end
end

function AdvanceText()
    text.NextLine()
	if text and text.isactive then
		text.x = 320 - text.GetTextWidth()/2
	end
end

function KillPoseur(num)
    if not num then
        kill = true
        
        speed = 4
        enemies[1].Call("loadstring", "local y = anim.legs.absy ; anim.ChangeAnim(0) ; anim.ChangeAnim(1) ; anim.animate = false ; anim.legs.absy = y")
        
        slash = CreateSprite("UI/Battle/spr_slice_0", "Topper")
        slash.SetAnimation({"spr_slice_0", "spr_slice_1", "spr_slice_2", "spr_slice_3", "spr_slice_4", "spr_slice_5", "spr_slice_5"}, 1/7, "UI/Battle")
        slash.loopmode = "ONESHOTEMPTY"
        slash.Scale(2.5, 2.5)
        slash.MoveToAbs(enemies[1]["monstersprite"].absx, enemies[1]["anim"].legs.absy + enemies[1]["monstersprite"].height/2)
        
        Audio.PlaySound("bighit", 0.6)
        
        if Misc.FullScreen then
            Misc.FullScreen = false
        end
        
        timer = 500
    
    -- kill ;-;
    elseif num == 1 then
        enemies[1].Call("loadstring", "monstersprite.alpha = 0")
        poseur = CreateSprite("poseur", "Topper")
        poseur.SetParent(enemies[1]["monstersprite"])
        poseur.MoveTo(0, 0)
    
    elseif num == 2 then
        poseur.Dust(true, true)
        poseur = nil
    end
end
