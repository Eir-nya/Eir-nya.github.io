-- A library that controls the user's path and routes, both in the current session and a previous one through AlMightyGlobals

local route = {}

-- 0: neutral, no path decided yet. even if you just did geno and reloaded the mod. you MUST decide on either geno or pacifist from here.
-- 1: geno. the intended best way to experience the mod.
--    once you enter a geno route for the first time, the opening dialogue will always be skipped.
--    once you finish a geno route for the first time, your pacifist ending will always be tainted.
-- 2: pacifist. counts for both tainted and non-tainted pacifist.
route.route = 0



-- used to determine if Poseur is vulnerable:
    -- 1. after attacking him enough during the Neutral route
    -- 2. during the Pacifist route
route.vulnerable = false


route.isGeno = GetAlMightyGlobal("wd geno") and GetAlMightyGlobal("wd geno") or false

-- 0: not geno yet/geno dialogue before phase 1
-- 1: phase 1
-- 2: phase 2
-- 3: phase 3
-- 4: geno ending
route.genostep = 0

--=========================================--
-- functions for entering different phases --
--=========================================--

-- initial setting
function route.neutral()
    -- set window title
    if windows then
        Misc.WindowName = "Unitale"
    end
    
    -- set deathtext
    deathtext = ({
        {"[voice:monsterfont]Hey,[w:5] get up...[w:15]\nYou're not dead,[w:5] are you?",
         "[voice:monsterfont]We still have stuff to do...[w:10]\nCome on, [w:10]" .. Player.name .. "..."},
        {"[voice:monsterfont]Oops,[w:5] haha![w:10]\nMaybe I hit too hard there...",
         "[voice:monsterfont][waitall:4]...[waitall:1][w:10]" .. Player.name .. "?"},
        {"[voice:monsterfont]You're not dodging fast enough!",
         "[voice:monsterfont]You're going to get yourself killed!",
         "[voice:monsterfont][waitall:4]..."},
        {"[voice:monsterfont]You are not ready.[w:10]\nTrain with me some more,[w:10] and...",
         "[voice:monsterfont]Oh,[w:5] get up,[w:5] will you?"}
    })[math.random(4)]
    
    -- function to call on death
    route.deathfunc = function()
        -- I mean, why not? ;3
        if math.random() < 0.5 then
            Audio.PlaySound("uuhhh")
        end
        
        if windows then
            Misc.WindowName = " \" mY mOd iS ChAlLeNgInG BuT FaIr \" "
        end
    end
    
    -- set comments
    enemies[1]["comments"] = {
        "This is looking pretty\rfamiliar.",
        "Smells like code.",
        "Poseur is half-posing,\rhalf-fighting.",
        "This is...[w:10]combat training?",
        "You feel intimidated by\rPoseur's raw posing power[waitall:3]...[waitall:1]![w:15]\nNah,[w:5] not really.",
    }
end

-- space (geno phase 1)
function route.space()
    route.genostep = 1
    
    -- set window title
    if windows then
        Misc.WindowName = "SPACE?!"
    end
    
    -- set deathtext
    deathtext = ({
        {"[voice:monsterfont]I can't believe you would do this.",
         "[voice:monsterfont]Begone,[w:10] " .. (require "Libraries/playerName") .. "."},
        {"[voice:monsterfont]Oh,[w:5] I won?",
         "[voice:monsterfont]Serves you right."},
        {"[voice:monsterfont]You know what you did wrong.",
         "[voice:monsterfont]...[w:10]Don't come back."}
    })[math.random(3)]
    
    
    -- play music
    musicIntroLoop.StartSong("King Caliente (Intro)", "King Caliente (Loop)", 8.591, 0.55)
    
    encountertext = "Poseur is reinvigorated."
    
    route.endofsegmentmsg = "[speed:1.25]Poseur is looking pretty[w:2]\rspaced out."
    
    -- set stats
    enemies[1]["hp"] = enemies[1]["maxhp"]
    enemies[1]["comments"] = {
        "Smells like stars and platinum.",
        "Space?[w:5] But why?",
        "Stars are whizzing past.",
        "Poseur is not amused.",
        "You feel wobbly..."
    }
    enemies[1]["commands"] = {"Check"}
    enemies[1]["check"] = "He's like a completely\rdifferent person."
    enemies[1]["dispatk"] = "£"
    enemies[1]["dispdef"] = "£"
    
    enemies[1].Call("loadstring", "anim.timer = 0 ; anim.EnterSpace()")
    enemies[1]["attackcount"] = 0
    
end

-- jevil (geno phase 2)
function route.jevil()
    route.genostep = 2
    
    -- set window title
    if windows then
        Misc.WindowName = "A simple numbers game."
    end
    
    -- set deathtext
    deathtext = ({
        {"[voice:monsterfont]How have you survived\nup to now?[w:10] Sheesh!",
         "[voice:monsterfont]Don't tell me you're going to try again?",
         "[voice:monsterfont][w:10]O[w:10]k[waitall:4]aaa[speed:0.75]y then[w:10], here we go.[w:10]\nAgain.",
         "[voice:monsterfont]Hmph.[w:10] Good."},
        {"[voice:monsterfont]And don't come back!",
         "[voice:monsterfont]...[w:10]You won't stay down,[w:6]\nthough,[w:8] will you?",
         "[voice:monsterfont][w:5]Have another go,[w:10] then![w:10]\nI'll still win.",
         "[voice:monsterfont][w:10][noskip]Wait,[w:2] was that [w:5]\"no\"\nmeaning [w:5]\"yes\",[w:10] or[w:4][func:loadstring,Input = {Confirm = 1}]"}
    })[math.random(2)]
    
    
    -- play music
    Audio.LoadFile("joker")
    Audio.Volume(0.75)
    
    encountertext = "???"
    
    route.endofsegmentmsg = "[speed:1.25]Poseur looks kinda ¡¢£¤¥!"
    
    enemies[1]["comments"] = {
        "The world is revolving.",
        "Poseur is in multiple places\rat once.",
        "It feels like a whirlwind.",
        "Not as much chaos this time."
    }
    
    enemies[1]["check"] = "He emits an aura of danger."
    enemies[1]["dispatk"] = "???"
    enemies[1]["dispdef"] = "???"
    
    enemies[1].Call("loadstring", "anim.timer = 0 ; anim.EnterJevil()")
    enemies[1]["attackcount"] = 0
end

-- glitch (geno phase 3)
function route.glitch()
    route.genostep = 3
    
    -- set window title
    if windows then
        Misc.WindowName = ""
        -- handled in animation file
    end
    
    -- set effect
    fakearena.effect = "[effect:twitch,255]"
    
    -- set deathtext
    deathtext = ({
        "[voice:monsterfont]There...",
        "[instant:stopall][noskip][func:loadstring,Audio.Volume(0.6)][w:5][func:loadstring,Audio.Volume(0.5)][w:5][func:loadstring,Audio.Volume(0.4)][w:5][func:loadstring,Audio.Volume(0.3)][w:5][func:loadstring,Audio.Volume(0.2)][w:5][func:loadstring,Audio.Volume(0.1)][w:5][func:loadstring,Audio.Stop()][next]",
        "[voice:monsterfont]Now will you PLEASE stop what you're doing?",
        "[instant:stopall][noskip][func:loadstring,Misc.DestroyWindow()]"
    })
    
    -- function to call on death
    route.deathfunc = function()
        Audio["heartsplosion"] = "uuhhh"
        
        if windows then
            Misc.WindowName = "Cook Your Food"
        end
        
        -- updates enemy callbacks properly to allow for fading out
        local _upd = Update
        function Update()
            enemies[1].Call("loadstring", "callbacks.Update()")
            _upd()
        end
    end
    
    
    -- play music
    musicIntroLoop.StartSong("Smithy First Battle (Intro)", "Smithy First Battle (Loop)", 9.273, 0.6)
    
    encountertext = {"Poseur is attacking the window[instant:stopall][noskip][w:5][next]",
            "[instant]Poseur is attacking the[instant:stopall][noskip][w:2][next]",
            "[instant]Poseur is attacking[instant:stopall][noskip][w:2][next]",
            "[instant]Poseur is[instant:stopall][noskip][w:2][next]",
            "[instant]Poseur[instant:stopall][noskip][w:8][next]",
            "[instant]Poseur [instant:stopall][waitall:3]intends to stop you."}
    
    route.endofsegmentmsg = "It looks like this is it."
    
    enemies[1]["comments"] = {
        {"Game world is going down![instant:stopall][noskip][w:5][next]",
         "[instant]Game world is going[instant:stopall][noskip][w:2][next]",
         "[instant]Game world is[instant:stopall][noskip][w:4][next]",
         "[instant]\"Game world is[instant:stopall][noskip][w:4][next]",
         "[instant]\"Game world\" is[instant:stopall][noskip][w:8][next]",
         "[instant]\"Game world\" is[instant:stopall][waitall:3] done for."},
        Misc.MachineName .. " is in danger!",
        "[color:000000][color:ffffff]",
        "[WARN][w:5] No background file found.\r[w:5]Using empty background.",
        "[WARN][w:5] There is no encounter\rtext!"
    }
    
    enemies[1]["check"] = ""
    for i = 1, 20 do
        if math.random() < 0.25 then
            enemies[1]["check"] = enemies[1]["check"] .. " "
        else
            enemies[1]["check"] = enemies[1]["check"] .. enemies[1]["anim"].gletters[math.random(78)]
        end
    end
    
    enemies[1]["dispatk"] = enemies[1]["anim"].gletters[math.random(78)] .. enemies[1]["anim"].gletters[math.random(78)] .. enemies[1]["anim"].gletters[math.random(78)]
    enemies[1]["dispdef"] = enemies[1]["anim"].gletters[math.random(78)] .. enemies[1]["anim"].gletters[math.random(78)] .. enemies[1]["anim"].gletters[math.random(78)]
    
    enemies[1].Call("loadstring", "anim.timer = 0 ; anim.EnterGlitch()")
    enemies[1]["attackcount"] = 0
end

-- pacifist
function route.pacifist()
    -- set window title
    if windows then
        Misc.WindowName = "Here's a real high-class bout!"
    end
    
    enemies[1]["hp"] = enemies[1]["maxhp"]
    route.vulnerable = false
    enemies[1]["check"] = "He's not giving in so easily."
    enemies[1]["def"] = 2
    enemies[1]["dispdef"] = 15
    enemies[1]["commands"] = { "Check", "Count" }
    
    -- play music
    musicIntroLoop.StartSong("Working Together (Intro)", "Working Together (Loop)", 11.8, 0.55)
    
    encountertext = "Poseur takes another stand!"
    
    route.endofsegmentmsg = "That's it...?"
    
    -- set comments
    enemies[1]["comments"] = {
        "Poseur bounces along.",
        "Projectiles scatter on the\rground around you.",
        "Is this dog here to help?[w:5]\nOr something?",
        "It's getting pretty hot\rin here.",
        "Poseur's still holding the\rsame pose.",
        "The battle rages on.",
        "The dog seems to want\ryour attention.",
        "What?[w:5] Is this a shield??",
        "Attacks bounce harmlessly\roff of the magic shield.",
        "Battle rages on.",
        "Something's coming...!",
        "Poseur's almost out of\renergy...",
    }
    
    enemies[1].Call("loadstring", "anim.timer = 0 ; anim.animate = true")
    enemies[1]["attackcount"] = 0
end

return route
