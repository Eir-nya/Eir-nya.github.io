wrapper = require "Libraries/userdataWrapper"

wrapper.WrapArena({
        -- Arena.width: gets Encounter["arenasize"][1]
        width = {
            set = function(_are, are, val)
                Encounter["arenasize"][1] = val
            end,
            get = function()
                return Encounter["arenasize"][1]
            end
        },
        
        -- Arena.height: gets Encounter["arenasize"][2]
        height = {
            set = function(_are, are, val)
                Encounter["arenasize"][2] = val
            end,
            get = function()
                return Encounter["arenasize"][2]
            end
        },
        
        -- Arena.x: gets Encounter["fakearena"].pos[1]
        x = {
            set = function(_are, are, val)
                Encounter["fakearena"].pos[1] = val
            end,
            get = function()
                return Encounter["fakearena"].pos[1]
            end
        },
        
        -- Arena.y: gets Encounter["fakearena"].pos[2]
        y = {
            set = function(_are, are, val)
                Encounter["fakearena"].pos[2] = val
            end,
            get = function()
                return Encounter["fakearena"].pos[2]
            end
        },
        
        -- Arena.currentwidth: gets Encounter["fakearena"].arena.xscale
        currentwidth = {
            set = function(_are, are, val)
                Encounter["fakearena"].arena.xscale = val
            end,
            get = function()
                return Encounter["fakearena"].arena.xscale
            end
        },
        
        -- Arena.currentheight: gets Encounter["fakearena"].arena.yscale
        currentheight = {
            set = function(_are, are, val)
                Encounter["fakearena"].arena.yscale = val
            end,
            get = function()
                return Encounter["fakearena"].arena.yscale
            end
        },
        
        -- Arena.currentx: gets Encounter["fakearena"].arena.x
        currentx = {
            set = function(_are, are, val)
                Encounter["fakearena"].arena.x = val
            end,
            get = function()
                return Encounter["fakearena"].arena.x
            end
        },
        
        -- Arena.currenty: gets Encounter["fakearena"].arena.y
        currenty = {
            set = function(_are, are, val)
                Encounter["fakearena"].arena.y = val
            end,
            get = function()
                return Encounter["fakearena"].arena.y
            end
        },
        
        -- Arena.isResizing: tells you if the arena is resizing
        isResizing = {
            get = function()
                return not (Encounter["fakearena"].arena.xscale == Encounter["arenasize"][1]
                        and Encounter["fakearena"].arena.yscale == Encounter["arenasize"][2])
            end
        },
        
        -- Arena.isMoving: tells you if the arena is moving
        isMoving = {
            get = function()
                local cond1 = Encounter["fakearena"].arena.x == Encounter["fakearena"].pos[1]
                if Encounter["fakearena"].offset[1] ~= 0 then
                    cond2 = math.abs(Encounter["fakearena"].arena.x - (Encounter["fakearena"].pos[1] + Encounter["fakearena"].offset[1])) < 1
                end
                
                local cond2 = Encounter["fakearena"].arena.y == Encounter["fakearena"].pos[2]
                if Encounter["fakearena"].offset[2] ~= 0 then
                    cond2 = math.abs(Encounter["fakearena"].arena.y - (Encounter["fakearena"].pos[2] + Encounter["fakearena"].offset[2])) < 1
                end
                
                return not (cond1 and cond2)
            end
        },
        
        -- Arena.isModifying: tells you if the arena is resizing OR moving
        isModifying = {
            get = function(_are, are)
                return are.isResizing or are.isMoving
            end
        },
        
        -- Arena.Resize: same as setting both width and height at once
        Resize = {
            set = function(_are, are, width, height)
                Encounter["arenasize"][1] =  width
                Encounter["arenasize"][2] = height
            end
        },
        
        -- Arena.ResizeImmediate: same as setting both width and height at once
        ResizeImmediate = {
            set = function(_are, are, width, height)
                Encounter["arenasize"][1] =  width
                Encounter["arenasize"][2] = height
                
                Encounter["fakearena"].arena.Scale(width, height)
            end
        },
        
        -- Arena.Move: moves the arena relative to its current position
        Move = {
            set = function(_are, are, x, y, movePlayer, immediate)
                local movePlayer = movePlayer == nil and  true or movePlayer
                local immediate  =  immediate == nil and false or  immediate
                
                Encounter["fakearena"].pos[1] = Encounter["fakearena"].pos[1] + x
                Encounter["fakearena"].pos[2] = Encounter["fakearena"].pos[2] + y
                
                if movePlayer then
                    Player.Move(x, y, true)
                end
                
                if immediate then
                    Encounter["fakearena"].arena.MoveTo(Encounter["fakearena"].pos[1], Encounter["fakearena"].pos[2])
                end
            end
        },
        
        -- Arena.MoveTo: moves the arena relative to the bottom-left of the screen
        MoveTo = {
            set = function(_are, are, x, y, movePlayer, immediate)
                are.Move(x - Encounter["fakearena"].pos[1], y - Encounter["fakearena"].pos[2], movePlayer, immediate)
            end
        },
        
        -- Arena.MoveAndResize: moves the arena relative to its current position and resizes it
        MoveAndResize = {
            set = function(_are, are, x, y, width, height, movePlayer, immediate)
                are.Move(x, y, movePlayer, immediate)
                if immediate then
                    are.ResizeImmediate(width, height)
                else
                    are.Resize(width, height)
                end
            end
        },
        
        -- Arena.MoveToAndResize: moves the arena relative to its current position and resizes it
        MoveToAndResize = {
            set = function(_are, are, x, y, width, height, movePlayer, immediate)
                are.MoveTo(x, y, movePlayer, immediate)
                if immediate then
                    are.ResizeImmediate(width, height)
                else
                    are.Resize(width, height)
                end
            end
        },
        
        -- Arena.Hide: calls Encounter["fakearena"].arena.alpha = 0
        Hide = {
            set = function()
                for spr in pairs(({[Encounter["fakearena"].arena] = true,
                                   [Encounter["fakearena"].top] = true,
                                   [Encounter["fakearena"].topleft] = true,
                                   [Encounter["fakearena"].topright] = true,
                                   [Encounter["fakearena"].bottom] = true,
                                   [Encounter["fakearena"].bottomleft] = true,
                                   [Encounter["fakearena"].bottomright] = true,
                                   [Encounter["fakearena"].left] = true,
                                   [Encounter["fakearena"].right] = true})) do
                    spr.alpha = 0
                end
            end
        },
        
        -- Arena.Show: calls Encounter["fakearena"].arena.alpha = 1
        Show = {
            set = function()
                for spr in pairs(({[Encounter["fakearena"].arena] = true,
                                   [Encounter["fakearena"].top] = true,
                                   [Encounter["fakearena"].topleft] = true,
                                   [Encounter["fakearena"].topright] = true,
                                   [Encounter["fakearena"].bottom] = true,
                                   [Encounter["fakearena"].bottomleft] = true,
                                   [Encounter["fakearena"].bottomright] = true,
                                   [Encounter["fakearena"].left] = true,
                                   [Encounter["fakearena"].right] = true})) do
                    spr.alpha = 1
                end
            end
        },
        
        -- Arena.rotation: gets and sets Encounter["fakearena"].arena.rotation
        rotation = {
            set = function(_are, are, val)
                Encounter["fakearena"].arena.rotation = val
                Encounter["fakearena"].target.rotation = Encounter["fakearena"].arena.rotation
                Encounter["fakearena"].top.rotation = Encounter["fakearena"].arena.rotation
                Encounter["fakearena"].bottom.rotation = Encounter["fakearena"].arena.rotation
                Encounter["fakearena"].left.rotation = Encounter["fakearena"].arena.rotation
                Encounter["fakearena"].right.rotation = Encounter["fakearena"].arena.rotation
            end,
            get = function()
                return Encounter["fakearena"].arena.rotation
            end,
        },
        
        -- Arena.speed: gets and sets Encounter["fakearena"].speed
        speed = {
            set = function(_are, are, val)
                Encounter["fakearena"].speed = val
            end,
            get = function()
                return Encounter["fakearena"].speed
            end,
        },
        
        -- Arena.sprite: returns Encounter["fakearena"].arena
        sprite = {
            get = function()
                return Encounter["fakearena"].arena
            end
        },
    })



--==========--

wrapper.autoWrapSprite = false
wrapper.projectileValues = {
    -- Bullet.x: gets/sets position relative to arena center
    x = {
        set = function(_prj, prj, val)
            _prj.absx = Arena.currentx + val
        end,
        get = function(_prj, prj)
            return _prj.absx - Arena.currentx
        end
    },
    
    -- Bullet.y: gets/sets position relative to arena center
    y = {
        set = function(_prj, prj, val)
            _prj.absy = Arena.currenty + (Arena.currentheight / 2) + val
        end,
        get = function(_prj, prj)
            return _prj.absy - (Arena.currenty + (Arena.currentheight / 2))
        end
    },
    
    -- Bullet.MoveTo: sets position relative to arena center
    MoveTo = {
        set = function(_prj, prj, x, y)
            prj.x = x
            prj.y = y
        end
    },
}

local _cp = CreateProjectile
function CreateProjectile(...)
    local bul = wrapper.WrapProjectile(_cp(...))
    bul.SetVar("wrapped", bul)
    bul.MoveTo(({...})[2], ({...})[3])
    bul.sprite.layer = "Topper"
    return bul
end

local _cpa = CreateProjectileAbs
function CreateProjectileAbs(...)
    local bul = wrapper.WrapProjectile(_cpa(...))
    bul.SetVar("wrapped", bul)
    bul.MoveToAbs(({...})[2], ({...})[3])
    bul.sprite.layer = "Topper"
    return bul
end

--==========--

Player.SetControlOverride(true)
Player.sprite.SetParent(Encounter["fakearena"].arena)
Player.sprite.rotation = Encounter["fakearena"].arena.rotation

local speed = 2
local controlOverride = false
SetGlobal("invulTimer", 0)

wrapper.WrapPlayer({
    -- Player.x: gets/sets position relative to arena center
    x = {
        set = function(_pla, pla, val)
            _pla.sprite.x = (Arena.currentwidth/2) + val
        end,
        get = function(_pla, pla)
            return _pla.sprite.x - (Arena.currentwidth/2)
        end
    },
    
    -- Player.y: gets/sets position relative to arena center
    y = {
        set = function(_pla, pla, val)
            _pla.sprite.y = (Arena.currentheight/2) + val
        end,
        get = function(_pla, pla)
            return _pla.sprite.y - (Arena.currentheight/2)
        end
    },
    
    -- Player.absx: gets/sets position relative to bottom-left of screen
    absx = {
        set = function(_pla, pla, val)
            _pla.sprite.absx = val
        end,
        get = function(_pla, pla)
            return _pla.sprite.absx
        end
    },
    
    -- Player.absy: gets/sets position relative to bottom-left of screen
    absy = {
        set = function(_pla, pla, val)
            _pla.sprite.absy = val
        end,
        get = function(_pla, pla)
            return _pla.sprite.absy
        end
    },
    
    -- Player.KeepInBounds(): keeps the player inside the arena
    KeepInBounds = {
        set = function(_pla, pla)
            local arena_left_side   = -Encounter["fakearena"].arena.xscale/2
            local arena_right_side  =  Encounter["fakearena"].arena.xscale/2
            local arena_top_side    =  Encounter["fakearena"].arena.yscale/2
            local arena_bottom_side = -Encounter["fakearena"].arena.yscale/2
            
            local player_width  = _pla.sprite.width /2 * _pla.sprite.xscale
            local player_height = _pla.sprite.height/2 * _pla.sprite.yscale
            
            --   left side
            if     pla.x - player_width <   arena_left_side then
                pla.x = arena_left_side   + player_width
            
            --  right side
            elseif pla.x + player_width >   arena_right_side then
                pla.x = arena_right_side  - player_width
            end
            
            --    top side
            --     (                         top edge of player                       )
            if     pla.y + player_height >    arena_top_side then
                pla.y = arena_top_side    - player_height
            
            -- bottom side
            --     (                      bottom edge of player                       )
            elseif pla.y - player_height < arena_bottom_side then
                pla.y = arena_bottom_side + player_height
            end
        end
    },
    
    -- Player.Move: adds on to x and y
    Move = {
        set = function(_pla, pla, x, y, ignoreWalls)
            pla.x = pla.x + x
            pla.y = pla.y + y
            
            if not ignoreWalls then
                pla.KeepInBounds()
            end
        end
    },
    
    -- Player.MoveTo: gets/sets position relative to arena center
    MoveTo = {
        set = function(_pla, pla, x, y)
            pla.x = x
            pla.y = y
            
            if not ignoreWalls then
                pla.KeepInBounds()
            end
        end
    },
    
    -- Player.Hurt: also shakes the screen (optionally)
    Hurt = {
        set = function(_pla, pla, damage, invuln, shake)
            if not pla.isHurting then
                if _pla.hp - damage > 0 then
                    if shake ~= false then
                        Misc.ShakeScreen(6, 6)
                    end
                    _pla.hp = _pla.hp - damage
                    Audio.PlaySound("hurtsound")
                    pla.invulTimer = (invuln and invuln or 1.7) * 60
                    
                    _pla.sprite.alpha = _pla.sprite.alpha / 2
                    if _pla.sprite["outline"] and Encounter["route"].route == 2 then
                        _pla.sprite["outline"].alpha = _pla.sprite["outline"].alpha / 2
                    end
                else
                    Encounter.Call("loadstring",
                            "gameover = require \"Libraries/game_over_" .. (Encounter["route"].genostep == 2 and "deltarune" or "undertale") .. "\" ; "
                         .. "Update = function() ; "
                             .. "gameover.Update() ; "
                         .. "end ; "
                         .. "gameover.text = deathtext and deathtext or gameover.text ; "
                         .. "gameover.music = deathmusic and deathmusic or gameover.music ; "
                         .. "gameover.layer = \"Toppest\" ; "
                         .. "gameover.shardcount = " .. (Encounter["route"].genostep == 3 and 400 or 6) .. " ; "
                         .. "gameover.StartGameOver() ; "
                         .. "Misc.ResetCamera() ; "
                         .. "NewAudio.StopAll() ; "
                         .. "route.deathfunc()"
                    )
                    State("NONE")
                end
            end
        end
    },
    
    -- Player.isHurting: returns if `invulTimer` from above is > 0
    isHurting = {
        get = function(_pla, pla)
            return GetGlobal("invulTimer") and GetGlobal("invulTimer") > 0
        end
    },
    
    -- Player.invulTimer: gets and sets `invulTimer` from above. see `Libraries/fakearena_WAVE_END.lua`
    invulTimer = {
        set = function(_pla, pla, val)
            SetGlobal("invulTimer", val)
        end,
        get = function()
            return GetGlobal("invulTimer") and GetGlobal("invulTimer")
        end
    },
    
    -- Player.speed: gets and sets `speed` from above. see `Libraries/fakearena_WAVE_END.lua`
    speed = {
        set = function(_pla, pla, val)
            speed = val
        end,
        get = function()
            return speed
        end
    },
    
    -- Player.controlOverride: gets and sets `controlOverride` from above. see `Libraries/fakearena_WAVE_END.lua`
    controlOverride = {
        set = function(_pla, pla, val)
            controlOverride = val
        end,
        get = function()
            return controlOverride
        end
    },
    
    -- Player.SetControlOverride: shortcut to above
    SetControlOverride = {
        set = function(_pla, pla, val)
            pla.controlOverride = val
        end
    }
})

Player.MoveTo(0, 0)
