-- made by WD200019
local self = {}

-- will be true whenever the game over sequence is active.
self.active = false

-- the layer to create all of the sprites on
self.layer = "Top"

-- number of shards to create!
self.shardcount = 6

-- used to keep track of the progress of the game over animation
self.animtimer = 0

local defaultmessages = {"[noskip][charspacing:7][voice:v_fluffybuns][waitall:2]Our fate rests\nupon you...",
                          "[noskip][charspacing:7][voice:v_fluffybuns][waitall:2]Don't lose hope!",
                          "[noskip][charspacing:7][voice:v_fluffybuns][waitall:2]It cannot end now!",
                          "[noskip][charspacing:7][voice:v_fluffybuns][waitall:2]You're going to\nbe alright!",
    "[noskip][charspacing:7][voice:v_fluffybuns][waitall:2]" .. Player.name .. "![novoice]        [voice:v_fluffybuns]\nStay determined..."}

-- the text to be displayed on death
self.text = {defaultmessages[math.random(1, 4)], defaultmessages[5], defaultmessages[6]}

-- the music to play.
-- !!!!! set to "none" for silence !!!!!
self.music = "mus_gameover"

-- the update function. call from the encounter's Update function !
function self.Update()
    -- update player soul shards
	if self.active and self.shards ~= nil then
		if self.animtimer > 150 then
			for i = 1, #self.shards do
                if self.shards[i][1] ~= nil then
                    local shard = self.shards[i][1]
                    local velx = self.shards[i][2]
                    local vely = self.shards[i][3]
                    
                    shard.MoveTo(shard.x + (velx * shard["xmult"]), shard.y + vely)
                    
                    -- slow down the shard's horizontal movement
                    if shard["xmult"] > 0 then
                        shard["xmult"] = shard["xmult"] - 0.0125
                        
                        if shard["xmult"] < 0 then
                            shard["xmult"] = 0
                        end
                    end
                    
                    self.shards[i][3] = self.shards[i][3] - 0.025
                    
                    -- animate the shard
                    if (self.animtimer - 140)%4 == 0 then
                        shard.Set("UI/Battle/heartshard_" .. tostring(math.floor((self.animtimer-140)/8)%4))
                    end
                    
                    if shard.absy < -shard.height then
                        self.shards[i][1].Remove()
                        self.shards[i][1] = nil
                    end
                end
			end
		end
	elseif self.shards ~= nil and #self.shards == 0 and self.animtimer > 360 and self.animtimer < 370 then
		self.animtimer = 360
	end
    
    -- update animation timer
	if self.animtimer > 0 and not self.textobject then
		self.animtimer = self.animtimer + 1
        
        -- break the heart (1/2)
		if self.animtimer == 80 then
			Audio.PlaySound("heartbeatbreaker")
            
			self.fakePlayer.Set("ut-heart-broken")
            self.fakePlayer.rotation = 0
        -- break the heart (2/2)
		elseif self.animtimer == 150 then
			Audio.PlaySound("heartsplosion")
            
            -- a table of player soul fragments to animate
			self.shards = {}
            
            -- create shards
			for i = 1, self.shardcount do
				local shard = CreateSprite("UI/Battle/heartshard_0", self.layer)
                shard.MoveTo(self.fakePlayer.absx, self.fakePlayer.absy)
				shard.color = self.fakePlayer.color
				shard.SetVar("xmult", 2)
                
				local velx = 0
                local vely = 0
                
                -- make sure that every shard has a unique x and y velocity
				local prev_velx = {}
                local prev_vely = {}
                
				for j = 1, #self.shards do
					prev_velx[self.shards[j][2]] = true
					prev_vely[self.shards[j][3]] = true
				end
                
                -- original
                if self.shardcount <= 6 then
                    repeat
                        velx = (math.random(-3, 4.5) / 3)
                    until prev_velx[velx] == nil
                    
                    repeat
                        vely = (math.random(-5, 5) / 5) + 1
                    until prev_vely[vely] == nil
                
                -- shoehorned in version
                else
                    velx = (  0 + (math.random() *   3)) * (math.random() < 0.5 and -1 or 1)
                    vely = ( -1 + (math.random() * 2.5))
                end
                
                shard.xscale = math.random() < 0.5 and -1 or 1
                
				table.insert(self.shards, {shard, velx, vely})
			end
            
            -- remove the fake player
			self.fakePlayer.Remove()
            self.fakePlayer = nil
        -- start the music and create the "game over" text
		elseif self.animtimer == 250 then
            if self.music ~= "none" then
                Audio.LoadFile(self.music and self.music or (deathmusic and deathmusic or "mus_gameover"))
                Audio.Volume(0.75)
            end
            
            -- create the "game over" text
			self.gameover = CreateSprite("UI/spr_gameoverbg_0", self.layer)
            self.gameover.MoveTo(322, 356)
			self.gameover.alpha = 0
        -- fade in the "game over" text
		elseif self.animtimer > 250 and self.gameover.alpha < 1 and self.animtimer < 370 then
			self.gameover.alpha = self.gameover.alpha + 0.0125
        -- start the text
		elseif self.animtimer == 360 then
            self.StartText()
        -- fade out the "game over" text
		elseif self.animtimer >= 370 and self.animtimer < 550 then
			self.gameover.alpha = self.gameover.alpha - (1/120)
			Audio.Volume(0.75 - ((self.animtimer-370)/180))
        -- finally, end the game over screen
		elseif self.animtimer == 550 then
			self.EndAction()
		end
    -- freeze self.animtimer until the text object is all done
    elseif self.textobject then
        if self.textobject.allLinesComplete then
            self.textobject = nil
        end
	end
end

-- call this function to begin the game over!
function self.StartGameOver()
    if not self.active then
        NewAudio.StopAll()
        Audio.PlaySound("hurtsound")
        
        self.active = true
        self.animtimer = 1
        
        self.cover = CreateSprite("UI/sq_white", self.layer)
        self.cover.MoveTo(320, 240)
        self.cover.Scale(640/4, 480/4)
        self.cover.color = { 0, 0, 0 }
        
        self.fakePlayer = CreateSprite(Player.sprite.spritename, self.layer)
        self.fakePlayer.MoveTo(Player.sprite.absx, Player.sprite.absy)
        self.fakePlayer.color = Player.sprite.color
        self.fakePlayer.rotation = Player.sprite.rotation
        
        State("PAUSE")
        
        function Update()
            self.Update()
        end
    end
end

-- this function creates the game over text
function self.StartText()
    table.insert(self.text, "")
    self.textobject = CreateText(self.text, {159, 112}, 320, self.layer)
    self.textobject.SetFont("uidialog")
    self.textobject.color = {1, 1, 1}
    self.textobject.HideBubble()
    self.textobject.progressmode = "manual"
end

-- this function gets called automatically whenever the game over sequence has ended.
-- put your code here! especially recommended for setting globals!
function self.EndAction()
    self.active = false
    
    -- self.cover.Remove()
    -- self.cover = nil
    -- self.gameover.Remove()
    -- self.gameover = nil
    
	State("DONE")
end

return self